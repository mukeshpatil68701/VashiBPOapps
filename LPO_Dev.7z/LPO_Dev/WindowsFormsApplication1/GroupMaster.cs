﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LPO_Dev
{
    public partial class Group_Master : Form
    {
        public Group_Master()
        {
            InitializeComponent();
        }

        private void Group_Master_Load(object sender, EventArgs e)
        {
            bindGV();
        }
        public void  bindGV()
        {
            try
            {
                clsMain.Connect();
                String StrData = "Select GroupId,Group_Name,(case Active when 'Y'  THEN 'True'  else 'False' end)  as 'Flag' from vu_admin_groupmaster where Active = 'Y' order by GroupId";
                DataTable Objdt = new DataTable();
                Objdt = clsMain.GetData(StrData);
                if (Objdt.Rows.Count > 0)
                {

                    dgvUserRole.Columns[0].Name = "GroupId";
                    dgvUserRole.Columns[0].HeaderText = "UserType Id";
                    dgvUserRole.Columns[0].DataPropertyName = "GroupId";
                    dgvUserRole.Columns[0].Width = 100;


                    dgvUserRole.Columns[1].Name = "Group_Name";
                    dgvUserRole.Columns[1].HeaderText = "User Role";
                    dgvUserRole.Columns[1].DataPropertyName = "Group_Name";
                    dgvUserRole.Columns[1].Width = 150;

                    dgvUserRole.Columns[2].Name = "Flag";
                    dgvUserRole.Columns[2].HeaderText = "IsActive";
                    dgvUserRole.Columns[2].DataPropertyName = "Flag";
                    dgvUserRole.Columns[2].Width = 150;
                    dgvUserRole.AllowUserToAddRows = false;

                    dgvUserRole.DataSource = Objdt;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);


            }

        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            string StrSqlInsert = string.Empty;
            string StrSqlUpdate = string.Empty;
            DateTime currentDate = DateTime.Now;
            try
            {

                if (btnSave.Text == "Update")
                {
                    StrSqlUpdate = "Update vu_admin_groupmaster  set Group_Name='" + txtgrpName.Text.Trim() + "' where GroupId='" + ClsProperty.GroupID + "' ";
                    bool Update = clsMain.ExcuteDML(StrSqlUpdate);
                    if (Update == true)
                    {
                        MessageBox.Show("Data Update Successfully..");

                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }
                }
                else
                {
                    StrSqlInsert = "Insert into vu_admin_groupmaster(Group_Name,Active,Created_On,Created_by )"
                                           + "values ('" + txtgrpName.Text + "','Y','" + currentDate.ToString("dd-MM-yyyy") + "','" + ClsProperty.UserName + "')";


                    bool Insert = clsMain.ExcuteDML(StrSqlInsert);
                    if (Insert == true)
                    {
                        MessageBox.Show("Data Save Successfully..");

                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dgvUserRole_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int row;               
                row = e.RowIndex;               
                string GroupId = dgvUserRole.Rows[row].Cells["GroupId"].Value.ToString();
                ClsProperty.GroupID = GroupId;
                string Group_Name = dgvUserRole.Rows[row].Cells["Group_Name"].Value.ToString();
                txtgrpName.Text = Group_Name;

                this.dgvUserRole.Cursor = Cursors.Hand;
                btnSave.Text = "Update";
            }
            catch (Exception ex)
            {


                MessageBox.Show(ex.Message);
            }
        }
    }
}
