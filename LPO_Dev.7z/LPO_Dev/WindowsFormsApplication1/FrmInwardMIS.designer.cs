﻿namespace LPO_Dev
{
    partial class FrmInwardMIS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbtbyinwardDate = new System.Windows.Forms.RadioButton();
            this.pnlsingle = new System.Windows.Forms.Panel();
            this.textAppno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLoanno = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtpic = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnZoomout = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnzoomin = new System.Windows.Forms.Button();
            this.btnExel = new System.Windows.Forms.Button();
            this.pnlbulk = new System.Windows.Forms.Panel();
            this.rbtnAppno = new System.Windows.Forms.RadioButton();
            this.rbtnLoanno = new System.Windows.Forms.RadioButton();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.textBrowse = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRecords = new System.Windows.Forms.Button();
            this.PnlbyDate = new System.Windows.Forms.Panel();
            this.rbtnBulkSearch = new System.Windows.Forms.RadioButton();
            this.rbtnSingleSearch = new System.Windows.Forms.RadioButton();
            this.ofdbox = new System.Windows.Forms.OpenFileDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.dgvStatus = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.VU_Inwardno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VU_MasterID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VU_inward_IS_POD_RTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vu_TemplateName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DownloadImage = new System.Windows.Forms.DataGridViewButtonColumn();
            this.showImage = new System.Windows.Forms.DataGridViewButtonColumn();
            this.FrmdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.TodateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.pnlsingle.SuspendLayout();
            this.pnlbulk.SuspendLayout();
            this.PnlbyDate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "To Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "From Date";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.rbtbyinwardDate);
            this.panel1.Controls.Add(this.pnlsingle);
            this.panel1.Controls.Add(this.txtpic);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.btnZoomout);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.btnzoomin);
            this.panel1.Controls.Add(this.btnExel);
            this.panel1.Controls.Add(this.pnlbulk);
            this.panel1.Controls.Add(this.btnRecords);
            this.panel1.Controls.Add(this.PnlbyDate);
            this.panel1.Controls.Add(this.rbtnBulkSearch);
            this.panel1.Controls.Add(this.rbtnSingleSearch);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1057, 141);
            this.panel1.TabIndex = 20;
            // 
            // rbtbyinwardDate
            // 
            this.rbtbyinwardDate.AutoSize = true;
            this.rbtbyinwardDate.Location = new System.Drawing.Point(12, 3);
            this.rbtbyinwardDate.Name = "rbtbyinwardDate";
            this.rbtbyinwardDate.Size = new System.Drawing.Size(134, 17);
            this.rbtbyinwardDate.TabIndex = 50;
            this.rbtbyinwardDate.TabStop = true;
            this.rbtbyinwardDate.Text = "Search by Inward Date";
            this.rbtbyinwardDate.UseVisualStyleBackColor = true;
            this.rbtbyinwardDate.CheckedChanged += new System.EventHandler(this.rbtbyinwardDate_CheckedChanged);
            // 
            // pnlsingle
            // 
            this.pnlsingle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlsingle.Controls.Add(this.textAppno);
            this.pnlsingle.Controls.Add(this.label2);
            this.pnlsingle.Controls.Add(this.txtLoanno);
            this.pnlsingle.Controls.Add(this.label5);
            this.pnlsingle.Location = new System.Drawing.Point(296, 26);
            this.pnlsingle.Name = "pnlsingle";
            this.pnlsingle.Size = new System.Drawing.Size(374, 63);
            this.pnlsingle.TabIndex = 49;
            // 
            // textAppno
            // 
            this.textAppno.Location = new System.Drawing.Point(157, 35);
            this.textAppno.Name = "textAppno";
            this.textAppno.Size = new System.Drawing.Size(146, 20);
            this.textAppno.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Application No.";
            // 
            // txtLoanno
            // 
            this.txtLoanno.Location = new System.Drawing.Point(157, 6);
            this.txtLoanno.Name = "txtLoanno";
            this.txtLoanno.Size = new System.Drawing.Size(146, 20);
            this.txtLoanno.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(70, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Loan / Card No";
            // 
            // txtpic
            // 
            this.txtpic.Location = new System.Drawing.Point(1020, 113);
            this.txtpic.Name = "txtpic";
            this.txtpic.Size = new System.Drawing.Size(30, 20);
            this.txtpic.TabIndex = 48;
            this.txtpic.Visible = false;
            this.txtpic.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtpic_KeyDown);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(3, 114);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 20);
            this.checkBox1.TabIndex = 47;
            this.checkBox1.Text = "Select All";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // btnZoomout
            // 
            this.btnZoomout.Location = new System.Drawing.Point(707, 113);
            this.btnZoomout.Name = "btnZoomout";
            this.btnZoomout.Size = new System.Drawing.Size(65, 21);
            this.btnZoomout.TabIndex = 46;
            this.btnZoomout.Text = "Zoom Out";
            this.btnZoomout.UseVisualStyleBackColor = true;
            this.btnZoomout.Click += new System.EventHandler(this.btnZoomout_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(495, 96);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(59, 36);
            this.button4.TabIndex = 17;
            this.button4.Text = "Exit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnzoomin
            // 
            this.btnzoomin.Location = new System.Drawing.Point(637, 113);
            this.btnzoomin.Name = "btnzoomin";
            this.btnzoomin.Size = new System.Drawing.Size(64, 21);
            this.btnzoomin.TabIndex = 45;
            this.btnzoomin.Text = "Zoom In";
            this.btnzoomin.UseVisualStyleBackColor = true;
            this.btnzoomin.Click += new System.EventHandler(this.btnzoomin_Click);
            // 
            // btnExel
            // 
            this.btnExel.Location = new System.Drawing.Point(361, 96);
            this.btnExel.Name = "btnExel";
            this.btnExel.Size = new System.Drawing.Size(126, 36);
            this.btnExel.TabIndex = 16;
            this.btnExel.Text = "Download All";
            this.btnExel.UseVisualStyleBackColor = true;
            this.btnExel.Click += new System.EventHandler(this.btnExel_Click);
            // 
            // pnlbulk
            // 
            this.pnlbulk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlbulk.Controls.Add(this.rbtnAppno);
            this.pnlbulk.Controls.Add(this.rbtnLoanno);
            this.pnlbulk.Controls.Add(this.btnBrowse);
            this.pnlbulk.Controls.Add(this.textBrowse);
            this.pnlbulk.Controls.Add(this.label1);
            this.pnlbulk.Location = new System.Drawing.Point(676, 26);
            this.pnlbulk.Name = "pnlbulk";
            this.pnlbulk.Size = new System.Drawing.Size(374, 63);
            this.pnlbulk.TabIndex = 15;
            // 
            // rbtnAppno
            // 
            this.rbtnAppno.AutoSize = true;
            this.rbtnAppno.Location = new System.Drawing.Point(140, 7);
            this.rbtnAppno.Name = "rbtnAppno";
            this.rbtnAppno.Size = new System.Drawing.Size(97, 17);
            this.rbtnAppno.TabIndex = 9;
            this.rbtnAppno.TabStop = true;
            this.rbtnAppno.Text = "Application No.";
            this.rbtnAppno.UseVisualStyleBackColor = true;
            this.rbtnAppno.CheckedChanged += new System.EventHandler(this.rbtnAppno_CheckedChanged);
            // 
            // rbtnLoanno
            // 
            this.rbtnLoanno.AutoSize = true;
            this.rbtnLoanno.Location = new System.Drawing.Point(30, 7);
            this.rbtnLoanno.Name = "rbtnLoanno";
            this.rbtnLoanno.Size = new System.Drawing.Size(93, 17);
            this.rbtnLoanno.TabIndex = 8;
            this.rbtnLoanno.TabStop = true;
            this.rbtnLoanno.Text = "Card/Loan No";
            this.rbtnLoanno.UseVisualStyleBackColor = true;
            this.rbtnLoanno.CheckedChanged += new System.EventHandler(this.rbtnLoanno_CheckedChanged);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(291, 30);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(60, 23);
            this.btnBrowse.TabIndex = 7;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // textBrowse
            // 
            this.textBrowse.Location = new System.Drawing.Point(140, 32);
            this.textBrowse.Name = "textBrowse";
            this.textBrowse.Size = new System.Drawing.Size(146, 20);
            this.textBrowse.TabIndex = 6;
            this.textBrowse.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBrowse_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(35, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Select Excel File";
            // 
            // btnRecords
            // 
            this.btnRecords.Location = new System.Drawing.Point(222, 98);
            this.btnRecords.Name = "btnRecords";
            this.btnRecords.Size = new System.Drawing.Size(133, 34);
            this.btnRecords.TabIndex = 14;
            this.btnRecords.Text = "Find Records";
            this.btnRecords.UseVisualStyleBackColor = true;
            this.btnRecords.Click += new System.EventHandler(this.btnRecords_Click);
            // 
            // PnlbyDate
            // 
            this.PnlbyDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlbyDate.Controls.Add(this.TodateTimePicker);
            this.PnlbyDate.Controls.Add(this.FrmdateTimePicker);
            this.PnlbyDate.Controls.Add(this.label3);
            this.PnlbyDate.Controls.Add(this.label4);
            this.PnlbyDate.Location = new System.Drawing.Point(12, 25);
            this.PnlbyDate.Name = "PnlbyDate";
            this.PnlbyDate.Size = new System.Drawing.Size(274, 63);
            this.PnlbyDate.TabIndex = 13;
            this.PnlbyDate.Paint += new System.Windows.Forms.PaintEventHandler(this.Pnlsingle_Paint);
            // 
            // rbtnBulkSearch
            // 
            this.rbtnBulkSearch.AutoSize = true;
            this.rbtnBulkSearch.Location = new System.Drawing.Point(676, 3);
            this.rbtnBulkSearch.Name = "rbtnBulkSearch";
            this.rbtnBulkSearch.Size = new System.Drawing.Size(86, 17);
            this.rbtnBulkSearch.TabIndex = 12;
            this.rbtnBulkSearch.TabStop = true;
            this.rbtnBulkSearch.Text = "Bulk Search ";
            this.rbtnBulkSearch.UseVisualStyleBackColor = true;
            this.rbtnBulkSearch.CheckedChanged += new System.EventHandler(this.rbtnBulkSearch_CheckedChanged);
            // 
            // rbtnSingleSearch
            // 
            this.rbtnSingleSearch.AutoSize = true;
            this.rbtnSingleSearch.Location = new System.Drawing.Point(296, 3);
            this.rbtnSingleSearch.Name = "rbtnSingleSearch";
            this.rbtnSingleSearch.Size = new System.Drawing.Size(91, 17);
            this.rbtnSingleSearch.TabIndex = 11;
            this.rbtnSingleSearch.TabStop = true;
            this.rbtnSingleSearch.Text = "Single Search";
            this.rbtnSingleSearch.UseVisualStyleBackColor = true;
            this.rbtnSingleSearch.CheckedChanged += new System.EventHandler(this.rbtnSingleSearch_CheckedChanged);
            // 
            // ofdbox
            // 
            this.ofdbox.FileName = "openFileDialog1";
            // 
            // dgvStatus
            // 
            this.dgvStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStatus.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.VU_Inwardno,
            this.VU_MasterID,
            this.VU_inward_IS_POD_RTO,
            this.Vu_TemplateName,
            this.DownloadImage,
            this.showImage});
            this.dgvStatus.Location = new System.Drawing.Point(12, 173);
            this.dgvStatus.Name = "dgvStatus";
            this.dgvStatus.Size = new System.Drawing.Size(556, 482);
            this.dgvStatus.TabIndex = 21;
            this.dgvStatus.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvStatus_CellClick);
            this.dgvStatus.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvStatus_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(495, 482);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 44;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseClick);
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Location = new System.Drawing.Point(586, 173);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(497, 485);
            this.panel2.TabIndex = 45;
            // 
            // Select
            // 
            this.Select.FillWeight = 10F;
            this.Select.HeaderText = "Select";
            this.Select.Name = "Select";
            this.Select.Width = 40;
            // 
            // VU_Inwardno
            // 
            this.VU_Inwardno.HeaderText = "Inward No.";
            this.VU_Inwardno.Name = "VU_Inwardno";
            // 
            // VU_MasterID
            // 
            this.VU_MasterID.HeaderText = "Master ID";
            this.VU_MasterID.Name = "VU_MasterID";
            this.VU_MasterID.Width = 115;
            // 
            // VU_inward_IS_POD_RTO
            // 
            this.VU_inward_IS_POD_RTO.HeaderText = "Status";
            this.VU_inward_IS_POD_RTO.Name = "VU_inward_IS_POD_RTO";
            this.VU_inward_IS_POD_RTO.Width = 40;
            // 
            // Vu_TemplateName
            // 
            this.Vu_TemplateName.HeaderText = "Template Name";
            this.Vu_TemplateName.Name = "Vu_TemplateName";
            this.Vu_TemplateName.Width = 77;
            // 
            // DownloadImage
            // 
            this.DownloadImage.HeaderText = "Download Image";
            this.DownloadImage.Name = "DownloadImage";
            this.DownloadImage.Text = "Download Image";
            this.DownloadImage.Width = 70;
            // 
            // showImage
            // 
            this.showImage.HeaderText = "show Image";
            this.showImage.Name = "showImage";
            this.showImage.Text = "2";
            this.showImage.Width = 70;
            // 
            // FrmdateTimePicker
            // 
            this.FrmdateTimePicker.Location = new System.Drawing.Point(86, 9);
            this.FrmdateTimePicker.Name = "FrmdateTimePicker";
            this.FrmdateTimePicker.Size = new System.Drawing.Size(131, 20);
            this.FrmdateTimePicker.TabIndex = 40;
            // 
            // TodateTimePicker
            // 
            this.TodateTimePicker.Location = new System.Drawing.Point(86, 35);
            this.TodateTimePicker.Name = "TodateTimePicker";
            this.TodateTimePicker.Size = new System.Drawing.Size(131, 20);
            this.TodateTimePicker.TabIndex = 41;
            // 
            // FrmInwardMIS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1095, 685);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dgvStatus);
            this.Controls.Add(this.panel1);
            this.Name = "FrmInwardMIS";
            this.Text = "FrmInwardMIS";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmInwardMIS_Load);
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.FrmInwardMIS_Scroll);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlsingle.ResumeLayout(false);
            this.pnlsingle.PerformLayout();
            this.pnlbulk.ResumeLayout(false);
            this.pnlbulk.PerformLayout();
            this.PnlbyDate.ResumeLayout(false);
            this.PnlbyDate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnExel;
        private System.Windows.Forms.Panel pnlbulk;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox textBrowse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRecords;
        private System.Windows.Forms.Panel PnlbyDate;
        private System.Windows.Forms.RadioButton rbtnBulkSearch;
        private System.Windows.Forms.RadioButton rbtnSingleSearch;
        private System.Windows.Forms.OpenFileDialog ofdbox;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridView dgvStatus;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnzoomin;
        private System.Windows.Forms.Button btnZoomout;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox txtpic;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rbtbyinwardDate;
        private System.Windows.Forms.Panel pnlsingle;
        private System.Windows.Forms.TextBox textAppno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLoanno;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rbtnAppno;
        private System.Windows.Forms.RadioButton rbtnLoanno;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn VU_Inwardno;
        private System.Windows.Forms.DataGridViewTextBoxColumn VU_MasterID;
        private System.Windows.Forms.DataGridViewTextBoxColumn VU_inward_IS_POD_RTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vu_TemplateName;
        private System.Windows.Forms.DataGridViewButtonColumn DownloadImage;
        private System.Windows.Forms.DataGridViewButtonColumn showImage;
        private System.Windows.Forms.DateTimePicker TodateTimePicker;
        private System.Windows.Forms.DateTimePicker FrmdateTimePicker;
    }
}