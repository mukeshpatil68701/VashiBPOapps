﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Odbc;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.Text.RegularExpressions;

namespace LPO_Dev
{
    static class ClsGlobal
    {

        public static int icntTest = 0;

        public static string pServer;
        public static string pDataBase;
        public static string pUid;
        public static string pPwd;
        public static string max_connetion;
        public static OdbcConnection con;
        public static string ConnStr;
        public static OleDbConnection conExcel = new OleDbConnection();


        public static string strGlbFileName = string.Empty;
        public static string strGlbBatchID = string.Empty;



        public static string strGlbInputFilePath = string.Empty;
        public static string strGlbOutputPathBulk = string.Empty;
        public static string strGlbOutputPathReport = string.Empty;
        public static string strGlbOutputPathSticker = string.Empty;
        public static string strGlbPath = @"C:\Output";
        public const string const_strReportTable = "LPO_trnReportTbl";


        public static string strGlbUploadTbl = string.Empty;
        public static string strGlbUploadSuccess = string.Empty;
        public static string strGlbUploadFailed = string.Empty;
        public static string strGlbCol = string.Empty;
        public static string strGlbTemplateName = string.Empty;
        public static ArrayList alSpList = new ArrayList();
        public static Hashtable htGlbVPNCustomer = new Hashtable();

        public static string strGlbTemplateLocation = string.Empty;

        public static Hashtable htGlbColTyp = new Hashtable();
        public static int iGlbRegNo = 0;

        public static string strGlbOdrnDispType = string.Empty;



        public static string strGlbAppstartID = string.Empty;
        /// <summary>
        /// Connects to MySQL server
        /// </summary>
        /// <returns></returns>
        public static bool Connect()
        {
            bool OpenCon = false;
            try
            {
                pServer = ConfigurationManager.AppSettings["Server"].ToString();
                pDataBase = ConfigurationManager.AppSettings["DataBase"].ToString();
                pUid = ConfigurationManager.AppSettings["Uid"].ToString();
                pPwd = ConfigurationManager.AppSettings["Pwd"].ToString();
                max_connetion = ConfigurationManager.AppSettings["max_connection"].ToString();
                strGlbTemplateLocation = ConfigurationManager.AppSettings["ReportPath"].ToString();


                ConnStr = "DRIVER={MySQL ODBC 3.51 Driver}; SERVER=" + pServer + "; DATABASE=" + pDataBase + "; UID=" + pUid + "; PWD=" + pPwd + ";max_connections = " + max_connetion + ";";

                con = new OdbcConnection();

                if (con.State.ToString() == "Closed")
                {
                    con.ConnectionString = ConnStr;
                    con.ConnectionTimeout = 60000;
                    con.Open();
                    OpenCon = true;
                }
            }
            catch (Exception Ex)
            {
                OpenCon = false;
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
            return OpenCon;
        }


        /// <summary>
        /// Starts Processing Excel
        /// </summary>
        /// <param name="iTempIndex">Selected template index</param>
        internal static void ProcessExcel(int iTempIndex, string strDispatchMode)
        {
            DataTable dtExcelData = new DataTable();


            strGlbOdrnDispType = strDispatchMode;
            try
            {

                int iExcelColCount = getExcelColcnt(iTempIndex);
                dtExcelData = getExcelData();
                int idtExcelCnt = dtExcelData.Columns.Count;
                //iRegNo = getRegNumber();
                if (iExcelColCount != idtExcelCnt)
                {
                    MessageBox.Show("File format not correct");
                    conExcel.Close();
                    return;
                }

                generateAppStart();

                if (dtExcelData.Rows.Count > 0)
                {
                    UploadToDB(iTempIndex, dtExcelData);
                    conExcel.Close();

                }


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        //private static int getRegNumber()
        //{
        //    try
        //    {
        //        DataTable dtNum = new DataTable();
        //        int iNum = 0;
        //        string strRegNum = "select Id from startId where Description = 'VU_RegNo';";
        //        dtNum = GetData(strRegNum);
        //        if(dtNum.Rows.Count>0)
        //        {
        //            foreach(DataRow row in dtNum.Rows)
        //            {
        //                iNum = Convert.ToInt32(row["Id"]);
        //            }

        //        }
        //        //int iNew = iNum + 1; 
        //        //string strSetRegNum = "Update startId set Id = "+ iNew .ToString() + " where Description = 'VU_RegNo';";
        //        //ExcuteDML(strSetRegNum);

        //        return iNum;
        //    }
        //    catch (Exception Ex)
        //    {
        //        MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
        //        return 0;
        //    }
        //}


        /// <summary>
        /// Get pre-defined number of columns from lpo_templatemaster table
        /// </summary>
        /// <param name="iTempIndex">Selected index of Template</param>
        /// <returns></returns>
        public static int getExcelColcnt(int iTempIndex)
        {
            try
            {
                DataTable dtExcelCnt = new DataTable();
                int iCnt = 0;
                string strExcelColcntQry = "select ExcelColCount from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                dtExcelCnt = GetData(strExcelColcntQry);
                if (dtExcelCnt.Rows.Count > 0)
                {
                    foreach (DataRow row in dtExcelCnt.Rows)
                    {
                        iCnt = Convert.ToInt32(row["ExcelColCount"]);
                    }
                }
                return iCnt;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return 0;
            }
        }


        /// <summary>
        /// Generate AppStart Number and BatchID for each file, for that day.
        /// Appstart number will change on daily basis only.
        /// </summary>
        internal static void generateAppStart()
        {
            DataTable dtFileUploadLog = new DataTable();
            string strUploadDate = string.Empty;
            string strBatchId = string.Empty;
            string strNumberofRecords = string.Empty;
            string strApp = string.Empty;
            try
            {
                string strAppStartQry = "select FileName, UploadDate, BatchId, AppStartNo,NumberofRecords" +
                     " from vu_fileuploadlog order by ID desc limit 1;";
                dtFileUploadLog = GetData(strAppStartQry);
                if (dtFileUploadLog.Rows.Count > 0)
                {
                    foreach (DataRow row in dtFileUploadLog.Rows)
                    {
                        strUploadDate = row["UploadDate"].ToString();
                        strBatchId = row["BatchId"].ToString();
                        strNumberofRecords = row["NumberofRecords"].ToString();
                        strApp = row["AppStartNo"].ToString();
                    }


                    DateTime dtUpload = Convert.ToDateTime(strUploadDate);
                    DateTime dtToday = DateTime.Now;

                    if (dtToday.Date > dtUpload.Date)
                    {
                        string strYr = DateTime.Now.Year.ToString();
                        string strDay = DateTime.Now.DayOfYear.ToString();
                        const string const_strAppNo = "0000001";

                        if (strDay.Length == 2)
                        {
                            strDay = "0" + strDay;
                        }
                        else if (strDay.Length == 1)
                        {
                            strDay = "00" + strDay;
                        }
                        strGlbAppstartID = strYr + strDay + const_strAppNo;
                        int iBatch = 1;
                        strGlbBatchID = iBatch.ToString();

                        return;
                    }
                    else
                    {
                        double iBatch = Convert.ToDouble(strBatchId) + 1;
                        strGlbBatchID = iBatch.ToString();
                        //double iAppNo  = Convert.ToDouble(strApp) + Convert.ToDouble(strNumberofRecords);
                        //strGlbAppstartID = iAppNo.ToString();
                        strGlbAppstartID = strApp;
                    }
                }


                else
                {
                    string strYr = DateTime.Now.Year.ToString();
                    string strDay = DateTime.Now.DayOfYear.ToString();
                    const string const_strAppNo = "0000001";

                    if (strDay.Length == 2)
                    {
                        strDay = "0" + strDay;
                    }
                    else if (strDay.Length == 1)
                    {
                        strDay = "00" + strDay;
                    }
                    strGlbAppstartID = strYr + strDay + const_strAppNo;
                    strGlbBatchID = "1";
                }



            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        /// <summary>
        /// Contains all functions to Upload ExcelData to Tables
        /// </summary>
        /// <param name="iTempIndex">Selected index of Template</param>
        /// <param name="dtExcelData">Excel Data</param>
        /// 
        private static void UploadToDB(int iTempIndex, DataTable dtExcelData)
        {
            DataTable dtTables = new DataTable();

            try
            {
                //getSRNumber(strGlbFileName);


                int iRowCont = dtExcelData.Rows.Count;
                strGlbTemplateName = string.Empty;


                string strGetTableQry = "select TemplateName, UploadTableName, UploadTableNameSuccess, " +
                "UploadTableNameFailed, TemplateID, CurRegNo, RegNoTO from lpo_templatemaster where TemplateID = " + iTempIndex.ToString();
                dtTables = GetData(strGetTableQry);
                if (dtTables.Rows.Count > 0)
                {
                    foreach (DataRow row in dtTables.Rows)
                    {
                        strGlbTemplateName = row["TemplateName"].ToString();
                        iGlbRegNo = Convert.ToInt32(row["CurRegNo"]);
                        fillSpDispatchArrayList();




                        strGlbUploadTbl = row["UploadTableName"].ToString();
                        InsertIntoUploadtbl(iTempIndex, strGlbUploadTbl, dtExcelData);


                        //6 Months Validation
                        DBHelper objHelper = new DBHelper();
                        objHelper.ExecuteNonQuery("call SP_SIXmonth_val ('" + strGlbTemplateName + "')",
                            CommandType.StoredProcedure);
                        objHelper = null;



                        strGlbUploadSuccess = row["UploadTableNameSuccess"].ToString();

                        if (strGlbTemplateName == "DLN" || strGlbTemplateName == "SARL"
                            || strGlbTemplateName == "DLNSEG" || strGlbTemplateName == "DLNHARD"
                            || strGlbTemplateName == "DLNPP" || strGlbTemplateName == "LRN")
                        {
                            DataTable dtDispMode = new DataTable();
                            string strCondition = string.Empty;
                            DataTable dtCondition = new DataTable();
                            string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                            dtCondition = GetData(strValidation);
                            if (dtCondition.Rows.Count > 0)
                            {
                                strCondition = dtCondition.Rows[0]["validation"].ToString();
                            }

                            string strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'SP' Order by VU_AppPincode";
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            }

                            strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'REG' Order by VU_AppPincode";
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            }
                        }


                        else if (strGlbTemplateName == "SARFCBSS" || strGlbTemplateName == "SARFCBUS")
                        {
                            //bool bflag = false;
                            string strDisp = string.Empty;
                            DataTable dtDispMode = new DataTable();
                            string strCondition = string.Empty;
                            DataTable dtCondition = new DataTable();
                            string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                            dtCondition = GetData(strValidation);
                            if (dtCondition.Rows.Count > 0)
                            {
                                strCondition = dtCondition.Rows[0]["validation"].ToString();
                            }

                            strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition;
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            }

                        }

                        else if (strGlbTemplateName == "SARF13_2_IB")
                        {
                            //bool bflag = false;
                            string strDisp = string.Empty;
                            DataTable dtDispMode = new DataTable();
                            string strCondition = string.Empty;
                            DataTable dtCondition = new DataTable();
                            string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                            dtCondition = GetData(strValidation);
                            if (dtCondition.Rows.Count > 0)
                            {
                                strCondition = dtCondition.Rows[0]["validation"].ToString();
                            }

                            strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition;
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            }

                        }


                        else if (strGlbTemplateName == "VPN")
                        {
                            //bool bflag = false;
                            string strDisp = string.Empty;
                            DataTable dtDispMode = new DataTable();
                            string strCondition = string.Empty;
                            DataTable dtCondition = new DataTable();
                            string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                            dtCondition = GetData(strValidation);
                            if (dtCondition.Rows.Count > 0)
                            {
                                strCondition = dtCondition.Rows[0]["validation"].ToString();
                            }

                            strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition;
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            }

                        }
                        else if (strGlbTemplateName == "LRNA")
                        {
                            bool bflag = false;
                            DataTable dtDispMode = new DataTable();
                            string strCondition = string.Empty;
                            DataTable dtCondition = new DataTable();
                            string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                            dtCondition = GetData(strValidation);
                            if (dtCondition.Rows.Count > 0)
                            {
                                strCondition = dtCondition.Rows[0]["validation"].ToString();
                            }

                            string strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'SP' ";
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                bflag = true;
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            }

                            if (bflag)
                            {
                                int i = 1;
                                strGlbAppstartID = (Convert.ToInt64(strGlbAppstartID) + i).ToString();
                                bflag = false;
                            }

                            strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'REG' ";
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            }
                        }


                        else if (strGlbTemplateName == "LRNAML")
                        {
                            bool bflag = false;
                            DataTable dtDispMode = new DataTable();
                            string strCondition = string.Empty;
                            DataTable dtCondition = new DataTable();
                            string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                            dtCondition = GetData(strValidation);
                            if (dtCondition.Rows.Count > 0)
                            {
                                strCondition = dtCondition.Rows[0]["validation"].ToString();
                            }

                            string strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'SP' ";
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                bflag = true;
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);

                            }

                            if (bflag)
                            {
                                int i = 1;
                                strGlbAppstartID = (Convert.ToInt64(strGlbAppstartID) + i).ToString();
                                bflag = false;
                            }

                            strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'REG' ";
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            }
                        }



                        else if (strGlbTemplateName == "ODRN"  || strGlbTemplateName == "ODRS")
                        {
                            //bool bflag = false;
                            string strDisp = string.Empty;
                            DataTable dtDispMode = new DataTable();
                            string strCondition = string.Empty;
                            DataTable dtCondition = new DataTable();
                            string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                            dtCondition = GetData(strValidation);
                            if (dtCondition.Rows.Count > 0)
                            {
                                strCondition = dtCondition.Rows[0]["validation"].ToString();
                            }

                            if (strGlbOdrnDispType == "SP")
                            {
                                strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'SP' ";
                                dtDispMode = GetData(strDisp);
                                if (dtDispMode.Rows.Count > 0)
                                {
                                    //bflag = true;
                                    InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);

                                }
                            }

                      
                            if (strGlbOdrnDispType == "REG")
                            {
                                strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'REG' ";
                                dtDispMode = GetData(strDisp);
                                if (dtDispMode.Rows.Count > 0)
                                {
                                    InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                                }
                            }
                        }


                        else if (strGlbTemplateName == "DLNAML")
                        {
                            DataTable dtDispMode = new DataTable();
                            string strCondition = string.Empty;
                            DataTable dtCondition = new DataTable();
                            string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                            dtCondition = GetData(strValidation);
                            if (dtCondition.Rows.Count > 0)
                            {
                                strCondition = dtCondition.Rows[0]["validation"].ToString();
                            }

                            string strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where " + strCondition;
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            }

                            int i = 1;
                            strGlbAppstartID = (Convert.ToInt64(strGlbAppstartID) + i).ToString();

                            //strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'REG' ";
                            //dtDispMode = GetData(strDisp);
                            //if (dtDispMode.Rows.Count > 0)
                            //{
                            //    InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            //}
                        }


                        else if (strGlbTemplateName == "SAWN")
                        {
                            DataTable dtDispMode = new DataTable();
                            string strCondition = string.Empty;
                            DataTable dtCondition = new DataTable();
                            string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                            dtCondition = GetData(strValidation);
                            if (dtCondition.Rows.Count > 0)
                            {
                                strCondition = dtCondition.Rows[0]["validation"].ToString();
                            }

                            //string strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where " + strCondition;
                            //dtDispMode = GetData(strDisp);
                            //if (dtDispMode.Rows.Count > 0)
                            //{
                            //    InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                            //}

                            //int i = 1;
                            //strGlbAppstartID = (Convert.ToInt64(strGlbAppstartID) + i).ToString();

                            string strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition ;
                            dtDispMode = GetData(strDisp);
                            if (dtDispMode.Rows.Count > 0)
                            {
                                InsertIntoSuccessChanged(iTempIndex, strGlbUploadSuccess, dtDispMode);
                                //int i = 1;
                                //strGlbAppstartID = (Convert.ToInt64(strGlbAppstartID) + i).ToString();
                            }
                        }

                        else
                        {
                            InsertIntoSuccess(iTempIndex, strGlbUploadSuccess);
                        }



                        //if (strGlbTemplateName != "DLN")
                        //{
                        //    InsertIntoSuccess(iTempIndex, strGlbUploadSuccess, dtExcelData);
                        //}
                        //if(strGlbTemplateName == "DLN")
                        //{
                        //    string strDisp = "select " + strGlbCol + " where VU_DispatchMode = 'SP'";
                        //    dtExcelData = GetData(strDisp);
                        //    InsertIntoSuccess(iTempIndex, strGlbUploadSuccess, dtExcelData);

                        //    strDisp = "select " + strGlbCol + " where VU_DispatchMode = 'REG'";
                        //    dtExcelData = GetData(strDisp);
                        //    InsertIntoSuccess(iTempIndex, strGlbUploadSuccess, dtExcelData);
                        //}





                        if (strGlbTemplateName == "DLNA" || strGlbTemplateName == "LRNA" || strGlbTemplateName == "VPN"
                            || strGlbTemplateName == "DLNAML" || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "ODRN"
                            || strGlbTemplateName == "SAWN" || strGlbTemplateName == "SARFCBSS" || strGlbTemplateName == "ODRS"
                            || strGlbTemplateName == "SARF13_2_IB")
                        {
                            InsertIntoAnnexrTable("lpo_trnannexrpttbl");
                        }

                        strGlbUploadFailed = row["UploadTableNameFailed"].ToString();
                        InsertIntoFailedtbl(iTempIndex, strGlbUploadFailed);

                        int iSuccessCnt = 0;
                        //get Success Records
                        if (strGlbTemplateName != "DLN" || strGlbTemplateName != "SARL"
                                 || strGlbTemplateName != "DLNSEG" || strGlbTemplateName != "DLNHARD"
                                 || strGlbTemplateName != "DLNPP" || strGlbTemplateName != "LRN" || strGlbTemplateName != "LRNA")
                        {
                            iSuccessCnt = getSuccessCnt(strGlbUploadSuccess, strGlbFileName, strGlbTemplateName);
                            UpdateFileLog(strGlbFileName, strGlbAppstartID, strGlbBatchID, iSuccessCnt);

                        }

                        if (strGlbTemplateName == "DLNA")
                        {
                            iSuccessCnt = getSuccessCnt(strGlbUploadSuccess, strGlbFileName, strGlbTemplateName);
                            UpdateFileLog(strGlbFileName, strGlbAppstartID, strGlbBatchID, iSuccessCnt);

                        }
                        else
                        {
                            UpdateFileLog(strGlbFileName, strGlbAppstartID, strGlbBatchID, iSuccessCnt);

                        }

                        MessageBox.Show("File uploaded Successfully!");

                        CreateFolderStructure(strGlbPath);
                        bulkRegister(strGlbTemplateName);

                        MessageBox.Show("Completed");



                    }
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static int getSuccessCnt(string strGlbUploadSuccess, string strGlbFileName, string strGlbTemplateName)
        {
            int icntSuccess = 0;
            DataTable dtCnt = new DataTable();
            try
            {
                string strQry = "select * from " + strGlbUploadSuccess + " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "'  group by VU_MasterID";
                dtCnt = GetData(strQry);
                icntSuccess = dtCnt.Rows.Count;
                return icntSuccess;
            }
            catch (Exception Ex)
            {

                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return 0;
            }
            finally
            {
                dtCnt.Clear();
            }
        }



        private static void InsertIntoSuccessChanged(int iTempIndex, string strUploadSuccess, DataTable dtDispMode)
        {
            //"DLN", "SARL", "DLNSEG","LRNA","DLNAML","ODRN","SAWN","SARFCBSS", "ODRS","VPN"
            string testCol = "";
            htGlbVPNCustomer = new Hashtable();
            //DataTable dtUploadData = new DataTable();
            DataTable dtCondition = new DataTable();
            string strCondition = string.Empty;
            StringBuilder sbValues = new StringBuilder();


            //ArrayList al138ECSLanCheck = new ArrayList();
            Hashtable ht138ECSLanCheck = new Hashtable();

            Hashtable htRegNoCheck = new Hashtable();


            Hashtable ht138ECSNumCheck = new Hashtable();
            Hashtable ht138ECSRegNoCheck = new Hashtable();

            double dAppstart = Convert.ToDouble(strGlbAppstartID);
            double dAppLocal = Convert.ToDouble(strGlbAppstartID);
            double dRegNoLocal = Convert.ToDouble(iGlbRegNo);
            double dRegNostart = Convert.ToDouble(iGlbRegNo);

            string strColTest = string.Empty;

            Hashtable htLocal = new Hashtable();
            Hashtable htRegNoMapping = new Hashtable();


            string strRptTbl = "Truncate " + const_strReportTable;
            string strInsQry = "Insert into " + strUploadSuccess + "( " + strGlbCol + ") Values (";



            try
            {

                //string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                //dtCondition = GetData(strValidation);
                //if (dtCondition.Rows.Count > 0)
                //{
                //    strCondition = dtCondition.Rows[0]["validation"].ToString();
                //}

                //string strUploadqry = "select " + strGlbCol + " from " + strGlbUploadTbl + " where " + strCondition + " Order by VU_AppPincode";
                //dtUploadData = GetData(strUploadqry);

                //int itest = 0;

                foreach (DataRow dRow in dtDispMode.Rows)
                {

                    ArrayList alApplicants = new ArrayList();
                    bool bExecute = true;
                    foreach (DataColumn col in dtDispMode.Columns)
                    {
                        icntTest++;
                        //itest++;
                        bool bDate = false;
                        bool bLan = false;
                        string strColName = col.ColumnName;

                        strColTest = strColName;


                        string strColType = htGlbColTyp[strColName].ToString();
                        testCol = strColName;

                        if (strColName == "VU_MasterID" && (strGlbTemplateName == "LRN"
                            || strGlbTemplateName == "DLNHARD" || strGlbTemplateName == "DLNPP"
                            || strGlbTemplateName == "DLNVPN"))
                        {
                            sbValues.Append("'" + dAppstart.ToString() + "',");
                            dAppstart += 1;
                            continue;
                        }

                        else if (strColName == "VU_MasterID" && (strGlbTemplateName == "DLN"))
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_AppAdd1"].ToString().Trim() + "," + dRow["VU_OutstandingDues"].ToString().Trim()
                                + "," + dRow["VU_DuesAsOn"].ToString().Trim()))
                            {
                                ht138ECSLanCheck.Add(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                    + "," + dRow["VU_AppAdd1"].ToString().Trim() + "," + dRow["VU_OutstandingDues"].ToString().Trim()
                                    + "," + dRow["VU_DuesAsOn"].ToString().Trim(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }

                        }

                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "DLN"))
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_AppAdd1"].ToString().Trim() + "," + dRow["VU_OutstandingDues"].ToString().Trim()
                                + "," + dRow["VU_DuesAsOn"].ToString().Trim()))
                            {
                                ht138ECSRegNoCheck.Add(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_AppAdd1"].ToString().Trim() + "," + dRow["VU_OutstandingDues"].ToString().Trim()
                                + "," + dRow["VU_DuesAsOn"].ToString().Trim(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }

                        if (strColName == "VU_MasterID" && (strGlbTemplateName == "DLNSEG"))
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_TOTAMTDUE"].ToString().Trim() + "," + dRow["VU_MINAMTDUE"].ToString().Trim()))
                            {
                                ht138ECSLanCheck.Add(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                    + "," + dRow["VU_TOTAMTDUE"].ToString().Trim() + "," + dRow["VU_MINAMTDUE"].ToString().Trim(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }
                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "SARFCBUS")
                        {

                            if (!htRegNoCheck.Contains(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_UnSecLan"]))
                            {
                                htRegNoCheck.Add(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_UnSecLan"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dRegNostart += 1;
                                continue;

                            }

                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }

                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "DLNSEG"))
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_TOTAMTDUE"].ToString().Trim() + "," + dRow["VU_MINAMTDUE"].ToString().Trim()))
                            {
                                ht138ECSRegNoCheck.Add(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_TOTAMTDUE"].ToString().Trim() + "," + dRow["VU_MINAMTDUE"].ToString().Trim(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "SARF13_2_IB")
                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_MORT_NAME"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_MORT_NAME"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }

                        else if (strGlbTemplateName == "SARF13_2_IB" && strColName == "VU_LANNo")
                        {
                            bLan = ClsValidations.LanValidate(dRow[strColName].ToString(), strGlbTemplateName);

                            if (bLan)
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }

                        #region SARF13_2_IB MasterID

                        if (strColName == "VU_MasterID" && (strGlbTemplateName == "SARF13_2_IB"))
                        {
                            if (dRow["VU_ApplicantName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_ApplicantName"].ToString());
                                if (!htLocal.Contains(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }
                            }

                            if (dRow["VU_CoApplicantName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_CoApplicantName"].ToString());
                                if (!htLocal.Contains(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }
                            }

                            if (dRow["VU_GurName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_GurName"].ToString());
                                if (!htLocal.Contains(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }

                            if (dRow["VU_MORT_NAME"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_MORT_NAME"].ToString());
                                if (!htLocal.Contains(dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }

                            if (!htGlbVPNCustomer.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_MORT_NAME"] + "," + dRow["VU_LANNo"]))
                            {
                                htGlbVPNCustomer.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_MORT_NAME"] + "," + dRow["VU_LANNo"], dAppstart.ToString());

                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;                                
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        #endregion

                        #region SARFCBUS MasterID
                        if (strColName == "VU_MasterID" && (strGlbTemplateName == "SARFCBUS"))
                        {
                            if (dRow["VU_BorrowerName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_BorrowerName"].ToString());
                                if (!htLocal.Contains(dRow["VU_BorrowerName"]))
                                {
                                    htLocal.Add(dRow["VU_BorrowerName"], dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_BorrowerName"]))
                                {
                                    htRegNoMapping.Add(dRow["VU_BorrowerName"], dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }


                            }
                            if (dRow["VU_CoBorrowerName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_CoBorrowerName"].ToString());
                                if (!htLocal.Contains(dRow["VU_CoBorrowerName"]))
                                {
                                    htLocal.Add(dRow["VU_CoBorrowerName"], dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_CoBorrowerName"]))
                                {
                                    htRegNoMapping.Add(dRow["VU_CoBorrowerName"], dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }


                            if (dRow["VU_GurName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_GurName"].ToString());
                                if (!htLocal.Contains(dRow["VU_GurName"]))
                                {
                                    htLocal.Add(dRow["VU_GurName"], dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_GurName"]))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurName"], dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }



                            if (!htGlbVPNCustomer.Contains(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_UnSecLan"]))
                            {
                                htGlbVPNCustomer.Add(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_UnSecLan"], dAppstart.ToString());

                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;                                
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        #endregion

                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "CIBILAN")
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["VU_AppAdd1"].ToString().Trim()))
                            {
                                ht138ECSLanCheck.Add(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["VU_AppAdd1"].ToString().Trim(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["VU_AppAdd1"].ToString().Trim()].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                                continue;
                            }

                        }



                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "SARL")
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_SanctionedAmt"].ToString().Trim() + "," + dRow["VU_DuesAsON"].ToString().Trim()))
                            {
                                ht138ECSLanCheck.Add(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_SanctionedAmt"].ToString().Trim() + "," + dRow["VU_DuesAsON"].ToString().Trim(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }

                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "SARL")
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_SanctionedAmt"].ToString().Trim() + "," + dRow["VU_DuesAsON"].ToString().Trim()))
                            {
                                ht138ECSRegNoCheck.Add(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["vu_LanNo"].ToString().Trim()
                                + "," + dRow["VU_SanctionedAmt"].ToString().Trim() + "," + dRow["VU_DuesAsON"].ToString().Trim(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }

                        }

                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "DLNVPNML")
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim()))
                            {
                                ht138ECSLanCheck.Add(dRow["vu_ApplicantName"].ToString().Trim(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["vu_ApplicantName"].ToString().Trim()].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                                continue;
                            }

                        }

                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "DLNML")
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["vu_ApplicantName"]))
                            {
                                ht138ECSLanCheck.Add(dRow["vu_ApplicantName"], dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["vu_ApplicantName"]].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                                continue;
                            }

                        }



                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "DLNML")
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["vu_ApplicantName"]))
                            {
                                ht138ECSRegNoCheck.Add(dRow["vu_ApplicantName"], iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                string strRegNo = ht138ECSRegNoCheck[dRow["vu_ApplicantName"]].ToString();
                                sbValues.Append("'" + strRegNo + "',");
                                continue;
                            }

                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "CIBILAN")
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["vu_ApplicantName"] + "," + dRow["VU_AppAdd1"]))
                            {
                                ht138ECSRegNoCheck.Add(dRow["vu_ApplicantName"] + "," + dRow["VU_AppAdd1"], iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                string strRegNo = ht138ECSRegNoCheck[dRow["vu_ApplicantName"] + "," + dRow["VU_AppAdd1"]].ToString();
                                sbValues.Append("'" + strRegNo + "',");
                                continue;
                            }

                        }

                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "138HFC")
                        {
                            if (!ht138ECSNumCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_LANNO"] + "," + dRow["VU_BOU_ChqNo"]))
                            {
                                ht138ECSNumCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_LANNO"] + "," + dRow["VU_BOU_ChqNo"], dAppstart.ToString());
                                //sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;
                                //continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }

                            if (!ht138ECSLanCheck.Contains(dRow["VU_ApplicantName"].ToString()))
                            {
                                ht138ECSLanCheck.Add(dRow["VU_ApplicantName"].ToString(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["VU_ApplicantName"]].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                            }


                        }


                        else if (strColName == "VU_MasterID" &&
                            (strGlbTemplateName == "138ECS"))
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["VU_LANNO"].ToString()))
                            {
                                ht138ECSLanCheck.Add(dRow["VU_LANNO"].ToString(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["VU_LANNO"]].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                            }


                            if (!ht138ECSNumCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_LANNO"] + "," + dRow["VU_BOUECSNO"]))
                            {
                                ht138ECSNumCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_LANNO"] + "," + dRow["VU_BOUECSNO"], dAppstart.ToString());
                                //sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }


                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "138ECS"
                             || strGlbTemplateName == "138HFC"
                            ))
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["VU_LANNO"].ToString()))
                            {
                                ht138ECSRegNoCheck.Add(dRow["VU_LANNO"].ToString(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                string strRegNo = ht138ECSRegNoCheck[dRow["VU_LANNO"]].ToString();
                                sbValues.Append("'" + strRegNo + "',");
                                continue;
                            }

                        }


                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "DLNA")
                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }


                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "ODRS")
                        {
                            if (!htRegNoCheck.Contains(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," +
                                 dRow["VU_MortgagorName"] + "," + dRow["VU_GurMortgagorName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," +
                                 dRow["VU_MortgagorName"] + "," + dRow["VU_GurMortgagorName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "ODRN")
                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "LRNA")
                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_GurName"].ToString().Trim()
                                + "," + dRow["VU_LanNo"].ToString().Trim()))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_GurName"].ToString().Trim()
                                + "," + dRow["VU_LanNo"].ToString().Trim(), dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "SARFCBSS")
                        {

                            if (!htRegNoCheck.Contains(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_BadSecLan"]))
                            {
                                htRegNoCheck.Add(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_BadSecLan"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dRegNostart += 1;
                                continue;

                            }

                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }


                        #region ODRS MasterID
                        if (strColName == "VU_MasterID" && strGlbTemplateName == "ODRS")
                        {
                            if (dRow["VU_BorrowerName"].ToString().Trim() != "")
                            {
                                alApplicants.Add(dRow["VU_BorrowerName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_BorrowerName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_BorrowerName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_BorrowerName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_BorrowerName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }


                            }
                            if (dRow["VU_CoBorrowerName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_CoBorrowerName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_CoBorrowerName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_CoBorrowerName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_CoBorrowerName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_CoBorrowerName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }


                            if (dRow["VU_GurName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_GurName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_GurName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }

                            if (dRow["VU_MortgagorName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_MortgagorName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_MortgagorName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_MortgagorName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_MortgagorName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_MortgagorName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }
                            if (dRow["VU_GurMortgagorName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_GurMortgagorName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_GurMortgagorName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_GurMortgagorName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_GurMortgagorName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurMortgagorName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }



                            if (!htGlbVPNCustomer.Contains(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," +
                                 dRow["VU_MortgagorName"] + "," + dRow["VU_GurMortgagorName"] + "," + dRow["VU_LanNo"]))
                            {
                                htGlbVPNCustomer.Add(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," +
                                 dRow["VU_MortgagorName"] + "," + dRow["VU_GurMortgagorName"] + "," + dRow["VU_LanNo"], dAppstart.ToString());

                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;                                
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        #endregion


                        #region SARFCBSS MasterID
                        if (strColName == "VU_MasterID" && (strGlbTemplateName == "SARFCBSS"))
                        {
                            if (dRow["VU_BorrowerName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_BorrowerName"].ToString());
                                if (!htLocal.Contains(dRow["VU_BorrowerName"]))
                                {
                                    htLocal.Add(dRow["VU_BorrowerName"], dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_BorrowerName"]))
                                {
                                    htRegNoMapping.Add(dRow["VU_BorrowerName"], dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }


                            }
                            if (dRow["VU_CoBorrowerName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_CoBorrowerName"].ToString());
                                if (!htLocal.Contains(dRow["VU_CoBorrowerName"]))
                                {
                                    htLocal.Add(dRow["VU_CoBorrowerName"], dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_CoBorrowerName"]))
                                {
                                    htRegNoMapping.Add(dRow["VU_CoBorrowerName"], dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }


                            if (dRow["VU_GurName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_GurName"].ToString());
                                if (!htLocal.Contains(dRow["VU_GurName"]))
                                {
                                    htLocal.Add(dRow["VU_GurName"], dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_GurName"]))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurName"], dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }



                            if (!htGlbVPNCustomer.Contains(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_BadSecLan"]))
                            {
                                htGlbVPNCustomer.Add(dRow["VU_BorrowerName"] + "," + dRow["VU_CoBorrowerName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_BadSecLan"], dAppstart.ToString());

                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;                                
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        #endregion


                        #region VPN MasterID
                        if (strColName == "VU_MasterID" && (strGlbTemplateName == "VPN"                             
                             || strGlbTemplateName == "SAWN"))
                        {
                            if (dRow["VU_ApplicantName"].ToString().Trim() != "")
                            {
                                alApplicants.Add(dRow["VU_ApplicantName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }


                            }
                            if (dRow["VU_CoApplicantName"].ToString().Trim() != "")
                            {
                                alApplicants.Add(dRow["VU_CoApplicantName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_CoApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_CoApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_CoApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_CoApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }


                            if (dRow["VU_GurName"].ToString().Trim() != "")
                            {
                                alApplicants.Add(dRow["VU_GurName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_GurName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }



                            if (!htGlbVPNCustomer.Contains(dRow["VU_ApplicantName"].ToString().Trim() + "," +
                                dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_LanNo"].ToString().Trim()))
                            {
                                htGlbVPNCustomer.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," +
                                    dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_GurName"].ToString().Trim() + "," +
                                    dRow["VU_LanNo"].ToString().Trim(), dAppstart.ToString());

                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        #endregion


                        #region LRNA MasterID
                        if (strColName == "VU_MasterID" && (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA" || strGlbTemplateName == "DLNAML"||strGlbTemplateName == "LRNAML"
                            || strGlbTemplateName == "ODRN"))
                        {
                            if (dRow["VU_ApplicantName"].ToString().Trim() != "")
                            {
                                alApplicants.Add(dRow["VU_ApplicantName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_ApplicantName"].ToString().Trim()+ ","+dRow["VU_ApplicantName"].ToString().Trim()
                                    ))
                                {
                                    htLocal.Add(dRow["VU_ApplicantName"].ToString().Trim()
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim() , dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()
                                    ))
                                {
                                    htRegNoMapping.Add(dRow["VU_ApplicantName"].ToString().Trim()
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()
                                        , dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }


                            }
                            if (dRow["VU_CoApplicantName"].ToString().Trim() != "")
                            {
                                alApplicants.Add(dRow["VU_CoApplicantName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_CoApplicantName"].ToString().Trim()
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim() , dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_CoApplicantName"].ToString().Trim()
                                    + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_CoApplicantName"].ToString().Trim()
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }


                            if (dRow["VU_GurName"].ToString().Trim() != "")
                            {
                                alApplicants.Add(dRow["VU_GurName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_GurName"].ToString().Trim()
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }



                            if (!htGlbVPNCustomer.Contains(dRow["VU_ApplicantName"].ToString().Trim() + "," +
                                dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_LanNo"].ToString().Trim()))
                            {
                                htGlbVPNCustomer.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," + 
                                    dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_GurName"].ToString().Trim() + "," +
                                    dRow["VU_LanNo"].ToString().Trim(), dAppstart.ToString());

                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        #endregion

                        else if (strColName == "VU_DispatchMode" && (strGlbTemplateName == "SARL"
                            || strGlbTemplateName == "DLNHARD" || strGlbTemplateName == "DLNPP"
                            || strGlbTemplateName == "DLNSEG"))
                        {
                            if (alSpList.Contains(dRow["VU_AppPincode"].ToString()))
                            {
                                sbValues.Append("'SP',");
                                continue;
                            }
                            else
                            {
                                sbValues.Append("'REG',");
                                continue;
                            }
                        }


                        else if (strColName == "VU_DispatchMode" && (strGlbTemplateName == "LRN"
                            || strGlbTemplateName == "LRNA" || strGlbTemplateName == "LRNAML"
                            ))
                        {
                            if (Convert.ToDouble(dRow["VU_TotalForclosureAmt"]) >= 500000)
                            {
                                sbValues.Append("'SP',");
                                continue;
                            }
                            else
                            {
                                sbValues.Append("'REG',");
                                continue;
                            }
                        }

                        else if (strColName == "VU_DispatchMode"
                           && (strGlbTemplateName == "138ECS" || strGlbTemplateName == "SEC138"
                           || strGlbTemplateName == "138HFC" || strGlbTemplateName == "SARF13_2_IB"))
                        {
                            sbValues.Append("'SP',");
                            continue;
                        }



                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "SAWN")

                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "DLNAML")

                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "VPN")

                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "LRNAML")

                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        else if (strColName == "VU_DispatchMode"
                            && (strGlbTemplateName == "VPN" || strGlbTemplateName == "CIBILAN"
                            || strGlbTemplateName == "DLNA" || strGlbTemplateName == "DLNML"
                            || strGlbTemplateName == "DLNAML" || strGlbTemplateName == "DLNVPN"
                            || strGlbTemplateName == "DLNVPNML" || strGlbTemplateName == "SAWN" || strGlbTemplateName == "SARFCBSS"
                           || strGlbTemplateName == "SARFCBUS"))
                        {
                            sbValues.Append("'REG',");
                            continue;

                        }
                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "LRN"
                            || strGlbTemplateName == "DLNHARD" || strGlbTemplateName == "DLNPP"
                            || strGlbTemplateName == "CIBILAN"))
                        {
                            sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                            iGlbRegNo += 1;
                            continue;
                        }


                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "DLNVPN" || strGlbTemplateName == "DLNVPNML"
                            || strGlbTemplateName == "DLNML"))
                        {
                            //if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            //{
                            //    htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dAppstart.ToString());

                            //    sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                            //    //dAppstart += 1;
                            //    continue;

                            //}
                            //else
                            //{
                            //    bExecute = false;
                            //    sbValues.Clear();
                            //    break;

                            //}

                            sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                            iGlbRegNo += 1;
                            continue;

                        }


                        else if (strColType == "Date")
                        {
                            bDate = ClsValidations.DateValidate(dRow[strColName].ToString(), strGlbTemplateName);
                            if (bDate)
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }

                        else if (strGlbTemplateName == "SARFCBUS" && strColName == "VU_UnSecLan")
                        {
                            bLan = ClsValidations.LanValidate(dRow[strColName].ToString(), strGlbTemplateName);
                            if (bLan)
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }
                        else if (strColType == "LAN")
                        {
                            bLan = ClsValidations.LanValidate(dRow[strColName].ToString(), strGlbTemplateName);


                            if (bLan)
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }

                        else if (strColType == "LANMASK")
                        {
                            if(strGlbTemplateName == "SARFCBSS" || strGlbTemplateName == "SARFCBUS")
                            {
                                sbValues.Append("'',");
                                continue;
                            }
                            string strLanMask = dRow["VU_LanNo"].ToString();
                            if (Regex.IsMatch(strLanMask, @"^[0-9]") && strLanMask.Length > 12)
                            {
                                string strLanReplace = Regex.Replace(strLanMask.Substring(3, strLanMask.Length - 7), ".", "X");
                                string strFinalLan = strLanMask.Substring(0, 4) +
                                    strLanReplace.Substring(1, strLanReplace.Length - 1) + strLanMask.Substring(strLanMask.Length - 4);
                                sbValues.Append("'" + strFinalLan + "',");

                            }

                            else
                            {
                                sbValues.Append("'" + strLanMask + "',");
                            }

                        }

                        else
                        {
                            // string str = dRow[strColName].ToString();
                            sbValues.Append("'" + dRow[strColName].ToString() + "',");
                        }


                    }
                    if (bExecute)
                    {


                        // string strTest = strColTest;
                        string strMasterID = string.Empty;
                        string strRegNoNew = string.Empty;






                        string strInsert = strInsQry + sbValues.ToString();

                        //sbValues.Replace()
                        strInsert = strInsert.Remove(strInsert.LastIndexOf(","));
                        strInsert += ")";

                        string strAppp = dAppstart.ToString();
                        string strRegNo = dRegNostart.ToString();
                        int iRegUpload = 0;

                        #region VPN Upload logic

                        if (strGlbTemplateName == "VPN"  
                             
                            || strGlbTemplateName == "SAWN")
                        {
                            string strDeletermp;
                            if (alApplicants.Count == 1)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim()))
                                {

                                    if (strGlbTemplateName == "SAWN")
                                    {
                                        iRegUpload++;
                                        iGlbRegNo++;
                                        string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                        strInsert = strInsert.Replace(strAppp, strApppReplace);

                                        //string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                        //strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                        strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                        string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                        strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                        ExcuteDML(strInsert);
                                        strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                        ExcuteDML(strDeletermp);


                                        strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim()].ToString();



                                        //iGlbRegNo++;
                                        strMasterID = strApppReplace;
                                        strRegNoNew = iGlbRegNo.ToString();
                                    }

                                    else
                                    {
                                        iRegUpload++;

                                        string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                        strInsert = strInsert.Replace(strAppp, strApppReplace);

                                        //string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                        //strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                        strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                        ExcuteDML(strInsert);
                                        strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                        ExcuteDML(strDeletermp);


                                        strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim()].ToString();



                                        iGlbRegNo++;
                                        strMasterID = strApppReplace;
                                        strRegNoNew = iGlbRegNo.ToString();
                                    }
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }
                            }
                            if (alApplicants.Count == 2)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()].ToString();




                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim()].ToString();


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    //strApppReplace = htLocal[dRow["VU_CoApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}


                                }


                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }

                                else
                                {

                                }
                            }

                            if (alApplicants.Count == 3)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim()))
                                {

                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}

                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);


                                    strRegNo = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }

                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[1].ToString() + "','dummy'", alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_CoApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }


                                else
                                {

                                }
                            }






                            //dAppstart += alApplicants.Count;

                            //dRegNostart += iRegUpload;

                            ////dRegNostart += alApplicants.Count;
                            ////iGlbRegNo += alApplicants.Count;
                            //iGlbRegNo += iRegUpload;


                            if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA"
                                || strGlbTemplateName == "DLNAML" || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "ODRN"
                                || strGlbTemplateName == "SAWN" || strGlbTemplateName == "VPN")
                            {
                                //strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(alApplicants.Count)).ToString();

                                //strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(iRegUpload)).ToString();
                                strGlbAppstartID = strMasterID;
                                iGlbRegNo = Convert.ToInt32(strRegNoNew);
                            }

                        }
                        #endregion

                        #region LRNA Upload logic

                        if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA" || strGlbTemplateName == "DLNAML" || strGlbTemplateName == "LRNAML"
                            || strGlbTemplateName == "ODRN")
                        {
                            string strDeletermp;
                            if (alApplicants.Count == 1)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {

                                    if (strGlbTemplateName == "SAWN")
                                    {
                                        iRegUpload++;
                                        iGlbRegNo++;
                                        string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim()
                                             + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                        strInsert = strInsert.Replace(strAppp, strApppReplace);

                                        //string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                        //strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                        strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString()+","+alApplicants[0].ToString() + "','dummy'");


                                        string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()
                                             + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                        strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                        ExcuteDML(strInsert);
                                        strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                        ExcuteDML(strDeletermp);


                                        strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim()
                                             + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();



                                        //iGlbRegNo++;
                                        strMasterID = strApppReplace;
                                        strRegNoNew = iGlbRegNo.ToString();
                                    }

                                    else
                                    {
                                        iRegUpload++;

                                        string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim()
                                             + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                        strInsert = strInsert.Replace(strAppp, strApppReplace);

                                        //string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                        //strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                        strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString()+","+ alApplicants[0].ToString() + "','dummy'");


                                        ExcuteDML(strInsert);
                                        strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                        ExcuteDML(strDeletermp);


                                        strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim()
                                             + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();



                                        iGlbRegNo++;
                                        strMasterID = strApppReplace;
                                        strRegNoNew = iGlbRegNo.ToString();
                                    }
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }
                            }
                            if (alApplicants.Count == 2)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim()
                                     + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();




                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim()
                                     + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    //strApppReplace = htLocal[dRow["VU_CoApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}


                                }


                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()
                                     + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_ApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }

                                else
                                {

                                }
                            }

                            if (alApplicants.Count == 3)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim()
                                     + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {

                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}

                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim()
                                     + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);


                                    strRegNo = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }

                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()
                                     + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_CoApplicantName"].ToString().Trim()
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }


                                else
                                {

                                }
                            }






                            //dAppstart += alApplicants.Count;

                            //dRegNostart += iRegUpload;

                            ////dRegNostart += alApplicants.Count;
                            ////iGlbRegNo += alApplicants.Count;
                            //iGlbRegNo += iRegUpload;


                            if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA"
                                || strGlbTemplateName == "DLNAML" || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "ODRN"
                                || strGlbTemplateName == "SAWN")
                            {
                                //strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(alApplicants.Count)).ToString();

                                //strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(iRegUpload)).ToString();
                                strGlbAppstartID = strMasterID;
                                iGlbRegNo = Convert.ToInt32(strRegNoNew);
                            }

                        }
                        #endregion


                        #region SARF13_2_IB Upload logic

                        else if (strGlbTemplateName == "SARF13_2_IB")
                        {
                            string strDeletermp;
                            if (alApplicants.Count == 1)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    iGlbRegNo++;

                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);


                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);
                                    ExcuteDML(strInsert);

                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = iGlbRegNo.ToString();
                                }
                            }
                            if (alApplicants.Count == 2)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();


                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }
                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);

                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(); strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }


                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                }

                                if (htLocal.ContainsKey(dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[3].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                }
                            }

                            if (alApplicants.Count == 3)
                            {
                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();


                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }

                                else
                                {

                                }
                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);

                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(); strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }

                                else
                                {

                                }
                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                }

                                if (htLocal.ContainsKey(dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[3].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                }

                            }

                            if (alApplicants.Count == 4)
                            {
                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();


                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }

                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);

                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);
                                    strAppp = htLocal[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }
                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);

                                    strAppp = htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                }

                                if (htLocal.ContainsKey(dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();


                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[3].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_MORT_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                }
                            }


                            if (strGlbTemplateName == "SARF13_2_IB")
                            {
                                strGlbAppstartID = strMasterID;
                                iGlbRegNo = Convert.ToInt32(strRegNoNew);
                            }

                        }
                        #endregion


                        #region SARFCBSS Upload logic

                        else if (strGlbTemplateName == "SARFCBSS" || strGlbTemplateName == "SARFCBUS")
                        {
                            string strDeletermp;
                            if (alApplicants.Count == 1)
                            {

                                if (htLocal.ContainsKey(dRow["VU_BorrowerName"]))
                                {
                                    iRegUpload++;
                                    iGlbRegNo++;

                                    string strApppReplace = htLocal[dRow["VU_BorrowerName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    //string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                    //strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);
                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_BorrowerName"]].ToString();



                                    //iGlbRegNo++;
                                    strMasterID = strApppReplace;
                                    strRegNoNew = iGlbRegNo.ToString();
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }
                            }
                            if (alApplicants.Count == 2)
                            {

                                if (htLocal.ContainsKey(dRow["VU_BorrowerName"]))
                                {
                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_BorrowerName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_BorrowerName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_BorrowerName"]].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_BorrowerName"]].ToString();




                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoBorrowerName"]))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoBorrowerName"]].ToString();


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoBorrowerName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    //strApppReplace = htLocal[dRow["VU_CoApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}


                                }


                                if (htLocal.ContainsKey(dRow["VU_GurName"]))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"]].ToString();

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_BorrowerName"]].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }

                                else
                                {

                                }
                            }

                            if (alApplicants.Count == 3)
                            {

                                if (htLocal.ContainsKey(dRow["VU_BorrowerName"]))
                                {

                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_BorrowerName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_BorrowerName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_BorrowerName"]].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_BorrowerName"]].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}

                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoBorrowerName"]))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoBorrowerName"]].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoBorrowerName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);


                                    strRegNo = htRegNoMapping[dRow["VU_CoBorrowerName"]].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }

                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"]))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"]].ToString();

                                    strInsert = strInsert.Replace(alApplicants[1].ToString() + "','dummy'", alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_CoBorrowerName"]].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }


                                else
                                {

                                }
                            }



                            //dAppstart += alApplicants.Count;

                            //dRegNostart += iRegUpload;

                            ////dRegNostart += alApplicants.Count;
                            ////iGlbRegNo += alApplicants.Count;
                            //iGlbRegNo += iRegUpload;


                            if (strGlbTemplateName == "SARFCBSS" || strGlbTemplateName == "SARFCBUS")
                            {
                                //strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(alApplicants.Count)).ToString();

                                //strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(iRegUpload)).ToString();
                                strGlbAppstartID = strMasterID;
                                iGlbRegNo = Convert.ToInt32(strRegNoNew);
                            }

                        }
                        #endregion

                        #region ODRS Upload logic

                        else if (strGlbTemplateName == "ODRS")
                        {
                            string strDeletermp;
                            if (alApplicants.Count == 1)
                            {

                                if (htLocal.ContainsKey(dRow["VU_BorrowerName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    iGlbRegNo++;

                                    string strApppReplace = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    //string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    //strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim().ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);
                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();



                                    //iGlbRegNo++;
                                    strMasterID = strApppReplace;
                                    strRegNoNew = iGlbRegNo.ToString();
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }
                            }
                            if (alApplicants.Count == 2)
                            {

                                if (htLocal.ContainsKey(dRow["VU_BorrowerName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim()].ToString();




                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoBorrowerName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    //strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}


                                }


                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }

                                if (htLocal.ContainsKey(dRow["VU_MortgagorName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_MortgagorName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[2].ToString() + "','dummy'", alApplicants[3].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_MortgagorName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_MortgagorName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }
                                if (htLocal.ContainsKey(dRow["VU_GurMortgagorName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[3].ToString() + "','dummy'", alApplicants[4].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;


                                }

                                else
                                {

                                }
                            }

                            if (alApplicants.Count == 3)
                            {

                                if (htLocal.ContainsKey(dRow["VU_BorrowerName"].ToString().Trim()))
                                {

                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                   

                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoBorrowerName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);


                                    strRegNo = htRegNoMapping[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }



                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[1].ToString() + "','dummy'", alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }


                                if (htLocal.ContainsKey(dRow["VU_MortgagorName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_MortgagorName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[2].ToString() + "','dummy'", alApplicants[3].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_MortgagorName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_GurName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }
                                if (htLocal.ContainsKey(dRow["VU_GurMortgagorName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[3].ToString() + "','dummy'", alApplicants[4].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;


                                }

                                else
                                {

                                }
                            }


                            if (alApplicants.Count == 4)
                            {

                                if (htLocal.ContainsKey(dRow["VU_BorrowerName"].ToString().Trim()))
                                {

                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}

                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoBorrowerName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);


                                    strRegNo = htRegNoMapping[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }



                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[1].ToString() + "','dummy'", alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    strRegNo = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()].ToString(); 
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }


                                if (htLocal.ContainsKey(dRow["VU_MortgagorName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_MortgagorName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[2].ToString() + "','dummy'", alApplicants[3].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_MortgagorName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_GurName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);


                                    strRegNo = htRegNoMapping[dRow["VU_MortgagorName"].ToString().Trim()].ToString();
                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }
                                if (htLocal.ContainsKey(dRow["VU_GurMortgagorName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[3].ToString() + "','dummy'", alApplicants[4].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_MortgagorName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;


                                }

                                else
                                {

                                }
                            }


                            if (alApplicants.Count == 5)
                            {

                                if (htLocal.ContainsKey(dRow["VU_BorrowerName"].ToString().Trim()))
                                {

                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_BorrowerName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_BorrowerName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}

                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoBorrowerName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);


                                    strRegNo = htRegNoMapping[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }



                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[1].ToString() + "','dummy'", alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_CoBorrowerName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }



                                if (htLocal.ContainsKey(dRow["VU_MortgagorName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_MortgagorName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[2].ToString() + "','dummy'", alApplicants[3].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_MortgagorName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_GurName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                    //if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA")
                                    //{
                                    //    strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                                    //}
                                }
                                if (htLocal.ContainsKey(dRow["VU_GurMortgagorName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[3].ToString() + "','dummy'", alApplicants[4].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurMortgagorName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_MortgagorName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;


                                }

                                else
                                {

                                }
                            }

                            //dAppstart += alApplicants.Count;

                            //dRegNostart += iRegUpload;

                            ////dRegNostart += alApplicants.Count;
                            ////iGlbRegNo += alApplicants.Count;
                            //iGlbRegNo += iRegUpload;


                            if (strGlbTemplateName == "ODRS")
                            {
                                //strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(alApplicants.Count)).ToString();

                                //strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(iRegUpload)).ToString();
                                strGlbAppstartID = strMasterID;
                                iGlbRegNo = Convert.ToInt32(strRegNoNew);
                            }

                        }
                        #endregion



                        else
                        {

                            ExcuteDML(strInsert);
                            string strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                            ExcuteDML(strDeletermp);
                            if (strGlbTemplateName == "DLN" || strGlbTemplateName == "SARL"
                                 || strGlbTemplateName == "DLNSEG" || strGlbTemplateName == "DLNHARD"
                                 || strGlbTemplateName == "DLNPP" || strGlbTemplateName == "LRN")
                            {
                                strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + 1).ToString();
                            }
                        }
                    }
                    sbValues.Clear();
                    alApplicants.Clear();
                    //string test = testCol;

                }


                if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA" || strGlbTemplateName == "DLNAML"
                    || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "ODRN" || strGlbTemplateName == "SAWN"
                    || strGlbTemplateName == "SARFCBSS" || strGlbTemplateName == "SARFCBUS" || strGlbTemplateName == "ODRS"
                     ||  strGlbTemplateName == "VPN")
                {
                    iGlbRegNo += 1;
                }
                string strUpdateRegNo = "update lpo_templatemaster set curRegNo = " + iGlbRegNo.ToString() + " where TemplateId = " + iTempIndex.ToString();
                ExcuteDML(strUpdateRegNo);

                if (strGlbTemplateName == "DLN" || strGlbTemplateName == "DLNPP"
                    || strGlbTemplateName == "DLNHARD" || strGlbTemplateName == "SARL"
                    || strGlbTemplateName == "VPN" || strGlbTemplateName == "CIBILAN"
                    || strGlbTemplateName == "LRN" || strGlbTemplateName == "138ECS"
                    || strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA"
                   || strGlbTemplateName == "DLNML" || strGlbTemplateName == "DLNAML"
                   || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "SEC138"
                   || strGlbTemplateName == "DLNVPN" || strGlbTemplateName == "DLNVPNML"
                   || strGlbTemplateName == "138HFC" || strGlbTemplateName == "SAWN"
                   || strGlbTemplateName == "SARFCBSS")
                {
                    string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'LOAN' where " +
                        "VU_LanNo REGEXP '^[A-Z]' and VU_TemplateName = '" + strGlbTemplateName +
                        "' AND VU_FileName = '" + strGlbFileName + "';";
                    ExcuteDML(strUpdateLoanCard);

                    strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'CARD' where " +
                        "VU_LanNo REGEXP '^[0-9]' and VU_TemplateName = '" + strGlbTemplateName +
                        "' AND VU_FileName = '" + strGlbFileName + "';";
                    ExcuteDML(strUpdateLoanCard);
                }
                if (strGlbTemplateName == "SARF13_2_IB")
                {
                    //string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'LOAN' where " +
                    //    "VU_LanNo REGEXP '^[0-9]' and VU_TemplateName = '" + strGlbTemplateName +
                    //    "' AND VU_FileName = '" + strGlbFileName + "';";
                    //ExcuteDML(strUpdateLoanCard);

                    string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'LOAN' where " +
                            "VU_TemplateName = '" + strGlbTemplateName +
                            "' AND VU_FileName = '" + strGlbFileName + "';";
                    ExcuteDML(strUpdateLoanCard);
                }

                    if (strGlbTemplateName == "SARFCBSS")
                {
                    string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'LOAN' where " +
                        "VU_BadSecLan REGEXP '^[A-Z]' and VU_TemplateName = '" + strGlbTemplateName +
                        "' AND VU_FileName = '" + strGlbFileName + "';";
                    ExcuteDML(strUpdateLoanCard);

                    strUpdateLoanCard = "Update lpo_trnsuccess set VU_LanNo = VU_BadSecLan, VU_Product = VU_BadSecLanProd" +
                        " where VU_TemplateName = '" + strGlbTemplateName +
                        "' AND VU_FileName = '" + strGlbFileName + "';";


                    ExcuteDML(strUpdateLoanCard);


                    //strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'CARD' where " +
                    //    "VU_LanNo REGEXP '^[0-9]' and VU_TemplateName = '" + strGlbTemplateName +
                    //    "' AND VU_FileName = '" + strGlbFileName + "';";
                    //ExcuteDML(strUpdateLoanCard);
                }


                if (strGlbTemplateName == "SARFCBUS")
                {
                    //string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'LOAN' where " +
                    //    "VU_BadSecLan REGEXP '^[A-Z]' and VU_TemplateName = '" + strGlbTemplateName +
                    //    "' AND VU_FileName = '" + strGlbFileName + "';";
                    //ExcuteDML(strUpdateLoanCard);

                    string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LanNo = VU_UnSecLan, VU_Product = VU_UnSecProd , VU_LoanorCard = 'LOAN' " +
                        " where VU_TemplateName = '" + strGlbTemplateName +
                        "' AND VU_FileName = '" + strGlbFileName + "';";


                    ExcuteDML(strUpdateLoanCard);


                    //strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'CARD' where " +
                    //    "VU_LanNo REGEXP '^[0-9]' and VU_TemplateName = '" + strGlbTemplateName +
                    //    "' AND VU_FileName = '" + strGlbFileName + "';";
                    //ExcuteDML(strUpdateLoanCard);
                }


                if (strGlbTemplateName == "DLNSEG" || strGlbTemplateName == "ODRN" || strGlbTemplateName == "ODRS")
                {
                    string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'LOAN' where " +
                        "VU_LanNo REGEXP '^[0-9]'  and VU_TemplateName = '" + strGlbTemplateName +
                        "' AND VU_FileName = '" + strGlbFileName + "';";
                    ExcuteDML(strUpdateLoanCard);
                }



            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message + "  " + icntTest.ToString());
            }
        }

        private static void InsertIntoAnnexrTable(string strAnxTbl)
        {
            try
            {
                string strInsertAnxtbl = "truncate " + strAnxTbl;
                ExcuteDML(strInsertAnxtbl);

                if ((strGlbTemplateName != "SARFCBSS") && (strGlbTemplateName != "SARFCBUS")  && 
                    (strGlbTemplateName != "SARF13_2_IB")  && (strGlbTemplateName != "SAWN")
                    && (strGlbTemplateName != "ODRS") && (strGlbTemplateName != "VPN") )
                {
                    strInsertAnxtbl = "Insert into " + strAnxTbl + "( VU_LoanOrCard, VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                                            "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                            "and VU_TemplateName = '" + strGlbTemplateName + "' and concat(trim(vu_ApplicantName),',', trim(vu_ApplicantName))= trim(VU_NAmeMapping ))";

                    ExcuteDML(strInsertAnxtbl);

                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_CoApplicantName, VU_CoAppAdd1, VU_CoAppAdd2 " +
                        ", VU_CoAppAdd3, VU_CoAppAdd4,VU_CoAppCity, VU_CoAppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                                            "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                            "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_CoApplicantName <> '' and concat(trim(vu_ApplicantName),',', trim(vu_CoApplicantName))= trim(VU_NAmeMapping ))";

                    ExcuteDML(strInsertAnxtbl);


                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurName, VU_GurAdd1, VU_GurAdd2 " +
                        ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                         "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                          "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and concat(trim(vu_ApplicantName),',', trim(VU_GurName))= trim(VU_NAmeMapping ))";

                    ExcuteDML(strInsertAnxtbl);
                }
                if ( strGlbTemplateName == "SAWN"  || strGlbTemplateName == "VPN")
                {
                    strInsertAnxtbl = "Insert into " + strAnxTbl + "( VU_LoanOrCard, VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                                            "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                            "and VU_TemplateName = '" + strGlbTemplateName + "' and  vu_ApplicantName= VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);

                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_CoApplicantName, VU_CoAppAdd1, VU_CoAppAdd2 " +
                        ", VU_CoAppAdd3, VU_CoAppAdd4,VU_CoAppCity, VU_CoAppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                                            "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                            "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_CoApplicantName <> '' and VU_CoApplicantName = VU_NAmeMapping  )";

                    ExcuteDML(strInsertAnxtbl);


                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurName, VU_GurAdd1, VU_GurAdd2 " +
                        ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                         "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                          "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and VU_GurName = VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);
                }


                else if (strGlbTemplateName == "SARF13_2_IB")
                {
                    strInsertAnxtbl = "Insert into " + strAnxTbl + "( VU_LoanOrCard, VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                       ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                       ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                      " from " + strGlbUploadSuccess +
                       " where VU_FileName = '" + strGlbFileName + "' " +
                                           "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                           "and VU_TemplateName = '" + strGlbTemplateName + "' and concat(vu_ApplicantName,',',vu_ApplicantName)= VU_NAmeMapping)";

                    ExcuteDML(strInsertAnxtbl);

                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_CoApplicantName, VU_CoAppAdd1, VU_CoAppAdd2 " +
                        ", VU_CoAppAdd3, VU_CoAppAdd4,VU_CoAppCity, VU_CoAppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_CoApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                                            "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                            "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_CoApplicantName <> '' and concat(vu_ApplicantName,',',VU_CoApplicantName)= VU_NAmeMapping)";

                    ExcuteDML(strInsertAnxtbl);


                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurName, VU_GurAdd1, VU_GurAdd2 " +
                        ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                         "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                          "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and concat(vu_ApplicantName,',',VU_GurName)=VU_NAmeMapping)";

                    ExcuteDML(strInsertAnxtbl);

                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                      ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_MORT_NAME, VU_MORT_CORR_ADD1, VU_MORT_CORR_ADD2 " +
                      ", VU_MORT_CORR_ADD3, VU_MORT_CORR_ADD4,VU_MORT_CORR_CITY, VU_MORT_CORR_PIN, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                     " from " + strGlbUploadSuccess +
                      " where VU_FileName = '" + strGlbFileName + "' " +
                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_MORT_NAME <> ''  and concat(vu_ApplicantName,',',VU_MORT_NAME)=VU_NAmeMapping)";

                    ExcuteDML(strInsertAnxtbl);

                }


                else if (strGlbTemplateName == "SARFCBSS")
                {
                    strInsertAnxtbl = "Insert into " + strAnxTbl + "( VU_LoanOrCard, VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                       ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_BorrowerName, VU_BorrowerAdd1, VU_BorrowerAdd2 " +
                       ", VU_BorrowerAdd3, VU_AppAdd4,VU_BorrowerCity, VU_BorrowerPin, VU_BadSecLan, VU_Filename,VU_MasterID,VU_BorrowerName " +
                      " from " + strGlbUploadSuccess +
                       " where VU_FileName = '" + strGlbFileName + "' " +
                                           "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                           "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_BorrowerName= VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);

                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_CoBorrowerName, VU_CoBorrowerAdd1, VU_CoBorrowerAdd2 " +
                        ", VU_CoBorrowerAdd3, VU_CoAppAdd4,VU_CoBorrowerCity, VU_CoBorrowerPin, VU_BadSecLan, VU_Filename,VU_MasterID,VU_CoBorrowerName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                                            "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                            "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_CoBorrowerName <> '' and VU_CoBorrowerName= VU_NAmeMapping  )";

                    ExcuteDML(strInsertAnxtbl);


                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurName, VU_GurAdd1, VU_GurAdd2 " +
                        ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_BadSecLan, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                         "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                          "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and VU_GurName= VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);

                }
                else if (strGlbTemplateName == "SARFCBUS")
                {
                    strInsertAnxtbl = "Insert into " + strAnxTbl + "( VU_LoanOrCard, VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                       ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_BorrowerName, VU_BorrowerAdd1, VU_BorrowerAdd2 " +
                       ", VU_BorrowerAdd3, VU_AppAdd4,VU_BorrowerCity, VU_BorrowerPin, VU_UnSecLan, VU_Filename,VU_MasterID,VU_BorrowerName " +
                      " from " + strGlbUploadSuccess +
                       " where VU_FileName = '" + strGlbFileName + "' " +
                                           "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                           "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_BorrowerName= VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);

                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_CoBorrowerName, VU_CoBorrowerAdd1, VU_CoBorrowerAdd2 " +
                        ", VU_CoBorrowerAdd3, VU_CoAppAdd4,VU_CoBorrowerCity, VU_CoBorrowerPin, VU_UnSecLan, VU_Filename,VU_MasterID,VU_CoBorrowerName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                                            "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                            "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_CoBorrowerName <> '' and VU_CoBorrowerName= VU_NAmeMapping  )";

                    ExcuteDML(strInsertAnxtbl);


                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurName, VU_GurAdd1, VU_GurAdd2 " +
                        ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_UnSecLan, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                         "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                          "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and VU_GurName= VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);

                }


                else if (strGlbTemplateName == "ODRS")
                {
                    strInsertAnxtbl = "Insert into " + strAnxTbl + "( VU_LoanOrCard, VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                       ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_BorrowerName, VU_BorrowerAdd1, VU_BorrowerAdd2 " +
                       ", VU_BorrowerAdd3, VU_AppAdd4,VU_BorrowerCity, VU_BorrowerPin, VU_LANNo, VU_Filename,VU_MasterID,VU_BorrowerName " +
                      " from " + strGlbUploadSuccess +
                       " where VU_FileName = '" + strGlbFileName + "' " +
                                           "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                           "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_BorrowerName= VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);

                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_CoBorrowerName, VU_CoBorrowerAdd1, VU_CoBorrowerAdd2 " +
                        ", VU_CoBorrowerAdd3, VU_CoAppAdd4,VU_CoBorrowerCity, VU_CoBorrowerPin, VU_LANNo, VU_Filename,VU_MasterID,VU_CoBorrowerName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                                            "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                            "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_CoBorrowerName <> '' and VU_CoBorrowerName= VU_NAmeMapping  )";

                    ExcuteDML(strInsertAnxtbl);


                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                        ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurName, VU_GurAdd1, VU_GurAdd2 " +
                        ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_LANNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                       " from " + strGlbUploadSuccess +
                        " where VU_FileName = '" + strGlbFileName + "' " +
                         "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                          "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and VU_GurName= VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);


                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                       ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_MortgagorName, VU_MortgagorAdd1, VU_MortgagorAdd2 " +
                       ", VU_MortgagorAdd3, VU_GurAdd4,VU_MortgagorCity, VU_MortgagorPin, VU_LANNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                      " from " + strGlbUploadSuccess +
                       " where VU_FileName = '" + strGlbFileName + "' " +
                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                         "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and VU_GurName= VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);


                    strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                       ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurMortgagorName, VU_GurMortgagorAdd1, VU_GurMortgagorAdd2 " +
                       ", VU_GurMortgagorAdd3, VU_GurAdd4,VU_GurMortgagorCity, VU_GurMortgagorPin, VU_LANNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                      " from " + strGlbUploadSuccess +
                       " where VU_FileName = '" + strGlbFileName + "' " +
                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                         "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and VU_GurName= VU_NAmeMapping )";

                    ExcuteDML(strInsertAnxtbl);

                }


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        //private static void InsertIntoAnnexrTable(string strAnxTbl)
        //{
        //    try
        //    {
        //        string strInsertAnxtbl = "truncate " + strAnxTbl;
        //        ExcuteDML(strInsertAnxtbl);

        //        if (strGlbTemplateName != "SARFCBSS")
        //        {
        //            strInsertAnxtbl = "Insert into " + strAnxTbl + "( VU_LoanOrCard, VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
        //                ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
        //                ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
        //               " from " + strGlbUploadSuccess +
        //                " where VU_FileName = '" + strGlbFileName + "' " +
        //                                    "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
        //                                    "and VU_TemplateName = '" + strGlbTemplateName + "' and vu_ApplicantName= VU_NAmeMapping )";

        //            ExcuteDML(strInsertAnxtbl);

        //            strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
        //                ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_CoApplicantName, VU_CoAppAdd1, VU_CoAppAdd2 " +
        //                ", VU_CoAppAdd3, VU_CoAppAdd4,VU_CoAppCity, VU_CoAppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
        //               " from " + strGlbUploadSuccess +
        //                " where VU_FileName = '" + strGlbFileName + "' " +
        //                                    "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
        //                                    "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_CoApplicantName <> '' and VU_CoApplicantName= VU_NAmeMapping  )";

        //            ExcuteDML(strInsertAnxtbl);


        //            strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
        //                ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurName, VU_GurAdd1, VU_GurAdd2 " +
        //                ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
        //               " from " + strGlbUploadSuccess +
        //                " where VU_FileName = '" + strGlbFileName + "' " +
        //                 "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
        //                  "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and VU_GurName= VU_NAmeMapping )";

        //            ExcuteDML(strInsertAnxtbl);
        //        }

        //        else
        //        {
        //            strInsertAnxtbl = "Insert into " + strAnxTbl + "( VU_LoanOrCard, VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
        //               ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_BorrowerName, VU_BorrowerAdd1, VU_BorrowerAdd2 " +
        //               ", VU_BorrowerAdd3, VU_AppAdd4,VU_BorrowerCity, VU_BorrowerPin, VU_BadSecLan, VU_Filename,VU_MasterID,VU_BorrowerName " +
        //              " from " + strGlbUploadSuccess +
        //               " where VU_FileName = '" + strGlbFileName + "' " +
        //                                   "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
        //                                   "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_BorrowerName= VU_NAmeMapping )";

        //            ExcuteDML(strInsertAnxtbl);

        //            strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
        //                ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_CoBorrowerName, VU_CoBorrowerAdd1, VU_CoBorrowerAdd2 " +
        //                ", VU_CoBorrowerAdd3, VU_CoAppAdd4,VU_CoBorrowerCity, VU_CoBorrowerPin, VU_BadSecLan, VU_Filename,VU_MasterID,VU_CoBorrowerName " +
        //               " from " + strGlbUploadSuccess +
        //                " where VU_FileName = '" + strGlbFileName + "' " +
        //                                    "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
        //                                    "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_CoBorrowerName <> '' and VU_CoBorrowerName= VU_NAmeMapping  )";

        //            ExcuteDML(strInsertAnxtbl);


        //            strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
        //                ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurName, VU_GurAdd1, VU_GurAdd2 " +
        //                ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_BadSecLan, VU_Filename,VU_MasterID,VU_ApplicantName " +
        //               " from " + strGlbUploadSuccess +
        //                " where VU_FileName = '" + strGlbFileName + "' " +
        //                 "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
        //                  "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and VU_GurName= VU_NAmeMapping )";

        //            ExcuteDML(strInsertAnxtbl);

        //        }


        //    }
        //    catch (Exception Ex)
        //    {
        //        MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
        //    }
        //}

        //private static void getSRNumber(string strGlbFileName)
        //{
        //    try
        //    {
        //        string strPattern = "_SR[0-9]+";
        //        if(Regex.IsMatch(strPattern, strPattern))
        //        {

        //        }


        //    }
        //    catch (Exception Ex)
        //    {
        //        MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
        //    }
        //}

        private static void CreateFolderStructure(string strGlbPath)
        {
            try
            {

                String strDt = DateTime.Now.ToString("dd MMM yyyy");
                string strOutputPath = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt;
                string strInputFile = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Input";

                strGlbOutputPathBulk = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "BulkRegister";
                strGlbOutputPathReport = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Report";
                strGlbOutputPathSticker = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Sticker";


                if (!Directory.Exists(strInputFile))
                {
                    Directory.CreateDirectory(strInputFile);

                }
                File.Copy(strGlbInputFilePath, strInputFile + "\\" + strGlbFileName + ".xls", true);
                if (!Directory.Exists(strOutputPath))
                {
                    Directory.CreateDirectory(strOutputPath);
                }
                if (!Directory.Exists(strGlbOutputPathBulk))
                {
                    Directory.CreateDirectory(strGlbOutputPathBulk);
                }
                if (!Directory.Exists(strGlbOutputPathReport))
                {
                    Directory.CreateDirectory(strGlbOutputPathReport);
                }
                if (!Directory.Exists(strGlbOutputPathSticker))
                {
                    Directory.CreateDirectory(strGlbOutputPathSticker);
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }



        private static void bulkRegister(string strGlbTemplateName)
        {
            DataTable dtBulk = new DataTable();
            string strReportcond = string.Empty;
            string strSetPrintFlag = string.Empty;
            try
            {

                if (strGlbTemplateName == "SARL")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptSARL.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkSP = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";




                    dtBulk = GetData(strBulkSP);

                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_Sticker_SP.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_Sticker_REG.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }

                if (strGlbTemplateName == "SARF13_2_IB")
                {

                    string serverRptPath = strGlbTemplateLocation + "CrRptSARF13_2IB.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl  group by VU_MasterID ORDER BY VU_MasterID;"; 
                                       //"where VU_FileName = '" + strGlbFileName + "' ORDER BY VU_MasterID;";


                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_SP_BulkRegister", dtBulk, "SPEED Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_Sticker_REG.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }

                }
                if (strGlbTemplateName == "SARFCBUS")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptSARFCBUS.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, '')), 200) as Name_And_Address," +
                                       " VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl group by VU_MasterID ORDER BY VU_MasterID;";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "REG Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }

                if (strGlbTemplateName == "SAWN")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptSAWN.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, '')), 200) as Name_And_Address," +
                                       " VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl group by VU_MasterID ORDER BY VU_MasterID;";
                                       //"where VU_FileName = '" + strGlbFileName + "' " +
                                       //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                       //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }


                if (strGlbTemplateName == "SARFCBSS")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptSarfCBSS.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, '')), 200) as Name_And_Address," +
                                       " VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl group by VU_MasterID ORDER BY VU_MasterID;";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "REG Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }


                if (strGlbTemplateName == "LRNA")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRpt_LRNA.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "StkrDLRna.rpt";

                    string strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, VU_ApplicantName as Name , VU_AppAdd1 as Address, VU_AppCity as City, " +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl " +
                                       "where  VU_LoanOrCard ='LOAN' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID;";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, VU_ApplicantName as Name , VU_AppAdd1 as Address, VU_AppCity as City, " +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl where  VU_LoanOrCard ='LOAN'" +
                                       " and VU_DispatchMode = 'REG'  group by VU_MasterID ORDER BY VU_MasterID; ";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }



                if (strGlbTemplateName == "LRNAML")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptLRNAML.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "StkrDLRna.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, VU_ApplicantName as Name , VU_AppAdd1 as Address, VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl where VU_DispatchMode = 'SP'" +
                                       "group by VU_MasterID order by VU_MasterID";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, VU_ApplicantName as Name , VU_AppAdd1 as Address, VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl where VU_DispatchMode = 'REG'" +
                                       "group by VU_MasterID order by VU_MasterID";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }

                if (strGlbTemplateName == "DLNAML")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptDLNAML.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "StkrDLRna.rpt";

                    string strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, VU_ApplicantName as Name , VU_AppAdd1 as Address, VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl " +
                                       "where VU_LoanOrCard ='LOAN' and VU_DispatchMode = 'REG' Group by VU_MasterID ORDER BY VU_MasterID;";

                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number,VU_ApplicantName as Name , VU_AppAdd1 as Address, VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl " +
                                       "where VU_LoanOrCard ='CARD' and VU_DispatchMode = 'REG' Group by VU_MasterID ORDER BY VU_MasterID;";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //                   "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //                   "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                    //                   "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_REG_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }



                if (strGlbTemplateName == "DLNVPN")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptDLNVPN.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_REG_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }

                if (strGlbTemplateName == "DLNA")
                {
                    bool bExecute = false;
                    string serverRptPath = strGlbTemplateLocation + "CrRptDLNA1.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "StkrDLRna.rpt";



                    string strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, '')), 200) as Name_And_Address, VU_AppCity as City, " +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl " +
                                       "where  VU_LoanOrCard ='LOAN'  group by VU_MasterID ORDER BY VU_MasterID;";

                    //string strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                    //                   "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                    //                   "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                    //                   "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl " +
                    //                   "where  VU_LoanOrCard ='LOAN'  group by VU_MasterID  ORDER BY VU_MasterID;";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0 && !bExecute)
                    {
                        bExecute = true;
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, '')), 200) as Name_And_Address, VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl " +
                                       "where  VU_LoanOrCard ='CARD'  group by VU_MasterID  ORDER BY VU_MasterID;";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0 && !bExecute)
                    {
                        bExecute = true;
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_REG_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }



                if (strGlbTemplateName == "DLNVPNML")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptDLNVPNML.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_SP_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_REG_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }

                if (strGlbTemplateName == "DLNML")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRpDLNML.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    //string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                    //                   "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                    //                   "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                    //                   "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                    //                   "where VU_FileName = '" + strGlbFileName + "' " +
                    //                   "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //                   "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //                   "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                      "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                      "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                      "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                      "where VU_FileName = '" + strGlbFileName + "' " +
                                      "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                      "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                      "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' Group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_SP_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_REG_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }



                if (strGlbTemplateName == "138ECS")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRpt138_ECS.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_SP_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }




                if (strGlbTemplateName == "ODRN")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptODRN.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "StkrDLRna.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, '')), 200) as Name_And_Address," +
                                       " VU_AppCity as City, VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl where VU_LoanOrCard ='LOAN' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID;";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, '')), 200) as Name_And_Address," +
                                       " VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl where VU_LoanOrCard ='LOAN' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID;";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }



                if (strGlbTemplateName == "ODRS")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptODRS.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, '')), 200) as Name_And_Address," +
                                       " VU_AppCity as City, VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl where VU_LoanOrCard ='LOAN' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID;";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, '')), 200) as Name_And_Address," +
                                       " VU_AppCity as City," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl where VU_LoanOrCard ='LOAN' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID;";
                    //"where VU_FileName = '" + strGlbFileName + "' " +
                    //"and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }


                if (strGlbTemplateName == "DLNSEG")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptDLN_seg_loan.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }

                if (strGlbTemplateName == "LRN")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptLRN.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkSP = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";




                    dtBulk = GetData(strBulkSP);

                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_Sticker_SP.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_Sticker_REG.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }


                if (strGlbTemplateName == "DLN")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptDLN_Card.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";
                    string serverRpt = strGlbTemplateLocation + "CrRptDLN_Loan.rpt";



                    string strBulkSP = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";




                    dtBulk = GetData(strBulkSP);

                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_SP_Sticker.pdf", serverStickerPath);

                        // GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);



                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkSP = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N'  and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N'  and VU_LoanOrCard ='LOAN' " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";




                    dtBulk = GetData(strBulkSP);

                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRpt);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        // GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);



                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N'  and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRpt);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }


                if (strGlbTemplateName == "DLNPP")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptDLNPP_Card.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";
                    string serverRpt = strGlbTemplateLocation + "CrRptDLNPP_Loan.rpt";



                    string strBulkSP = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";




                    dtBulk = GetData(strBulkSP);

                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_SP_Sticker.pdf", serverStickerPath);

                        // GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);



                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 55) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkSP = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N'  and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N'  and VU_LoanOrCard ='LOAN' " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";




                    dtBulk = GetData(strBulkSP);

                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRpt);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        // GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);



                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N'  and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRpt);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }




                if (strGlbTemplateName == "DLNHARD")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptDLNHardCard.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";
                    string serverRpt = strGlbTemplateLocation + "CrRptDLNHardLoan.rpt";



                    string strBulkSP = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";




                    dtBulk = GetData(strBulkSP);

                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_SP_Sticker.pdf", serverStickerPath);

                        // GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);



                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }

                }


                if (strGlbTemplateName == "CIBILAN")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptCibillan.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_REG_BulkRegister", dtBulk, "Registered Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_REG.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_REG_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }

                if (strGlbTemplateName == "VPN")
                {

                    string serverRptPath = strGlbTemplateLocation + "CrVpn_1.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl group by VU_MasterID ORDER BY VU_MasterID;";
                                       //"where VU_FileName = '" + strGlbFileName + "' ORDER BY VU_MasterID;";
                    // "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                    //"and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                    //"and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'REG' ";


                    dtBulk = GetData(strBulkREG);
                    GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_REG_BulkRegister", dtBulk, "Registered Post");
                    dtBulk.Clear();
                    GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_REG.pdf", serverRptPath);
                    GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_Sticker_REG.pdf", serverStickerPath);


                    strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                    ExcuteDML(strSetPrintFlag);

                }

                if (strGlbTemplateName == "SEC138")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRptSec138.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_SP_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }



                if (strGlbTemplateName == "138HFC")
                {
                    string serverRptPath = strGlbTemplateLocation + "CrRpt138HFC.rpt";
                    string serverStickerPath = strGlbTemplateLocation + "Sticker1.rpt";

                    string strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                        //  GenerateReport(serverRpt, strGlbOutputPathSticker + "\\" + strGlbFileName + "_LOAN.pdf", serverStickerPath);


                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }



                    strBulkREG = "select IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                       "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                       "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                       "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                       "where VU_FileName = '" + strGlbFileName + "' " +
                                       "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                       "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD'  " +
                                       "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' group by VU_MasterID ORDER BY VU_MasterID; ";

                    strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' and VU_LoanOrCard ='CARD' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                    dtBulk = GetData(strBulkREG);
                    if (dtBulk.Rows.Count > 0)
                    {
                        GenerateBulkExcel(strGlbOutputPathBulk + "\\" + strGlbFileName + "_CARD_SP_BulkRegister", dtBulk, "Speed Post");
                        dtBulk.Clear();
                        GenerateReport(strReportcond, strGlbOutputPathReport + "\\" + strGlbFileName + "_CARD_SP.pdf", serverRptPath);
                        GenerateReport(strReportcond, strGlbOutputPathSticker + "\\" + strGlbFileName + "_CARD_SP_Sticker.pdf", serverStickerPath);

                        strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                        ExcuteDML(strSetPrintFlag);
                    }
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void GenerateReport(string strReportcond, string strRepoPath, string strserverRptPath)
        {
            try
            {
                string strSudiptoSign = ConfigurationManager.AppSettings["defaultSignatureSudipto"].ToString();
                
                string strSignMohanJayaraman = ConfigurationManager.AppSettings["defaultSignatureMohanJayaraman"].ToString(); 
                string strQry = "truncate table " + const_strReportTable;
                ExcuteDML(strQry);

                string strInsertRpt = "Insert into " + const_strReportTable + "( " + strGlbCol + ")" + "(select " + strGlbCol +
                    " from " + strGlbUploadSuccess + strReportcond + " )";

                ExcuteDML(strInsertRpt);

                if (strGlbTemplateName == "SARF13_2_IB")
                {
                    string strNonDunning = "update " + const_strReportTable + " set  VU_SignaturePath = " +
                            "'" + strSignMohanJayaraman + "'";

                    ExcuteDML(strNonDunning);

                }

                if (strGlbTemplateName.StartsWith("SARL") || strGlbTemplateName.StartsWith("LRN")
                    || strGlbTemplateName == "CIBILAN" || strGlbTemplateName == "LRNA"
                    || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "ODRN"
                    )
                {
                    //string strNonDunning = "update " + const_strReportTable + " set  VU_SignaturePath = " +
                    //        "'\\\\\\\\\\10.1.31.22\\\\\\vara_dev_bpo\\\\\\SoftTeam\\\\\\LPODevReports\\\\\\AUTHSIGN_DUNNING\\\\\\SUDIPTO_NAG.JPG'" +
                    //        " WHERE VU_LanNo REGEXP '^(AA|AC|AM|AQ|AT|AV|B2|BT|CA|CQ|CT|CU|CV" +
                    //        "|DI|DV|E2|E7|E9|EA|EB|EF|EP|ES|EV|F5|H9|HV|IP|JP|K9|KF|L0|L1|L2|L3|L5|L8|L9|LA|LB|LC|LD|LE|LF|LG|LH" +
                    //        "|LI|LJ|LK|LL|LM|LN|LO|LP|LQ|LT|LU|LV|LW|M1|M2|M3|M5|M9|MA|MB|MF|MP|MT|MV|NC|NH|R1|R5|RA|RB|RO|RP" +
                    //        "|RT|SA|SH|SP|SU|SV|TC|TM|TS|TT|UP|UQ|UV|WP)'";

                    string strNonDunning = "update " + const_strReportTable + " set  VU_SignaturePath = " +
                            "'" + strSudiptoSign + "'" +
                            " WHERE VU_LanNo REGEXP '^(AA|AC|AM|AQ|AT|AV|B2|BT|CA|CQ|CT|CU|CV" +
                            "|DI|DV|E2|E7|E9|EA|EB|EF|EP|ES|EV|F5|H9|HV|IP|JP|K9|KF|L0|L1|L2|L3|L5|L8|L9|LA|LB|LC|LD|LE|LF|LG|LH" +
                            "|LI|LJ|LK|LL|LM|LN|LO|LP|LQ|LT|LU|LV|LW|M1|M2|M3|M5|M9|MA|MB|MF|MP|MT|MV|NC|NH|R1|R5|RA|RB|RO|RP" +
                            "|RT|SA|SH|SP|SU|SV|TC|TM|TS|TT|UP|UQ|UV|WP)'";


                    ExcuteDML(strNonDunning);

                }

                if (strGlbTemplateName == "ODRN" || strGlbTemplateName == "VPN" || strGlbTemplateName == "SAWN")
                {
                    string strNonDunning = "update " + const_strReportTable + " set  VU_SignaturePath = " +
                            "'" + strSudiptoSign + "'";

                    ExcuteDML(strNonDunning);

                }
                if (strGlbTemplateName == "SARFCBSS" || strGlbTemplateName == "SARFCBUS")
                {
                    string strNonDunning = "update " + const_strReportTable + " set  VU_SignaturePath = " +
                            "'" + strSignMohanJayaraman + "'";

                    ExcuteDML(strNonDunning);

                }
                if (strGlbTemplateName == "VPN" || strGlbTemplateName == "CIBILAN"
                    || strGlbTemplateName == "DLNML" || strGlbTemplateName == "DLNVPNML"
                    || strGlbTemplateName == "DLNAML")
                {
                    DBHelper objHelper = new DBHelper();
                    objHelper.ExecuteNonQuery("call UpdateTotalAmount ('')",
                        CommandType.StoredProcedure);
                    objHelper = null;
                }


                if (strGlbTemplateName == "LRNAML")
                {
                    DBHelper objHelper = new DBHelper();
                    objHelper.ExecuteNonQuery("call UpdateLRNAMLTotalAmount ('')",
                        CommandType.StoredProcedure);
                    objHelper = null;
                }
                //UpdateECSTotalAmount
                if (strGlbTemplateName == "138ECS")
                {
                    DBHelper objHelper = new DBHelper();
                    objHelper.ExecuteNonQuery("call UpdateECSTotalAmount ('')",
                        CommandType.StoredProcedure);
                    objHelper = null;
                }
                if (strGlbTemplateName == "SEC138"
                    || strGlbTemplateName == "138HFC")
                {
                    DBHelper objHelper = new DBHelper();
                    objHelper.ExecuteNonQuery("call UpdateChqAmtAmount ('')",
                        CommandType.StoredProcedure);
                    objHelper = null;
                }

                ReportDocument cryRpt = new ReportDocument();
                //cryRpt.Refresh();
                cryRpt.Load(strserverRptPath);

                cryRpt.Refresh();
                ExportOptions CrExportOptions;
                DiskFileDestinationOptions CrDiskFileDestinationOptions = new DiskFileDestinationOptions();
                PdfRtfWordFormatOptions CrFormatTypeOptions = new PdfRtfWordFormatOptions();
                CrDiskFileDestinationOptions.DiskFileName = strRepoPath;
                CrExportOptions = cryRpt.ExportOptions;
                {
                    CrExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
                    CrExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
                    CrExportOptions.DestinationOptions = CrDiskFileDestinationOptions;
                    CrExportOptions.FormatOptions = CrFormatTypeOptions;
                }

                cryRpt.Export();
                MessageBox.Show("Report Generated SuccessFully");
                cryRpt.Refresh();

                cryRpt.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void GenerateBulkExcel(string strGlbOutputPathBulk, DataTable dtBulk, string strDispMode)
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application xlApp;
                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "IN CHARGE MBC, CHAKALA, MIDC POST OFFICE MUMBAI 400091";
                xlWorkSheet.Cells[2, 1] = "ICICI Bank - " + strGlbTemplateName + " Bulk Register";
                xlWorkSheet.Cells[3, 1] = "Mode of Dispatch - " + strDispMode;
                xlWorkSheet.Cells[4, 1] = "Date - " + DateTime.Now.ToShortDateString();

                for (var i = 0; i < dtBulk.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[5, i + 1] = dtBulk.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dtBulk.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dtBulk.Columns.Count - 1; j++)
                    {

                        string str = "'" + dtBulk.Rows[i][j].ToString();

                        xlWorkSheet.Cells[i + 6, j + 1] = str;

                        xlWorkSheet.Cells.Columns.AutoFit();
                    }
                }

                //xlWorkSheet.Range["A1" + ":" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Borders.LineStyle = LineStyle.SingleLine;
                xlWorkBook.SaveAs(strGlbOutputPathBulk);
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show("Data Exported Successfully ,file Path: " + (strGlbOutputPathBulk));


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void fillSpDispatchArrayList()
        {
            DataTable dtSpDispatch = new DataTable();
            alSpList = new ArrayList();
            try
            {
                string strSpdispatch = "select VU_Pincode from lpo_pincodematser;";

                dtSpDispatch = ClsGlobal.GetData(strSpdispatch);
                if (dtSpDispatch.Rows.Count > 0)
                {
                    foreach (DataRow row in dtSpDispatch.Rows)
                    {
                        alSpList.Add(row["VU_Pincode"].ToString());
                    }
                }

            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
            finally
            {
                dtSpDispatch.Clear();
            }
        }

        private static void UpdateFileLog(string strGlbFileName, string strGlbAppstartID, string strGlbBatchID, int iRowCont)
        {
            try
            {
                if (strGlbTemplateName == "LRNA" || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "ODRN"
                    || strGlbTemplateName == "SAWN" ||  strGlbTemplateName == "SARFCBSS" || strGlbTemplateName == "SARFCBUS" || strGlbTemplateName == "ODRS"
                    || strGlbTemplateName == "ODRS")
                {
                    int i = 1;
                    strGlbAppstartID = (Convert.ToInt64(strGlbAppstartID) + i).ToString();
                }


                string strUpdateFileLogQry = "Insert into vu_fileuploadlog (FileName, " +
                    " UploadDate, BatchId, AppStartNo,NumberofRecords,TemplateName) Values ('" +
                     strGlbFileName + "','" + DateTime.Now.ToShortDateString() + "','" + strGlbBatchID + "','" + strGlbAppstartID + "','" +
                      iRowCont.ToString() + "','" + strGlbTemplateName + "')";

                ExcuteDML(strUpdateFileLogQry);


            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }

        }

        private static void InsertIntoFailedtbl(int iTempIndex, string strUploadFailed)
        {
            try
            {
                double dAppstart = Convert.ToDouble(strGlbAppstartID);
                StringBuilder sbValues = new StringBuilder();
                DataTable dtUpload = new DataTable();
                string strSelectUpload = "Select " + strGlbCol + " From " + strGlbUploadTbl;
                dtUpload = GetData(strSelectUpload);
                string strInsQry = "Insert into " + strUploadFailed + "( " + strGlbCol + ") Values (";


                foreach (DataRow dRow in dtUpload.Rows)
                {
                    foreach (DataColumn col in dtUpload.Columns)
                    {
                        string strColName = col.ColumnName;

                        if (strColName == "VU_MasterID")
                        {
                            sbValues.Append("'" + dAppstart.ToString() + "',");
                            dAppstart += 1;
                            continue;
                        }

                        else if (strColName == "VU_DispatchMode" && strGlbTemplateName != "SARFCBSS" && strGlbTemplateName != "SARFCBUS"
                            && strGlbTemplateName != "ODRS")
                        //else if (strColName == "VU_DispatchMode" && (strGlbTemplateName != "SARFCBSS"|| strGlbTemplateName != "SARFCBUS"))
                        {
                            if (alSpList.Contains(dRow["VU_AppPincode"].ToString()))
                            {
                                sbValues.Append("'SP',");
                                continue;
                            }
                            else
                            {
                                sbValues.Append("'REG',");
                                continue;
                            }
                        }
                        sbValues.Append("'" + dRow[strColName].ToString() + "',");

                    }


                    ////sbValues.Append("'" + strFileName + "',");
                    sbValues.Append(")");
                    //dAppstart += 1;

                    string strInsert = strInsQry + sbValues.ToString();
                    strInsert = strInsert.Remove(strInsert.LastIndexOf(","), 1);
                    sbValues.Clear();
                    ExcuteDML(strInsert);

                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void InsertIntoSuccess(int iTempIndex, string strUploadSuccess)
        {
            string testCol = "";
            htGlbVPNCustomer = new Hashtable();
            DataTable dtUploadData = new DataTable();
            DataTable dtCondition = new DataTable();
            string strCondition = string.Empty;
            StringBuilder sbValues = new StringBuilder();


            Hashtable ht138ECSLanCheck = new Hashtable();

            Hashtable htRegNoCheck = new Hashtable();


            Hashtable ht138ECSNumCheck = new Hashtable();
            Hashtable ht138ECSRegNoCheck = new Hashtable();

            double dAppstart = Convert.ToDouble(strGlbAppstartID);
            double dAppLocal = Convert.ToDouble(strGlbAppstartID);
            double dRegNoLocal = Convert.ToDouble(iGlbRegNo);
            double dRegNostart = Convert.ToDouble(iGlbRegNo);

            string strColTest = string.Empty;


            Hashtable htLocal = new Hashtable();
            Hashtable htRegNoMapping = new Hashtable();


            string strRptTbl = "Truncate " + const_strReportTable;
            string strInsQry = "Insert into " + strUploadSuccess + "( " + strGlbCol + ") Values (";


            try
            {

                string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                dtCondition = GetData(strValidation);
                if (dtCondition.Rows.Count > 0)
                {
                    strCondition = dtCondition.Rows[0]["validation"].ToString();
                }

                if (strGlbTemplateName == "DLNAML" || strGlbTemplateName == "138ECS" || strGlbTemplateName == "DLNA")
                {
                    string strUploadqry = "select " + strGlbCol + " from " + strGlbUploadTbl + " where " + strCondition;
                    dtUploadData = GetData(strUploadqry);
                }
                else
                {
                    string strUploadqry = "select " + strGlbCol + " from " + strGlbUploadTbl + " where " + strCondition + " Order by VU_AppPincode";
                    dtUploadData = GetData(strUploadqry);
                }

                //int itest = 0;

                foreach (DataRow dRow in dtUploadData.Rows)
                {

                    ArrayList alApplicants = new ArrayList();
                    bool bExecute = true;
                    foreach (DataColumn col in dtUploadData.Columns)
                    {
                        // icntTest++;
                        //itest++;
                        bool bDate = false;
                        bool bLan = false;
                        string strColName = col.ColumnName;


                        strColTest = strColName;


                        string strColType = htGlbColTyp[strColName].ToString();
                        testCol = strColName;

                        if (strColName == "VU_MasterID" && (strGlbTemplateName == "SARL" || strGlbTemplateName == "DLN"
                            || strGlbTemplateName == "DLNHARD" || strGlbTemplateName == "DLNPP"
                             || strGlbTemplateName == "DLNSEG" || strGlbTemplateName == "DLNVPN"))
                        {
                            sbValues.Append("'" + dAppstart.ToString() + "',");
                            dAppstart += 1;
                            continue;
                        }


                        else if (strColName == "VU_MasterID" && (strGlbTemplateName == "LRN"))
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()))
                            {
                                ht138ECSLanCheck.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_LANNO"].ToString()
                                    , dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["VU_ApplicantName"].ToString().Trim() + "," +
                                    dRow["VU_LANNO"].ToString()].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                            }


                            if (!ht138ECSNumCheck.Contains(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_LANNO"].ToString().Trim()
                                    + "," + dRow["VU_TotalForclosureAmt"].ToString().Trim() + "," + dRow["VU_EMIOverdue"].ToString().Trim()))
                            {
                                ht138ECSNumCheck.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_LANNO"].ToString().Trim()
                                    + "," + dRow["VU_TotalForclosureAmt"].ToString().Trim() + "," + dRow["VU_EMIOverdue"].ToString().Trim(), dAppstart.ToString());
                                //sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }

                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "LRN"))
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()))
                            {
                                ht138ECSRegNoCheck.Add(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                string strRegNo = ht138ECSRegNoCheck[dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()].ToString();
                                sbValues.Append("'" + strRegNo + "',");
                                continue;
                            }

                        }


                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "CIBILAN")
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["VU_AppAdd1"].ToString().Trim()))
                            {
                                ht138ECSLanCheck.Add(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["VU_AppAdd1"].ToString().Trim(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["VU_AppAdd1"].ToString().Trim()].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                                continue;
                            }

                        }


                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "DLNVPNML")
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim()))
                            {
                                ht138ECSLanCheck.Add(dRow["vu_ApplicantName"].ToString().Trim(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["vu_ApplicantName"].ToString().Trim()].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                                continue;
                            }

                        }


                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "DLNVPNML")
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["vu_ApplicantName"]))
                            {
                                ht138ECSRegNoCheck.Add(dRow["vu_ApplicantName"].ToString().Trim(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                string strRegNo = ht138ECSRegNoCheck[dRow["vu_ApplicantName"].ToString().Trim()].ToString();
                                sbValues.Append("'" + strRegNo + "',");
                                continue;
                            }

                        }

                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "DLNML")
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["vu_ApplicantName"]))
                            {
                                ht138ECSLanCheck.Add(dRow["vu_ApplicantName"], dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["vu_ApplicantName"]].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                                continue;
                            }

                        }



                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "DLNML")
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["vu_ApplicantName"]))
                            {
                                ht138ECSRegNoCheck.Add(dRow["vu_ApplicantName"], iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                string strRegNo = ht138ECSRegNoCheck[dRow["vu_ApplicantName"]].ToString();
                                sbValues.Append("'" + strRegNo + "',");
                                continue;
                            }

                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "CIBILAN")
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["VU_AppAdd1"].ToString().Trim()))
                            {
                                ht138ECSRegNoCheck.Add(dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["VU_AppAdd1"].ToString().Trim(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;

                                continue;
                            }
                            else
                            {
                                string strRegNo = ht138ECSRegNoCheck[dRow["vu_ApplicantName"].ToString().Trim() + "," + dRow["VU_AppAdd1"].ToString().Trim()].ToString();
                                sbValues.Append("'" + strRegNo + "',");
                                continue;
                            }

                        }

                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "138HFC")
                        {
                            if (!ht138ECSNumCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_LANNO"] + "," + dRow["VU_BOU_ChqNo"]))
                            {
                                ht138ECSNumCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_LANNO"] + "," + dRow["VU_BOU_ChqNo"], dAppstart.ToString());
                                //sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;
                                //continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }

                            if (!ht138ECSLanCheck.Contains(dRow["VU_ApplicantName"].ToString()))
                            {
                                ht138ECSLanCheck.Add(dRow["VU_ApplicantName"].ToString(), dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["VU_ApplicantName"]].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                            }


                        }




                        else if (strColName == "VU_MasterID" &&
                            (strGlbTemplateName == "138ECS"))
                        {
                            if (!ht138ECSLanCheck.Contains(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()))
                            {
                                ht138ECSLanCheck.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_LANNO"].ToString()
                                    , dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                            }

                            else
                            {
                                string strMasterId = ht138ECSLanCheck[dRow["VU_ApplicantName"].ToString().Trim() + "," +
                                    dRow["VU_LANNO"].ToString()].ToString();
                                sbValues.Append("'" + strMasterId + "',");
                            }


                            if (!ht138ECSNumCheck.Contains(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_LANNO"].ToString().Trim()
                                    + "," + dRow["VU_BOUECSNO"].ToString().Trim()))
                            {
                                ht138ECSNumCheck.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_LANNO"].ToString().Trim()
                                    + "," + dRow["VU_BOUECSNO"].ToString().Trim(), dAppstart.ToString());
                                //sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }


                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "138ECS"))
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()))
                            {
                                ht138ECSRegNoCheck.Add(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                string strRegNo = ht138ECSRegNoCheck[dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()].ToString();
                                sbValues.Append("'" + strRegNo + "',");
                                continue;
                            }

                        }


                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "138ECS" || strGlbTemplateName == "LRNA"
                            || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "138HFC"
                            ))
                        {
                            if (!ht138ECSRegNoCheck.Contains(dRow["VU_LANNO"].ToString()))
                            {
                                ht138ECSRegNoCheck.Add(dRow["VU_LANNO"].ToString(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                string strRegNo = ht138ECSRegNoCheck[dRow["VU_LANNO"]].ToString();
                                sbValues.Append("'" + strRegNo + "',");
                                continue;
                            }

                        }
                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "DLNAML")

                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }

                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "DLNA")

                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }


                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "VPN")

                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                       


                             #region DLNA MasterID
                        else if (strColName == "VU_MasterID" && strGlbTemplateName == "DLNA")
                        {
                            if (dRow["VU_ApplicantName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_ApplicantName"].ToString());
                                if (!htLocal.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()
                                        , dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }


                            }
                            if (dRow["VU_CoApplicantName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_CoApplicantName"].ToString());
                                if (!htLocal.Contains(dRow["VU_CoApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_CoApplicantName"]
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_CoApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_CoApplicantName"]
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }


                            if (dRow["VU_GurName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_GurName"].ToString());
                                if (!htLocal.Contains(dRow["VU_GurName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_GurName"] + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_GurName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurName"]
                                         + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }



                            if (!htGlbVPNCustomer.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htGlbVPNCustomer.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dAppstart.ToString());

                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        #endregion

                        #region VPN MasterID
                        if (strColName == "VU_MasterID" && (strGlbTemplateName == "VPN" || strGlbTemplateName == "LRNA"
                            || strGlbTemplateName == "DLNAML" || strGlbTemplateName == "LRNAML"
                            || strGlbTemplateName == "ODRN" || strGlbTemplateName == "SAWN"))
                        {
                            if (dRow["VU_ApplicantName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_ApplicantName"].ToString());
                                if (!htLocal.Contains(dRow["VU_ApplicantName"]))
                                {
                                    htLocal.Add(dRow["VU_ApplicantName"], dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_ApplicantName"]))
                                {
                                    htRegNoMapping.Add(dRow["VU_ApplicantName"], dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }


                            }
                            if (dRow["VU_CoApplicantName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_CoApplicantName"].ToString());
                                if (!htLocal.Contains(dRow["VU_CoApplicantName"]))
                                {
                                    htLocal.Add(dRow["VU_CoApplicantName"], dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_CoApplicantName"]))
                                {
                                    htRegNoMapping.Add(dRow["VU_CoApplicantName"], dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }


                            if (dRow["VU_GurName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_GurName"].ToString());
                                if (!htLocal.Contains(dRow["VU_GurName"]))
                                {
                                    htLocal.Add(dRow["VU_GurName"], dAppLocal.ToString());
                                    dAppLocal += 1;
                                }


                                if (!htRegNoMapping.Contains(dRow["VU_GurName"]))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurName"], dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }



                            if (!htGlbVPNCustomer.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            {
                                htGlbVPNCustomer.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dAppstart.ToString());

                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        #endregion

                        else if (strColName == "VU_DispatchMode" && (strGlbTemplateName == "SARL" || strGlbTemplateName == "DLN"
                            || strGlbTemplateName == "DLNHARD" || strGlbTemplateName == "DLNPP"
                            || strGlbTemplateName == "DLNSEG" || strGlbTemplateName == "ODRN"))
                        {
                            if (alSpList.Contains(dRow["VU_AppPincode"].ToString()))
                            {
                                sbValues.Append("'SP',");
                                continue;
                            }
                            else
                            {
                                sbValues.Append("'REG',");
                                continue;
                            }
                        }


                        else if (strColName == "VU_DispatchMode" && (strGlbTemplateName == "LRN"
                            || strGlbTemplateName == "LRNA" || strGlbTemplateName == "LRNAML"
                            ))
                        {
                            if (Convert.ToDouble(dRow["VU_TotalForclosureAmt"]) >= 500000)
                            {
                                sbValues.Append("'SP',");
                                continue;
                            }
                            else
                            {
                                sbValues.Append("'REG',");
                                continue;
                            }
                        }

                        else if (strColName == "VU_DispatchMode"
                           && (strGlbTemplateName == "138ECS" || strGlbTemplateName == "SEC138"
                           || strGlbTemplateName == "138HFC"))
                        {
                            sbValues.Append("'SP',");
                            continue;
                        }
                        else if (strColName == "VU_DispatchMode"
                            && (strGlbTemplateName == "VPN" || strGlbTemplateName == "CIBILAN"
                            || strGlbTemplateName == "DLNA" || strGlbTemplateName == "DLNML"
                            || strGlbTemplateName == "DLNAML" || strGlbTemplateName == "DLNVPN"
                            || strGlbTemplateName == "DLNVPNML" || strGlbTemplateName == "SAWN"))
                        {
                            sbValues.Append("'REG',");
                            continue;

                        }
                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "SARL"
                            || strGlbTemplateName == "DLN"
                            || strGlbTemplateName == "DLNHARD" || strGlbTemplateName == "DLNPP"
                             || strGlbTemplateName == "DLNSEG"
                            || strGlbTemplateName == "ODRN" 
                            || strGlbTemplateName == "SAWN"))
                        {
                            sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                            iGlbRegNo += 1;
                            continue;
                        }


                        else if (strColName == "VU_REGNO" && (strGlbTemplateName == "DLNVPN" || strGlbTemplateName == "DLNML"))
                        {
                            //if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"]))
                            //{
                            //    htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_LanNo"], dAppstart.ToString());

                            //    sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                            //    //dAppstart += 1;
                            //    continue;

                            //}
                            //else
                            //{
                            //    bExecute = false;
                            //    sbValues.Clear();
                            //    break;

                            //}

                            sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                            iGlbRegNo += 1;
                            continue;

                        }


                        else if (strColType == "Date")
                        {
                            bDate = ClsValidations.DateValidate(dRow[strColName].ToString(), strGlbTemplateName);
                            if (bDate)
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }
                        else if (strColType == "LAN")
                        {
                            bLan = ClsValidations.LanValidate(dRow[strColName].ToString(), strGlbTemplateName);


                            if (bLan)
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }

                        else if (strColType == "LANMASK")
                        {
                            string strLanMask = dRow["VU_LanNo"].ToString();
                            if (Regex.IsMatch(strLanMask, @"^[0-9]") && strLanMask.Length > 12)
                            {
                                string strLanReplace = Regex.Replace(strLanMask.Substring(3, strLanMask.Length - 7), ".", "X");
                                string strFinalLan = strLanMask.Substring(0, 4) +
                                    strLanReplace.Substring(1, strLanReplace.Length - 1) + strLanMask.Substring(strLanMask.Length - 4);
                                sbValues.Append("'" + strFinalLan + "',");

                            }

                            else
                            {
                                sbValues.Append("'" + strLanMask + "',");
                            }

                        }

                        else
                        {
                            sbValues.Append("'" + dRow[strColName].ToString() + "',");
                        }



                    }
                    if (bExecute)
                    {

                        string strTest = strColTest;

                        string strInsert = strInsQry + sbValues.ToString();

                        //sbValues.Replace()
                        strInsert = strInsert.Remove(strInsert.LastIndexOf(","));
                        strInsert += ")";

                        string strAppp = dAppstart.ToString();
                        string strRegNo = dRegNostart.ToString();

                        
                            


                            #region DLNA Upload logic

                        if ( strGlbTemplateName == "DLNA")
                        {
                            string strDeletermp;
                            if (alApplicants.Count == 1)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"] 
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    //string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                    //strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                }
                            }
                            if (alApplicants.Count == 2)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"] 
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {

                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    //strApppReplace = htLocal[dRow["VU_CoApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + 
                                        "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);


                                }

                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_GurName"]
                                    + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {

                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    //strApppReplace = htLocal[dRow["VU_CoApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'",
                                        alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);


                                }

                                else
                                {

                                }
                            }

                            if (alApplicants.Count == 3)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {


                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"] + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {

                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", 
                                        alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);


                                    strRegNo = htRegNoMapping[dRow["VU_CoApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                }

                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"]
                                    + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {

                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'",
                                        alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_CoApplicantName"]
                                        + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);
                                }


                                else
                                {

                                }
                            }






                            dAppstart += alApplicants.Count;
                            dRegNostart += alApplicants.Count;
                            iGlbRegNo += alApplicants.Count;
                            if (strGlbTemplateName == "DLNA" || strGlbTemplateName == "VPN" || strGlbTemplateName == "DLNAML")
                            {
                                strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(alApplicants.Count)).ToString();
                            }

                        }
                        #endregion


                        #region VPN Upload logic

                        if (strGlbTemplateName == "VPN" || strGlbTemplateName == "LRNA"
                             || strGlbTemplateName == "DLNAML"
                            || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "ODRN"
                            || strGlbTemplateName == "SAWN")
                        {
                            string strDeletermp;
                            if (alApplicants.Count == 1)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"]))
                                {
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    //string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                    //strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"]].ToString();
                                }
                            }
                            if (alApplicants.Count == 2)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"]))
                                {
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"]].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"]))
                                {

                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"]].ToString();


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    //strApppReplace = htLocal[dRow["VU_CoApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);


                                }

                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_GurName"]))
                                {

                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"]].ToString();


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    //strApppReplace = htLocal[dRow["VU_CoApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");


                                    ExcuteDML(strInsert);


                                }

                                else
                                {

                                }
                            }

                            if (alApplicants.Count == 3)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"]))
                                {


                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"]].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"]].ToString();

                                }


                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"]))
                                {

                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"]].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "','dummy'", alApplicants[1].ToString() + "','dummy'");

                                    ExcuteDML(strInsert);


                                    strRegNo = htRegNoMapping[dRow["VU_CoApplicantName"]].ToString();
                                }

                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"]))
                                {

                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"]].ToString();

                                    strInsert = strInsert.Replace(alApplicants[1].ToString() + "','dummy'", alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"]].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_CoApplicantName"]].ToString(), strApppReplace);
                                    ExcuteDML(strInsert);
                                }


                                else
                                {

                                }
                            }






                            dAppstart += alApplicants.Count;
                            dRegNostart += alApplicants.Count;
                            iGlbRegNo += alApplicants.Count;
                            if (strGlbTemplateName == "DLNA" || strGlbTemplateName == "VPN" || strGlbTemplateName == "DLNAML")
                            {
                                strGlbAppstartID = (Convert.ToDouble(strGlbAppstartID) + Convert.ToDouble(alApplicants.Count)).ToString();
                            }

                        }
                        #endregion

                        else
                        {
                            ExcuteDML(strInsert);
                            string strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                            ExcuteDML(strDeletermp);
                        }
                    }
                    sbValues.Clear();
                    alApplicants.Clear();
                    //string test = testCol;

                }


                string strUpdateRegNo = "update lpo_templatemaster set curRegNo = " + iGlbRegNo.ToString() + " where TemplateId = " + iTempIndex.ToString();
                ExcuteDML(strUpdateRegNo);

                if (strGlbTemplateName == "DLN" || strGlbTemplateName == "DLNPP"
                    || strGlbTemplateName == "DLNHARD" || strGlbTemplateName == "SARL"
                    || strGlbTemplateName == "VPN" || strGlbTemplateName == "CIBILAN"
                    || strGlbTemplateName == "LRN" || strGlbTemplateName == "138ECS"
                    || strGlbTemplateName == "LRNA" || strGlbTemplateName == "DLNA"
                   || strGlbTemplateName == "DLNML" || strGlbTemplateName == "DLNAML"
                   || strGlbTemplateName == "LRNAML" || strGlbTemplateName == "SEC138"
                   || strGlbTemplateName == "DLNVPN" || strGlbTemplateName == "DLNVPNML"
                   || strGlbTemplateName == "138HFC" || strGlbTemplateName == "SAWN")
                {
                    string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'LOAN' where " +
                        "VU_LanNo REGEXP '^[A-Z]' and VU_TemplateName = '" + strGlbTemplateName +
                        "' AND VU_FileName = '" + strGlbFileName + "';";
                    ExcuteDML(strUpdateLoanCard);

                    strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'CARD' where " +
                        "VU_LanNo REGEXP '^[0-9]' and VU_TemplateName = '" + strGlbTemplateName +
                        "' AND VU_FileName = '" + strGlbFileName + "';";
                    ExcuteDML(strUpdateLoanCard);
                }


                if (strGlbTemplateName == "DLNSEG" || strGlbTemplateName == "ODRN")
                {
                    string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'LOAN' where " +
                        "VU_LanNo REGEXP '^[0-9]' and VU_TemplateName = '" + strGlbTemplateName +
                        "' AND VU_FileName = '" + strGlbFileName + "';";
                    ExcuteDML(strUpdateLoanCard);
                }



            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message + "  " + icntTest.ToString());
            }
        }

        private static void InsertIntoUploadtbl(int iTempIndex, string strUploadTbl, DataTable dtExcelData)
        {
            DataTable dtCol = new DataTable();
            StringBuilder sbCol = new StringBuilder();
            StringBuilder sbValues = new StringBuilder();
            int iColCnt = dtExcelData.Columns.Count;
            double dAppstart = Convert.ToDouble(strGlbAppstartID);
            strGlbCol = string.Empty;
            htGlbColTyp = new Hashtable();
            try
            {
                string strTruncate = "TRUNCATE TABLE " + strUploadTbl;
                ExcuteDML(strTruncate);
                string strColQry = "select a.Col_ID,b.Col_ID,a.DB_ColName,b.ExcelColName, b.Type from lpo_genericcolmaster a  JOIN lpo_excelcolmappingmaster b " +
                                   "ON a.Col_ID = b.Col_ID and b.TemplateID = " + iTempIndex.ToString() + " order by b.ExcelSquenceId;";
                dtCol = GetData(strColQry);
                if (dtCol.Rows.Count > 0)
                {
                    foreach (DataRow row in dtCol.Rows)
                    {
                        if (!htGlbColTyp.Contains(row["DB_ColName"]))
                        {
                            htGlbColTyp.Add(row["DB_ColName"].ToString(), row["Type"].ToString());
                        }
                        sbCol.Append(row["DB_ColName"].ToString() + ",");
                    }
                }

                strGlbCol = sbCol.ToString();
                strGlbCol = strGlbCol.Remove(strGlbCol.LastIndexOf(","));
                sbCol.Clear();
                string strInsQry = "Insert into " + strUploadTbl + "( " + strGlbCol + ") Values (";
                //sbCol.Clear();

                //foreach (DataRow dRow in dtExcelData.Rows)
                //{
                //    foreach (DataColumn col in dtExcelData.Columns)
                //    {
                //        string strColName = col.ColumnName;

                //        if (strColName == "VU_MasterID")
                //        {
                //            sbValues.Append("'" + dAppstart.ToString() + "',");
                //            dAppstart += 1;
                //            continue;
                //        }
                //        sbValues.Append("'" + dRow[strColName].ToString() + "',");

                //    }


                //    ////sbValues.Append("'" + strFileName + "',");
                //    sbValues.Append(")");



                foreach (DataRow dRow in dtExcelData.Rows)
                {

                    for (int i = 0; i < iColCnt; i++)
                    {

                        string strRepSingleQuote = dRow[i].ToString();
                        strRepSingleQuote = strRepSingleQuote.Replace("'", "");
                        sbValues.Append("'" + strRepSingleQuote + "',");
                    }

                    //string strTest = sbValues.ToString();

                    sbValues.Append("'" + strGlbFileName + "',");
                    sbValues.Append("'" + dAppstart.ToString() + "',");

                    //string strTest = sbValues.ToString();
                    sbValues.Append("'RegNo',");
                    sbValues.Append("'" + strGlbBatchID + "',");
                    sbValues.Append("'DispatchMode',");
                    sbValues.Append("'" + strGlbTemplateName + "',");
                    sbValues.Append("'" + DateTime.Now.ToShortDateString() + "',");
                    sbValues.Append("'N',");
                    sbValues.Append("'TestMapping',");
                    sbValues.Append("'dummy',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");


                    if (strGlbTemplateName.StartsWith("DLN") || strGlbTemplateName.StartsWith("138ECS")
                        || strGlbTemplateName.StartsWith("SEC138") || strGlbTemplateName.StartsWith("138HFC"))
                    {
                        sbValues.Append("'',");
                        sbValues.Append("'',");
                        sbValues.Append("'',");
                        sbValues.Append("'',");
                        sbValues.Append("'',");
                        sbValues.Append("'',");
                        sbValues.Append("'',");
                        sbValues.Append("'',");
                        sbValues.Append("'',");
                        sbValues.Append("'',");
                        sbValues.Append("'')");

                    }
                    else
                    {
                        sbValues.Append("'',");
                        sbValues.Append("'')");
                    }


                    dAppstart += 1;
                    string strInsert = strInsQry + sbValues.ToString();
                    sbValues.Clear();
                    ExcuteDML(strInsert);

                }




                if (strGlbTemplateName == "DLN" || strGlbTemplateName == "DLNHARD"
                    || strGlbTemplateName == "DLNPP" || strGlbTemplateName == "DLNSEG"
                    || strGlbTemplateName == "138ECS" || strGlbTemplateName == "DLNA"
                    || strGlbTemplateName == "DLNML" || strGlbTemplateName == "DLNAML"
                    || strGlbTemplateName == "SEC138" || strGlbTemplateName == "DLNVPN"
                    || strGlbTemplateName == "DLNVPNML" || strGlbTemplateName == "138HFC")
                {
                    string strAdvUpdate = "update " + strUploadTbl + " r join lpo_advmaster a on r.VU_Advocate = a.VU_AdvCity " +
                        "set r.VU_SignaturePath = a.VU_SignPath, r.VU_AdvName = a.VU_AdvName, r.VU_AdvDegree = a.VU_AdvDegree, " +
                        "r.VU_AdvAdd1 = a.VU_AdvAdd1, r.VU_AdvAdd2 = a.VU_AdvAdd2, r.VU_AdvAdd3 = a.VU_AdvAdd3, r.VU_AdvAdd4 = a.VU_AdvAdd4," +
                        "r.VU_AdvCity = a.VU_AdvCity, r.VU_AdvPinCode = a.VU_AdvPinCode,r.VU_AdvRegNo = a.VU_AdvRegNo";
                    ExcuteDML(strAdvUpdate);
                }


                if (strGlbTemplateName == "DLN" || strGlbTemplateName == "SARL"
                    || strGlbTemplateName == "DLNSEG" || strGlbTemplateName == "DLNHARD"
                    || strGlbTemplateName == "DLNPP")
                {
                    string strDispUpdate = "update  lpo_trnupload r join lpo_pincodematser a on r.VU_AppPinCode = a.VU_PinCode " +
                                            "set r.VU_DispatchMode = 'SP'";
                    ExcuteDML(strDispUpdate);
                    strDispUpdate = "update  lpo_trnupload set VU_DispatchMode = 'REG' where VU_DispatchMode <> 'SP'";
                    ExcuteDML(strDispUpdate);
                }


                //5,00,000
                if (strGlbTemplateName == "LRN" || strGlbTemplateName == "LRNA" || strGlbTemplateName == "LRNAML")
                {
                    string strDispUpdate = "update  lpo_trnupload set VU_DispatchMode = 'SP' where (VU_TotalForclosureAmt * 1) > 499999";
                    ExcuteDML(strDispUpdate);
                    strDispUpdate = "update  lpo_trnupload set VU_DispatchMode = 'REG' where VU_DispatchMode <> 'SP'";
                    ExcuteDML(strDispUpdate);
                }


                if (strGlbTemplateName == "ODRN" || strGlbTemplateName == "ODRS")
                {
                    string strDispUpdate = "update  lpo_trnupload set VU_DispatchMode = '" + strGlbOdrnDispType + "'";
                    ExcuteDML(strDispUpdate);
                }

            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        public static bool ExcuteDML(string strQry)
        {
            try
            {

                if (con.State.ToString() != "Closed")
                {
                    OdbcCommand cmd;
                    cmd = new OdbcCommand(strQry, con);
                    cmd.ExecuteNonQuery();
                }
                else
                {
                    Connect();
                    OdbcCommand cmd;
                    cmd = new OdbcCommand(strQry, con);
                    cmd.ExecuteNonQuery();
                }
                //}
                return true;
            }
            catch (Exception Ex)
            {
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return false;

            }
            con.Close();

        }
        internal static DataTable getExcelData()
        {
            DataTable dtExcelData = new DataTable();

            try
            {
                string strXlsQry = "select * from [Sheet1$]";
                OleDbCommand cmdExcel = new OleDbCommand(strXlsQry, conExcel);
                dtExcelData.Load(cmdExcel.ExecuteReader());

                return dtExcelData;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return dtExcelData;
            }
        }

        public static bool ExcelCon(string strFile)
        {
            try
            {
                strGlbFileName = Path.GetFileNameWithoutExtension(strFile);
                strGlbInputFilePath = strFile;
                bool bConState = false;
                if (Path.GetExtension(strFile) == ".xls")
                {
                    // conExcel.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strFile + ";Extended Properties=Excel 12.0;";
                    conExcel.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strFile + ";Extended Properties=Excel 8.0;Persist Security Info=False";
                }
                else if (Path.GetExtension(strFile) == ".xlsx")
                {
                    conExcel.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strFile + ";Extended Properties=Excel 8.0;Persist Security Info=False";
                }

                if (conExcel.State == 0)
                {
                    conExcel.Open();
                    bConState = true;
                }
                return bConState;

            }
            catch (Exception Ex)
            {

                conExcel.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return false;
            }
        }

        internal static void cmbFill(frmUpload frmUpload)
        {
            ComboBox cmbCntrl;
            DataTable dtCmb = new DataTable();
            try
            {
                // Connect();
                int iCnt = 1;
                string strCmbQry = "select distinct TemplateName, TemplateID  from lpo_templatemaster order by TemplateID;";
                cmbCntrl = (ComboBox)frmUpload.Controls.Find("cmbTemplate", true).FirstOrDefault();
                dtCmb = GetData(strCmbQry);
                cmbCntrl.Items.Insert(0, "-SELECT TEMPLATE-");
                foreach (DataRow row in dtCmb.Rows)
                {
                    cmbCntrl.Items.Insert(Convert.ToInt32(row["TemplateID"]), row["TemplateName"].ToString());
                    iCnt++;
                }

                cmbCntrl.SelectedIndex = 0;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        public static DataTable GetData(string strQry)
        {
            DataTable dtGetData = new DataTable();
            try
            {
                //if (Connect() == true)
                //{
                OdbcCommand Com;
                Com = new OdbcCommand(strQry, con);
                dtGetData.Load(Com.ExecuteReader());
                return dtGetData;
                //}

            }
            catch (Exception Ex)
            {
                //con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return null;
                //throw;
            }
            return dtGetData;
        }

    }
}
