﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LPO_Dev
{ 
    public partial class MDIParent : Form
    {
        private int childFormNumber = 0;

        public MDIParent()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void MDIParent_Load(object sender, EventArgs e)
        {
            this.IsMdiContainer = true;
            this.Controls.Add(mnuStrip);

            String SqlMenu = "SELECT distinct  b.MenuID,b.MenuName FROM vu_admin_menuaccessmast  as a inner join vu_admin_menumaster as b on a.Menu_Id_fk = b.MenuID  where Group_Id_fk = '" + ClsProperty.UserTypeID + "'  and b.IsFlag = 'Y'  order by MenuID";
            clsMain.Connect();
            DataTable dtMenu = new DataTable();
            dtMenu = clsMain.GetData(SqlMenu);

            foreach (DataRow dr in dtMenu.Rows)
            {
                ToolStripMenuItem MnuStripItem = new ToolStripMenuItem(dr["MenuName"].ToString());
                SubMenu(MnuStripItem, dr["MenuID"].ToString());
                mnuStrip.Items.Add(MnuStripItem);
            }          
            this.MainMenuStrip = mnuStrip;
            this.MainMenuStrip.Height = 50;
            this.MainMenuStrip.ForeColor = Color.White;
            this.MainMenuStrip.Cursor = Cursors.Hand;


        }

        public void SubMenu(ToolStripMenuItem mnu, string submenu)
        {
           
            String Seqchild = "SELECT distinct b.SubMenu_Id,  b.SubMenu_Id,b.Sub_Menu_Name FROM vu_admin_menuaccessmast  as a inner join vu_admin_submenumaster as b on a.Menu_Id_fk = b.Menu_Id_fk  and a.SubMenu_Id_fk = b.SubMenu_Id "
         + "where Group_Id_fk = '" + ClsProperty.UserTypeID + "'  and a.Menu_Id_fk ='" + submenu + "' order by b.SubMenu_Id";
            DataTable dtchild = new DataTable();
            dtchild = clsMain.GetData(Seqchild);
            foreach (DataRow dr in dtchild.Rows)
            {

                ToolStripMenuItem SSMenu = new ToolStripMenuItem(dr["Sub_Menu_Name"].ToString(), null, new EventHandler(ChildClick));
                mnu.DropDownItems.Add(SSMenu);



            }

        }
      

        private void ChildClick(object sender, EventArgs e)
        {

            String Seqtx = "select Sub_Menu_URL from vu_admin_submenumaster WHERE Sub_Menu_Name='" + sender.ToString() + "'";
            DataTable dtransaction = new DataTable();
            dtransaction = clsMain.GetData(Seqtx);

            Assembly frmAssembly = Assembly.LoadFile(Application.ExecutablePath);
            foreach (Type type in frmAssembly.GetTypes())
            {
                if (type.BaseType == typeof(Form))
                {
                    if (type.Name == dtransaction.Rows[0][0].ToString())
                    {
                        Form frmShow = (Form)frmAssembly.CreateInstance(type.ToString());
                        foreach (Form form in this.MdiChildren)
                        {
                            form.Close();
                        }

                        frmShow.MdiParent = this;
                      
                        frmShow.Show();
                    }

                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UpdateLoginFlag();
          
            MDIParent ObjMdi = new MDIParent();
            ObjMdi.Close();

        }
        public void UpdateLoginFlag()
        {
            try
            {

                DateTime OutTime = DateTime.Now;
                string MachineName = ClsProperty.Machine;
                string UserName = ClsProperty.UserName;
                clsMain.Connect();
                bool IsUpdate = clsMain.ExcuteDML("Update VU_Admin_UserInfo  set LOGIN='N'"
                    + " WHERE USER_NAME='" + UserName.Trim() + "'  AND sysname='" + MachineName + "' ");
                bool IsUpdateLog = clsMain.ExcuteDML("Update vu_admin_user_log  set OUTTIME='" + OutTime.ToString("hh:mm:ss") + "'"
                    + "WHERE USER_ID='" + UserName.Trim() + "'  AND sysname='" + MachineName + "' ");
                if (IsUpdate == true && IsUpdateLog == true)
                {
                    this.Hide();
                    Login frmlgin = new Login();
                    frmlgin.Show();

                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void MDIParent_FormClosing(object sender, FormClosingEventArgs e)
        {
            UpdateLoginFlag();

        }

        private void mnuStrip_MouseMove(object sender, MouseEventArgs e)
        {
            this.MainMenuStrip.ForeColor = Color.Black;
        }

        private void mnuStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void statusStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
