﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{

    public static class ClsValidations
    {
        public static ArrayList alLan = new ArrayList();
        internal static bool LanValidate(string strLan, string strTemplate)
        {
            try
            {

                if (strTemplate == "DLNAML"  || strTemplate == "DLNHARD" || strTemplate == "DLNPP"
                     || strTemplate == "DLNVPN" || strTemplate == "DLNVPNML"
                     || strTemplate == "CIBILAN" )
                {

                    if (!alLan.Contains(strLan))
                    {
                        alLan.Add(strLan);
                        bool bDLN = false;
                        bDLN = LanLengthValidate(strLan, strTemplate);
                        return bDLN;
                    }
                }


                if (strTemplate == "138ECS" || strTemplate == "SEC138"
                    || strTemplate == "138HFC" || strTemplate == "DLNML"
                    || strTemplate == "LRNA" || strTemplate == "LRNAML" || strTemplate == "SAWN"
                    || strTemplate == "SARL" || strTemplate == "LRN" || strTemplate == "DLNSEG" || strTemplate == "DLN"
                    || strTemplate == "SARFCBSS" || strTemplate == "ODRS" || strTemplate == "SARFCBUS" || strTemplate == "SARF13_2_IB"
                    || strTemplate == "DLNA" || strTemplate == "VPN" || strTemplate == "ODRN")
                {
                    bool bDLN = false;
                    bDLN = LanLengthValidate(strLan, strTemplate);
                    return bDLN;
                }

                return false;

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return false;
            }
        }

        internal static bool LanLengthValidate(string strLan, string strTemplate)
        {
            try
            {

                if (strLan.Length == 16 && (strTemplate == "LRNA" || strTemplate == "VPN"
                    || strTemplate == "CIBILAN" || strTemplate == "LRNAML" || strTemplate == "SAWN"
                    || strTemplate == "SARL" || strTemplate == "LRN" || strTemplate == "SARFCBSS" || strTemplate == "SARF13_2_IB" ))
                {
                    bool bFlag = false;

                    if (strLan.Length == 16)
                    {
                        bFlag = strLan.All(char.IsLetterOrDigit);
                    }
                    return bFlag;
                }

                else if ((strLan.Length == 16 || strLan.Length == 15) && (strTemplate == "138ECS"
                    || strTemplate == "SEC138" || strTemplate == "138HFC" || strTemplate == "DLNML"
                    || strTemplate == "DLNAML" || strTemplate == "DLN" || strTemplate == "DLNVPN"
                    || strTemplate == "DLNVPNML" || strTemplate == "DLNA" || strTemplate == "DLNPP"
                    || strTemplate == "DLNHARD" || strTemplate == "SARFCBUS"))
                {
                    bool bFlag = false;

                    if (strLan.Length == 16 || strLan.Length == 15)
                    {
                        bFlag = strLan.All(char.IsDigit);
                    }

                    if (strLan.Length == 16 && !bFlag)
                    {
                        bFlag = strLan.All(char.IsLetterOrDigit);
                    }
                        return bFlag;
                }
                else if (strLan.Length == 12 && (strTemplate == "DLNSEG"
                    || strTemplate == "ODRN" || strTemplate == "ODRS"))
                {
                    bool bFlag = false;
                    bFlag = strLan.All(char.IsDigit);
                    return bFlag;


                    //for (int i = 0; i < strLan.Length - 1; i++)
                    //{
                    //    if (!char.IsDigit(strLan[i]))
                    //    {
                    //        return false;
                    //    }
                    //}
                   // return true;
                }
                else
                {
                    return false;
                }
            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return false;
            }
        }
        internal static bool DateValidate(string strDt, string strTemplate)
        {
            try
            {

                DateTime dtNow = DateTime.Now;
                DateTime dtExcel = Convert.ToDateTime(strDt);
                if (dtExcel > dtNow)
                {
                    return false;
                }

                return true;

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return false;
            }


        }
    }
}
