﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    public partial class frmTest : Form
    {
        OdbcConnection con = new OdbcConnection();
        ConnectionString concs = new ConnectionString();
        DataTable dt = new DataTable();
        DataTable dt1 = new DataTable();

        public frmTest()
        {
            InitializeComponent();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            txtPath.Text = "";

            ofdbox.Filter = "excelfile|*.xls";
            ofdbox.ShowDialog();
            txtPath.Text = ofdbox.FileName;
            ToolTip1.SetToolTip(txtPath, txtPath.Text);
            ToolTip1.SetToolTip(btnSelect, txtPath.Text);
            if (!string.IsNullOrEmpty(txtPath.Text))
            {
                btnSelect.Enabled = false;
                txtPath.Enabled = false;
                //btnView.Enabled = true;
                //btnView.BackColor = Color.Red;
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            if (txtPath.Text == "")
            {
                MessageBox.Show("Please Select a File to Upload...");
                btnSelect.Focus();
                btnSelect.BackColor = Color.Red;
                return;
            }
            //dataGridView1
            //dataGridView1.Rows.Clear();
            //dataGridView1.Refresh();
            dataGridView1.DataSource = null;
            dataGridView2.DataSource = null;
            //dataGridView2.Rows.Clear();
            //dataGridView2.Refresh();
            if(rtbADUpload.Checked == true)
            {
                Upload_Pod();
            }
            else if(rtbrtoupload.Checked == true)
            {
                Upload_RTO();
            }
            else if(rbtDispatch.Checked==true)
            {
                Upload_Dispatch();
            }
            else if(rbtRetrival.Checked==true)
            {
                Upload_Retrival();
            }
            else
            {
                MessageBox.Show("PLEASE SELECT MODE ");
            }

        }
        public void Upload_Retrival()
        {
            if (txtPath.Text == "")
            {
                MessageBox.Show("Plaese Select File For Upload");
                return;
            }
            else
            {
                string ORGFNAME = concs.GetFileName(txtPath.Text);
                DataTable dtSucess = new DataTable("SucessData");
                DataTable dtGet = new DataTable("ExcelData");
                dtGet = concs.GetExcel(txtPath.Text);
                if (dtGet.Rows.Count > 0)
                {
                    int excelct = Convert.ToInt32(dtGet.Columns.Count);
                    string ExcelRecordCt = Convert.ToString(dtGet.Rows.Count);
                    if (excelct != 5)
                    {
                        MessageBox.Show("File Formate Not Correct ..");
                        return;
                    }
                    DialogResult dialogResult = MessageBox.Show(dtGet.Rows.Count + " -- Record To Upload Is this Correct? ", "Some Title", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        dtGet.Columns[0].ColumnName = "Inward_No";
                        dtGet.Columns[1].ColumnName = "Retrival_Name";
                        dtGet.Columns[2].ColumnName = "Retrival_Date";
                        dtGet.Columns[3].ColumnName = "Dispach_Mode";
                        dtGet.Columns[4].ColumnName = "SP_REG_NO";
                        dtGet.Columns.Add("Status", typeof(string));
                        dtGet.Columns.Add("Reject_Reason", typeof(string));
                        dtGet.Columns.Add("Notice_Type", typeof(string));
                        dtGet.Columns.Add("Table_Name", typeof(string));
                       // dtGet.Columns.Add("Registrion_No", typeof(string));

                        //Check for the mandatory values
                        DataRow[] rowsFiltered = dtGet.Select("[Inward_No] is null ");
                        if (rowsFiltered.Length > 0)
                        {
                            foreach (DataRow row in rowsFiltered)
                            {
                                row["Status"] = 'I';
                                row["Reject_Reason"] = "Mandatory Values Is Missing.";
                                dtGet.AcceptChanges();
                                row.SetModified();
                            }
                        }

                        //Get All Sucess Data
                        dtSucess = new DataTable("SucessData");
                        dtSucess = GetSucessData();

                        //Update Table Name And Notice Type
                        var query =
                                from tbl1 in dtGet.AsEnumerable()
                                join tbl2 in dtSucess.AsEnumerable() on tbl1["Inward_No"] equals tbl2["VU_RTO_POD_Inword_No"]
                                select new { Field1 = tbl2["VU_TemplateName"], Field2 = tbl1["Inward_No"] };
                        foreach (var row in query)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[Inward_No] = '" + row.Field2 + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Notice_Type"] = row.Field1;
                                row1["Table_Name"] = "lpo_trnsuccess";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }

                        //Check Notice Type And Table Name Is Blank
                        DataRow[] rowsNotice = dtGet.Select("[Notice_Type] is null Or [Table_Name] is null ");
                        if (rowsNotice.Length > 0)
                        {
                            foreach (DataRow row in rowsNotice)
                            {
                                row["Status"] = 'I';
                                row["Reject_Reason"] = "Table Name And Notice Type Is Missing";
                                dtGet.AcceptChanges();
                                row.SetModified();
                            }
                        }



                        DataRow[] rowsValid = dtGet.Select("[Status] is  Null ");
                        //IEnumerable<DataRow> rowsValid = dtGet.AsEnumerable().Where(r => r.IsNull("Status"));
                        //dataGridView1.DataSource = dtGet.Select("[Status] !=  null Or [Reject_Reason] != Not null ");
                        dt = new DataTable();
                        dt.Columns.Add("Inword No");
                        dt.Columns.Add("Retrival Name");
                        dt.Columns.Add("Retrival Date");
                        dt.Columns.Add("Dispatch Mode");
                        dt.Columns.Add("Sp Reg No");
                        dt.Columns.Add("Status");
                        dt.Columns.Add("Reject Reason");
                        dt.Columns.Add("Notice Type");
                        dt.Columns.Add("Table Name");
                       

                        DataRow ro;
                        if (rowsValid.Length > 0)
                        {
                            foreach (DataRow row in rowsValid)
                            {
                                ro = dt.NewRow();
                                ro["Inword No"] = row[0];
                                ro["Retrival Name"] = row[1];
                                ro["Retrival Date"] = row[2];
                                ro["Dispatch Mode"] = row[3];
                                ro["Sp Reg No"] = row[4];
                                ro["Status"] = row[5];
                                ro["Reject Reason"] = row[6];
                                ro["Notice Type"] = row[7];
                                ro["Table Name"] = row[8];

                                dt.Rows.Add(ro);

                                dataGridView1.DataSource = dt;
                                dataGridView1.Refresh();
                                dataGridView1.AutoResizeColumns();
                                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                                lblrct.Visible = true;
                                lblct.Visible = true;
                                lblct.Text = Convert.ToString((Convert.ToInt32(dataGridView1.Rows.Count.ToString()) - 1));
                                btnMatchMIS.Enabled = true;

                            }
                        }


                        DataRow[] rowsValid1 = dtGet.Select("[Status] is Not  Null ");
                        //IEnumerable<DataRow> rowsValid = dtGet.AsEnumerable().Where(r => r.IsNull("Status"));
                        //dataGridView1.DataSource = dtGet.Select("[Status] !=  null Or [Reject_Reason] != Not null ");
                        dt1 = new DataTable();
                        dt1.Columns.Add("Inword No");
                        dt1.Columns.Add("Retrival Name");
                        dt1.Columns.Add("Retrival Date");
                        dt1.Columns.Add("Dispatch Mode");
                        dt1.Columns.Add("Sp Reg No");
                        dt1.Columns.Add("Status");
                        dt1.Columns.Add("Reject Reason");
                        dt1.Columns.Add("Notice Type");
                        dt1.Columns.Add("Table Name");

                        DataRow ro1;
                        if (rowsValid1.Length > 0)
                        {
                            foreach (DataRow row in rowsValid1)
                            {
                                ro1 = dt1.NewRow();
                                ro1["Inword No"] = row[0];
                                ro1["Retrival Name"] = row[1];
                                ro1["Retrival Date"] = row[2];
                                ro1["Dispatch Mode"] = row[3];
                                ro1["Sp Reg No"] = row[4];
                                ro1["Status"] = row[5];
                                ro1["Reject Reason"] = row[6];
                                ro1["Notice Type"] = row[7];
                                ro1["Table Name"] = row[8];

                                dt1.Rows.Add(ro1);

                                dataGridView2.DataSource = dt1;
                                dataGridView2.Refresh();
                                dataGridView2.AutoResizeColumns();
                                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                                label5.Visible = true;
                                lblunmatch.Visible = true;
                                lblunmatch.Text = Convert.ToString((Convert.ToInt32(dataGridView2.Rows.Count.ToString()) - 1));
                                btnUnmatchMIS.Enabled = true;

                            }
                        }

                        MessageBox.Show("Match And UnMatch Case Record Display Is Both GridView");






                    }
                    else if (dialogResult == DialogResult.No)
                    {

                    }
                }
                else
                {
                    MessageBox.Show("No Record Found In Excel For Update And Show In GridView");
                }
            }
        }
        public void Upload_Dispatch()
        {
            if (txtPath.Text == "")
            {
                MessageBox.Show("Plaese Select File For Upload");
                return;
            }
            else
            {
                string ORGFNAME = concs.GetFileName(txtPath.Text);
                DataTable dtSucess = new DataTable("SucessData");
                DataTable dtGet = new DataTable("ExcelData");
                dtGet = concs.GetExcel(txtPath.Text);
                if (dtGet.Rows.Count > 0)
                {
                    int excelct = Convert.ToInt32(dtGet.Columns.Count);
                    string ExcelRecordCt = Convert.ToString(dtGet.Rows.Count);
                    if (excelct != 4)
                    {
                        MessageBox.Show("File Formate Not Correct ..");
                        return;
                    }
                    DialogResult dialogResult = MessageBox.Show(dtGet.Rows.Count + " -- Record To Upload Is this Correct? ", "Some Title", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        dtGet.Columns[0].ColumnName = "VU_Master_ID";
                        dtGet.Columns[1].ColumnName = "Speed Post Number";
                        dtGet.Columns[2].ColumnName = "Date";
                        dtGet.Columns[3].ColumnName = "Mode Of Dispatch";
                        dtGet.Columns.Add("Status", typeof(string));
                        dtGet.Columns.Add("Reject_Reason", typeof(string));

                        //Check for the mandatory values
                        DataRow[] rowsFiltered = dtGet.Select("[VU_Master_ID] is null ");
                        if (rowsFiltered.Length > 0)
                        {
                            foreach (DataRow row in rowsFiltered)
                            {
                                row["Status"] = 'I';
                                row["Reject_Reason"] = "Mandatory Values Is Missing.";
                                dtGet.AcceptChanges();
                                row.SetModified();
                            }
                        }


                        DataRow[] rowsValid = dtGet.Select("[Status] is  Null ");
                        //IEnumerable<DataRow> rowsValid = dtGet.AsEnumerable().Where(r => r.IsNull("Status"));
                        //dataGridView1.DataSource = dtGet.Select("[Status] !=  null Or [Reject_Reason] != Not null ");
                         dt = new DataTable();
                        dt.Columns.Add("Master ID");
                        dt.Columns.Add("Speed Post Number");
                        dt.Columns.Add("Date");
                        dt.Columns.Add("Mode Of Dispatch");
                        dt.Columns.Add("Status");
                        dt.Columns.Add("Reject Reason");
                        

                        DataRow ro;
                        if (rowsValid.Length > 0)
                        {
                            foreach (DataRow row in rowsValid)
                            {
                                ro = dt.NewRow();
                                ro["Master ID"] = row[0];
                                ro["Speed Post Number"] = row[1];
                                ro["Date"] = row[2];
                                ro["Mode Of Dispatch"] = row[3];
                                ro["Status"] = row[4];
                                ro["Reject Reason"] = row[5];
                                
                                dt.Rows.Add(ro);

                                dataGridView1.DataSource = dt;
                                dataGridView1.Refresh();
                                dataGridView1.AutoResizeColumns();
                                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                                lblrct.Visible = true;
                                lblct.Visible = true;
                                lblct.Text = Convert.ToString((Convert.ToInt32(dataGridView1.Rows.Count.ToString()) - 1));
                                btnMatchMIS.Enabled = true;

                            }
                        }


                        DataRow[] rowsValid1 = dtGet.Select("[Status] is Not  Null ");
                        //IEnumerable<DataRow> rowsValid = dtGet.AsEnumerable().Where(r => r.IsNull("Status"));
                        //dataGridView1.DataSource = dtGet.Select("[Status] !=  null Or [Reject_Reason] != Not null ");
                         dt1 = new DataTable();
                        dt1.Columns.Add("Master ID");
                        dt1.Columns.Add("Speed Post Number");
                        dt1.Columns.Add("Date");
                        dt1.Columns.Add("Mode Of Dispatch");
                        dt1.Columns.Add("Status");
                        dt1.Columns.Add("Reject Reason");

                        DataRow ro1;
                        if (rowsValid1.Length > 0)
                        {
                            foreach (DataRow row in rowsValid1)
                            {
                                ro1 = dt1.NewRow();
                                ro1["Master ID"] = row[0];
                                ro1["Speed Post Number"] = row[1];
                                ro1["Date"] = row[2];
                                ro1["Mode Of Dispatch"] = row[3];
                                ro1["Status"] = row[4];
                                ro1["Reject Reason"] = row[5];

                                dt1.Rows.Add(ro1);

                                dataGridView2.DataSource = dt1;
                                dataGridView2.Refresh();
                                dataGridView2.AutoResizeColumns();
                                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                                label5.Visible = true;
                                lblunmatch.Visible = true;
                                lblunmatch.Text = Convert.ToString((Convert.ToInt32(dataGridView2.Rows.Count.ToString()) - 1));
                                btnUnmatchMIS.Enabled = true;

                            }
                        }

                        MessageBox.Show("Match And UnMatch Case Record Display Is Both GridView");






                    }
                    else if (dialogResult == DialogResult.No)
                    {

                    }
                }
                else
                {
                    MessageBox.Show("No Record Found In Excel For Update And Show In GridView");
                }
            }
        }
        public void Upload_RTO()
        {
            if(txtPath.Text=="")
            {
                MessageBox.Show("Plaese Select File For Upload");
                return;
            }
            else
            {
                string ORGFNAME = concs.GetFileName(txtPath.Text);
                DataTable dtSucess = new DataTable("SucessData");
                DataTable dtGet = new DataTable("ExcelData");
                dtGet = concs.GetExcel(txtPath.Text);
                if (dtGet.Rows.Count > 0)
                {

                    int excelct = Convert.ToInt32(dtGet.Columns.Count);
                    string ExcelRecordCt = Convert.ToString(dtGet.Rows.Count);
                    if (excelct != 4)
                    {
                        MessageBox.Show("File Formate Not Correct ..");
                        return;
                    }
                    DialogResult dialogResult = MessageBox.Show(dtGet.Rows.Count + " -- Record To Upload Is this Correct? ", "Some Title", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        dtGet.Columns[0].ColumnName = "VU_Master_ID";
                        dtGet.Columns[1].ColumnName = "RTO_Reason";
                        dtGet.Columns[2].ColumnName = "Date";
                        dtGet.Columns[3].ColumnName = "Inward_No";
                        dtGet.Columns.Add("Status", typeof(string));
                        dtGet.Columns.Add("Reject_Reason", typeof(string));
                        dtGet.Columns.Add("Notice_Type", typeof(string));
                        dtGet.Columns.Add("Table_Name", typeof(string));
                        dtGet.Columns.Add("Registrion_No", typeof(string));


                        //Check for the mandatory values
                        DataRow[] rowsFiltered = dtGet.Select("[VU_Master_ID] is null Or [Date] is null Or [Inward_No] is Null Or [RTO_Reason] is Null");
                        if (rowsFiltered.Length > 0)
                        {
                            foreach (DataRow row in rowsFiltered)
                            {
                                row["Status"] = 'I';
                                row["Reject_Reason"] = "Mandatory Values Is Missing.";
                                dtGet.AcceptChanges();
                                row.SetModified();
                            }
                        }

                        //Get All Sucess Data
                        dtSucess = new DataTable("SucessData");
                        dtSucess = GetSucessData();


                        //Update Table Name And Notice Type
                        var query =
                                from tbl1 in dtGet.AsEnumerable()
                                join tbl2 in dtSucess.AsEnumerable() on tbl1["VU_Master_ID"] equals tbl2["VU_MasterID"]
                                select new { ID = tbl1["Date"], Field1 = tbl2["VU_TemplateName"], Field2 = tbl1["VU_Master_ID"] };
                        foreach (var row in query)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Field2 + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Notice_Type"] = row.Field1;
                                row1["Table_Name"] = "lpo_trnsuccess";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }

                        //Check Notice Type And Table Name Is Blank
                        DataRow[] rowsNotice = dtGet.Select("[Notice_Type] is null Or [Table_Name] is null ");
                        if (rowsNotice.Length > 0)
                        {
                            foreach (DataRow row in rowsNotice)
                            {
                                row["Status"] = 'I';
                                row["Reject_Reason"] = "Table Name And Notice Type Is Missing";
                                dtGet.AcceptChanges();
                                row.SetModified();
                            }
                        }


                        //Check RTO Range Exit Or Not 
                        OdbcDataAdapter daGetMaster = new OdbcDataAdapter("select * from lpo_templatemaster", con);
                        DataTable dtMaster = new DataTable();
                        daGetMaster.Fill(dtMaster);

                        var query1 =
                                from tbl1 in dtGet.AsEnumerable()
                                join tbl2 in dtMaster.AsEnumerable() on tbl1["Notice_Type"] equals tbl2["TemplateName"]
                                where tbl2.Field<string>("RTO_Start_No") == "" || tbl2.Field<string>("RTO_End_No") == ""
                                select new { ID = tbl1["Date"], Field1 = tbl2["RTO_Start_No"], Field2 = tbl2["RTO_End_No"], Master = tbl1["VU_Master_ID"] };

                        foreach (var row in query1)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Master + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {

                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "Range No not in Range Master.";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }


                        //Check Inward Is In Range Or Not
                        var query2 =
                               from tbl1 in dtGet.AsEnumerable()
                               join tbl2 in dtMaster.AsEnumerable() on tbl1["Notice_Type"] equals tbl2["TemplateName"]
                               where Convert.ToDouble(tbl1.Field<string>("Inward_No")) < Convert.ToDouble(tbl2.Field<string>("RTO_Start_No")) || Convert.ToDouble(tbl1.Field<string>("Inward_No")) > Convert.ToDouble(tbl2.Field<string>("RTO_End_No"))
                               select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master = tbl1["VU_Master_ID"] };

                        foreach (var row in query2)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Master + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "RTO Inward No not in Range.";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }


                        //Check Record Alredy Done POD Or Not
                        var query3 =
                             from tbl1 in dtGet.AsEnumerable()
                             join tbl2 in dtSucess.AsEnumerable() on tbl1["VU_Master_ID"] equals tbl2["VU_MasterID"]
                             where tbl2.Field<string>("VU_RTO_POD_FLG") == "POD"
                             select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master_1 = tbl1["VU_Master_ID"], Master_2 = tbl2["VU_MasterID"] };
                        foreach (var row in query3)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Master_1 + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "POD Alredy Done For Same Master_ID";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }

                        //Check Record Alredy Done RTO Or Not
                        var query4 =
                             from tbl1 in dtGet.AsEnumerable()
                             join tbl2 in dtSucess.AsEnumerable() on tbl1["VU_Master_ID"] equals tbl2["VU_MasterID"]
                             where tbl2.Field<string>("VU_RTO_POD_FLG") == "RTO"
                             select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master_1 = tbl1["VU_Master_ID"], Master_2 = tbl2["VU_MasterID"] };
                        foreach (var row in query4)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Master_1 + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "RTO Alredy Done For Same Master_ID";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }


                        //Check Inword Number Alredy Exit In Pod 
                        var query5 =
                             from tbl1 in dtGet.AsEnumerable()
                             join tbl2 in dtSucess.AsEnumerable() on tbl1["Inward_No"] equals tbl2["VU_RTO_POD_Inword_No"]
                             where tbl1.Field<string>("VU_Master_ID") != "" // tbl1.Field<string>("Inward_No") == tbl2.Field<string>("VU_RTO_RefNo") // || tbl1.Field<string>("Inward_No") == tbl2.Field<string>("VU_Delivery_ack_no")
                             select new { Field1 = tbl1["VU_Master_ID"] };
                        //select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master_1 = tbl1["VU_Master_ID"], Master_2 = tbl2["VU_MasterID"] };
                        foreach (var row in query5)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Field1 + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "Inword Number Alredy Use In POD";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }

                        //Comment By Avadhut - 17/03/2017
                        ////Check Inword Number Alredy Exit In RTO 
                        //var query6 =
                        //     from tbl1 in dtGet.AsEnumerable()
                        //     join tbl2 in dtSucess.AsEnumerable() on tbl1["Inward_No"] equals tbl2["VU_RTO_RefNo"]
                        //     where tbl1.Field<string>("VU_Master_ID") != "" // tbl1.Field<string>("Inward_No") == tbl2.Field<string>("VU_RTO_RefNo") // || tbl1.Field<string>("Inward_No") == tbl2.Field<string>("VU_Delivery_ack_no")
                        //     select new { Field1 = tbl1["VU_Master_ID"] };
                        ////select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master_1 = tbl1["VU_Master_ID"], Master_2 = tbl2["VU_MasterID"] };
                        //foreach (var row in query5)
                        //{
                        //    DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Field1 + "'");
                        //    foreach (DataRow row1 in rowsFiltered1)
                        //    {
                        //        row1["Status"] = 'I';
                        //        row1["Reject_Reason"] = "Inword Number Alredy Use In RTO";
                        //        dtGet.AcceptChanges();
                        //        row1.SetModified();
                        //    }
                        //}


                        DataRow[] rowsValid = dtGet.Select("[Status] is  Null ");
                        //IEnumerable<DataRow> rowsValid = dtGet.AsEnumerable().Where(r => r.IsNull("Status"));
                        //dataGridView1.DataSource = dtGet.Select("[Status] !=  null Or [Reject_Reason] != Not null ");
                         dt = new DataTable();
                        dt.Columns.Add("Master ID");
                        dt.Columns.Add("RTO Reason");
                        dt.Columns.Add("Date");
                        dt.Columns.Add("Inward No");
                        dt.Columns.Add("Status");
                        dt.Columns.Add("Reject Reason");
                        dt.Columns.Add("Notice Type");
                        dt.Columns.Add("Table Name");
                        dt.Columns.Add("Registrion No");

                        DataRow ro;
                        if (rowsValid.Length > 0)
                        {
                            foreach (DataRow row in rowsValid)
                            {
                                ro = dt.NewRow();
                                ro["Master ID"] = row[0];
                                ro["RTO Reason"] = row[1];
                                ro["Date"] = row[2];
                                ro["Inward No"] = row[3];
                                ro["Status"] = row[4];
                                ro["Reject Reason"] = row[5];
                                ro["Notice Type"] = row[6];
                                ro["Table Name"] = row[7];
                                ro["Registrion No"] = row[8];

                                dt.Rows.Add(ro);

                                dataGridView1.DataSource = dt;
                                dataGridView1.Refresh();
                                dataGridView1.AutoResizeColumns();
                                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                                lblrct.Visible = true;
                                lblct.Visible = true;
                                lblct.Text = Convert.ToString((Convert.ToInt32(dataGridView1.Rows.Count.ToString()) - 1));
                                btnMatchMIS.Enabled = true;

                            }
                        }


                        DataRow[] rowsValid1 = dtGet.Select("[Status] is Not  Null ");
                        //IEnumerable<DataRow> rowsValid = dtGet.AsEnumerable().Where(r => r.IsNull("Status"));
                        //dataGridView1.DataSource = dtGet.Select("[Status] !=  null Or [Reject_Reason] != Not null ");
                         dt1 = new DataTable();
                        dt1.Columns.Add("Master ID");
                        dt1.Columns.Add("RTO Reason");
                        dt1.Columns.Add("Date");
                        dt1.Columns.Add("Inward No");
                        dt1.Columns.Add("Status");
                        dt1.Columns.Add("Reject Reason");
                        dt1.Columns.Add("Notice Type");
                        dt1.Columns.Add("Table Name");
                        dt1.Columns.Add("Registrion No");

                        DataRow ro1;
                        if (rowsValid1.Length > 0)
                        {
                            foreach (DataRow row in rowsValid1)
                            {
                                ro1 = dt1.NewRow();
                                ro1["Master ID"] = row[0];
                                ro1["RTO Reason"] = row[1];
                                ro1["Date"] = row[2];
                                ro1["Inward No"] = row[3];
                                ro1["Status"] = row[4];
                                ro1["Reject Reason"] = row[5];
                                ro1["Notice Type"] = row[6];
                                ro1["Table Name"] = row[7];
                                ro1["Registrion No"] = row[8];

                                dt1.Rows.Add(ro1);

                                dataGridView2.DataSource = dt1;
                                dataGridView2.Refresh();
                                dataGridView2.AutoResizeColumns();
                                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                                label5.Visible = true;
                                lblunmatch.Visible = true;
                                lblunmatch.Text = Convert.ToString((Convert.ToInt32(dataGridView2.Rows.Count.ToString()) - 1));
                                btnUnmatchMIS.Enabled = true;

                            }
                        }

                        MessageBox.Show("Match And UnMatch Case Record Display Is Both GridView");



                    }
                    else if (dialogResult == DialogResult.No)
                    {

                    }
                }
                else
                {
                    MessageBox.Show("No Record Found In Excel For Update And Show In GridView");
                }
            }
            
        }

        public void Upload_Pod()
        {
            if(txtPath.Text=="")
            {
                MessageBox.Show("Plaese Select File For Upload");
                return;
            }
            else
            {

                string ORGFNAME = concs.GetFileName(txtPath.Text);
                DataTable dtSucess = new DataTable("SucessData");
                // OleDbConnection my_con = new OleDbConnection();
                DataTable dtGet = new DataTable("ExcelData");
                dtGet = concs.GetExcel(txtPath.Text);
                if (dtGet.Rows.Count > 0)
                {


                    int excelct = Convert.ToInt32(dtGet.Columns.Count);
                    string ExcelRecordCt = Convert.ToString(dtGet.Rows.Count);
                    if (excelct != 3)
                    {
                        MessageBox.Show("File Formate Not Correct ..");
                        return;
                    }
                    DialogResult dialogResult = MessageBox.Show(dtGet.Rows.Count + " -- Record To Upload Is this Correct? ", "Some Title", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {

                        dtGet.Columns[0].ColumnName = "VU_Master_ID";
                        //dtGet.Columns["VU_Master_ID"].DataType = typeof(string);
                        dtGet.Columns[1].ColumnName = "Date";
                        dtGet.Columns[2].ColumnName = "Inward_No";
                        dtGet.Columns.Add("Status", typeof(string));
                        dtGet.Columns.Add("Reject_Reason", typeof(string));
                        dtGet.Columns.Add("Notice_Type", typeof(string));
                        dtGet.Columns.Add("Table_Name", typeof(string));
                        dtGet.Columns.Add("Registrion_No", typeof(string));

                        //Check for the mandatory values
                        DataRow[] rowsFiltered = dtGet.Select("[VU_Master_ID] is null Or [Date] is null Or [Inward_No] is Null");
                        if (rowsFiltered.Length > 0)
                        {
                            foreach (DataRow row in rowsFiltered)
                            {
                                row["Status"] = 'I';
                                row["Reject_Reason"] = "Mandatory Values Is Missing.";
                                dtGet.AcceptChanges();
                                row.SetModified();
                            }
                        }

                        //Get All Sucess Data
                        dtSucess = new DataTable("SucessData");
                        dtSucess = GetSucessData();

                        //Update Table Name And Notice Type
                        var query =
                                from tbl1 in dtGet.AsEnumerable()
                                join tbl2 in dtSucess.AsEnumerable() on tbl1["VU_Master_ID"] equals tbl2["VU_MasterID"]
                                select new { ID = tbl1["Date"], Field1 = tbl2["VU_TemplateName"], Field2 = tbl1["VU_Master_ID"] };
                        foreach (var row in query)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Field2 + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Notice_Type"] = row.Field1;
                                row1["Table_Name"] = "lpo_trnsuccess";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }

                        //Check Notice Type And Table Name Is Blank
                        DataRow[] rowsNotice = dtGet.Select("[Notice_Type] is null Or [Table_Name] is null ");
                        if (rowsNotice.Length > 0)
                        {
                            foreach (DataRow row in rowsNotice)
                            {
                                row["Status"] = 'I';
                                row["Reject_Reason"] = "Table Name And Notice Type Is Missing";
                                dtGet.AcceptChanges();
                                row.SetModified();
                            }
                        }

                        //Check POD Range Exit Or Not 
                        OdbcDataAdapter daGetMaster = new OdbcDataAdapter("select * from lpo_templatemaster", con);
                        DataTable dtMaster = new DataTable();
                        daGetMaster.Fill(dtMaster);

                        var query1 =
                                from tbl1 in dtGet.AsEnumerable()
                                join tbl2 in dtMaster.AsEnumerable() on tbl1["Notice_Type"] equals tbl2["TemplateName"]
                                where tbl2.Field<string>("POD_Start_NO") == "" || tbl2.Field<string>("POD_End_NO") == ""
                                select new { ID = tbl1["Date"], Field1 = tbl2["POD_Start_NO"], Field2 = tbl2["POD_End_NO"], Master = tbl1["VU_Master_ID"] };

                        foreach (var row in query1)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Master + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {

                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "Range No not in Range Master.";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }

                        //Check Inward Is In Range Or Not
                        var query2 =
                               from tbl1 in dtGet.AsEnumerable()
                               join tbl2 in dtMaster.AsEnumerable() on tbl1["Notice_Type"] equals tbl2["TemplateName"]
                               where Convert.ToDouble(tbl1.Field<string>("Inward_No")) < Convert.ToDouble(tbl2.Field<string>("POD_Start_NO")) || Convert.ToDouble(tbl1.Field<string>("Inward_No")) > Convert.ToDouble(tbl2.Field<string>("POD_End_NO"))
                               select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master = tbl1["VU_Master_ID"] };

                        foreach (var row in query2)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Master + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "POD Inward No not in Range.";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }

                        //Check Record Alredy Done POD Or Not
                        var query3 =
                             from tbl1 in dtGet.AsEnumerable()
                             join tbl2 in dtSucess.AsEnumerable() on tbl1["VU_Master_ID"] equals tbl2["VU_MasterID"]
                             where tbl2.Field<string>("VU_RTO_POD_FLG") == "POD"
                             select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master_1 = tbl1["VU_Master_ID"], Master_2 = tbl2["VU_MasterID"] };
                        foreach (var row in query3)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Master_1 + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "POD Alredy Done For Same Master_ID";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }

                        //Check Record Alredy Done RTO Or Not
                        var query4 =
                             from tbl1 in dtGet.AsEnumerable()
                             join tbl2 in dtSucess.AsEnumerable() on tbl1["VU_Master_ID"] equals tbl2["VU_MasterID"]
                             where tbl2.Field<string>("VU_RTO_POD_FLG") == "RTO"
                             select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master_1 = tbl1["VU_Master_ID"], Master_2 = tbl2["VU_MasterID"] };
                        foreach (var row in query4)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Master_1 + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "RTO Alredy Done For Same Master_ID";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }

                        //Check Inword Number Alredy Exit In Pod 
                        var query5 =
                             from tbl1 in dtGet.AsEnumerable()
                             join tbl2 in dtSucess.AsEnumerable() on tbl1["Inward_No"] equals tbl2["VU_RTO_POD_Inword_No"]
                             where tbl1.Field<string>("VU_Master_ID") != "" // tbl1.Field<string>("Inward_No") == tbl2.Field<string>("VU_RTO_RefNo") // || tbl1.Field<string>("Inward_No") == tbl2.Field<string>("VU_Delivery_ack_no")
                         select new { Field1 = tbl1["VU_Master_ID"] };
                        //select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master_1 = tbl1["VU_Master_ID"], Master_2 = tbl2["VU_MasterID"] };
                        foreach (var row in query5)
                        {
                            DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Field1 + "'");
                            foreach (DataRow row1 in rowsFiltered1)
                            {
                                row1["Status"] = 'I';
                                row1["Reject_Reason"] = "Inword Number Alredy Use ";
                                dtGet.AcceptChanges();
                                row1.SetModified();
                            }
                        }
                        //Comment By Avadhut --17/03/2017
                        ////Check Inword Number Alredy Exit In RTO 
                        //var query6 =
                        //     from tbl1 in dtGet.AsEnumerable()
                        //     join tbl2 in dtSucess.AsEnumerable() on tbl1["Inward_No"] equals tbl2["VU_RTO_RefNo"]
                        //     where tbl1.Field<string>("VU_Master_ID") != "" // tbl1.Field<string>("Inward_No") == tbl2.Field<string>("VU_RTO_RefNo") // || tbl1.Field<string>("Inward_No") == tbl2.Field<string>("VU_Delivery_ack_no")
                        // select new { Field1 = tbl1["VU_Master_ID"] };
                        ////select new { ID = tbl1["Date"], Field1 = tbl1["Inward_No"], Master_1 = tbl1["VU_Master_ID"], Master_2 = tbl2["VU_MasterID"] };
                        //foreach (var row in query5)
                        //{
                        //    DataRow[] rowsFiltered1 = dtGet.Select("[VU_Master_ID] = '" + row.Field1 + "'");
                        //    foreach (DataRow row1 in rowsFiltered1)
                        //    {
                        //        row1["Status"] = 'I';
                        //        row1["Reject_Reason"] = "Inword Number Alredy Use In RTO";
                        //        dtGet.AcceptChanges();
                        //        row1.SetModified();
                        //    }
                        //}


                        DataRow[] rowsValid = dtGet.Select("[Status] is  Null ");
                        //IEnumerable<DataRow> rowsValid = dtGet.AsEnumerable().Where(r => r.IsNull("Status"));
                        //dataGridView1.DataSource = dtGet.Select("[Status] !=  null Or [Reject_Reason] != Not null ");
                         dt = new DataTable();
                        dt.Columns.Add("Master ID");
                        dt.Columns.Add("Date");
                        dt.Columns.Add("Inward No");
                        dt.Columns.Add("Status");
                        dt.Columns.Add("Reject Reason");
                        dt.Columns.Add("Notice Type");
                        dt.Columns.Add("Table Name");
                        dt.Columns.Add("Registrion No");

                        DataRow ro;
                        if (rowsValid.Length > 0)
                        {
                            foreach (DataRow row in rowsValid)
                            {
                                ro = dt.NewRow();
                                ro["Master ID"] = row[0];
                                ro["Date"] = row[1];
                                ro["Inward No"] = row[2];
                                ro["Status"] = row[3];
                                ro["Reject Reason"] = row[4];
                                ro["Notice Type"] = row[5];
                                ro["Table Name"] = row[6];
                                ro["Registrion No"] = row[7];

                                dt.Rows.Add(ro);

                                dataGridView1.DataSource = dt;
                                dataGridView1.Refresh();
                                dataGridView1.AutoResizeColumns();
                                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                                lblrct.Visible = true;
                                lblct.Visible = true;
                                lblct.Text = Convert.ToString((Convert.ToInt32(dataGridView1.Rows.Count.ToString()) - 1));
                                btnMatchMIS.Enabled = true;

                            }
                        }


                        DataRow[] rowsValid1 = dtGet.Select("[Status] is Not  Null ");
                        //IEnumerable<DataRow> rowsValid = dtGet.AsEnumerable().Where(r => r.IsNull("Status"));
                        //dataGridView1.DataSource = dtGet.Select("[Status] !=  null Or [Reject_Reason] != Not null ");
                         dt1 = new DataTable();
                        dt1.Columns.Add("Master ID");
                        dt1.Columns.Add("Date");
                        dt1.Columns.Add("Inward No");
                        dt1.Columns.Add("Status");
                        dt1.Columns.Add("Reject Reason");
                        dt1.Columns.Add("Notice Type");
                        dt1.Columns.Add("Table Name");
                        dt1.Columns.Add("Registrion No");

                        DataRow ro1;
                        if (rowsValid1.Length > 0)
                        {
                            foreach (DataRow row in rowsValid1)
                            {
                                ro1 = dt1.NewRow();
                                ro1["Master ID"] = row[0];
                                ro1["Date"] = row[1];
                                ro1["Inward No"] = row[2];
                                ro1["Status"] = row[3];
                                ro1["Reject Reason"] = row[4];
                                ro1["Notice Type"] = row[5];
                                ro1["Table Name"] = row[6];
                                ro1["Registrion No"] = row[7];

                                dt1.Rows.Add(ro1);

                                dataGridView2.DataSource = dt1;
                                dataGridView2.Refresh();
                                dataGridView2.AutoResizeColumns();
                                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                                dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                                label5.Visible = true;
                                lblunmatch.Visible = true;
                                lblunmatch.Text = Convert.ToString((Convert.ToInt32(dataGridView2.Rows.Count.ToString()) - 1));
                                btnUnmatchMIS.Enabled = true;

                            }
                        }


                        MessageBox.Show("Match And UnMatch Case Record Display Is Both GridView");


                    }
                    else if (dialogResult == DialogResult.No)
                    {

                    }
                }
                else
                {
                    MessageBox.Show("No Record Found In Excel For Update And Show In GridView");
                }

            }
            

        }
        public DataTable GetSucessData()
        {
            DataTable dtSuccess = new DataTable("SucessData");
            OdbcDataAdapter da = new OdbcDataAdapter("select * from lpo_trnsuccess", con);
            da.Fill(dtSuccess);
            return dtSuccess;
        }

        private void frmTest_Load(object sender, EventArgs e)
        {
            
            concs.connect();
            con = concs.con;
            lblrct.Visible = false;
            lblct.Visible = false;
            label5.Visible = false;
            lblunmatch.Visible = false;
            btnMatchMIS.Enabled = false;
            btnUnmatchMIS.Enabled = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            if (rtbADUpload.Checked == true)
            {
                UpdatePOD();
                btnSelect.Enabled = true;
            }
            else if (rtbrtoupload.Checked == true)
            {
                UpdateRTO();
                btnSelect.Enabled = true;
            }
            else if (rbtDispatch.Checked == true)
            {
                UpdateDispatch();
                btnSelect.Enabled = true;
            }
            else if(rbtRetrival.Checked==true)
            {
                UpdateRetrival();
                btnSelect.Enabled = true;
            }
            else
            {
                MessageBox.Show("PLEASE SELECT MODE ");
            }



        }
        public void UpdateRetrival()
        {
            if (dataGridView1.Rows.Count > 0)
            {
                for (int rows = 0; rows < dataGridView1.Rows.Count - 1; rows++)
                {
                    string Inword = "";
                    string Name = "";
                    string Date = "";
                    string Mode = "";
                    string sp_reg_no = "";
                    for (int col = 0; col < dataGridView1.Rows[rows].Cells.Count - 2; col++)
                    {
                        if (col == 0)
                        {
                            Inword = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 1)
                        {
                            Name = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 2)
                        {
                            Date = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if(col == 3)
                        {
                            Mode = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 4)
                        {
                            sp_reg_no = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }

                    }

                    string update = "update lpo_trnsuccess set VU_Retrival_Name='" + Name + "',VU_Retrival_Date='" + Date + "',VU_Retrival_Dispatch_Mode='"+ Mode + "',VU_Retrival_SP_REG_NO='"+ sp_reg_no + "' where VU_RTO_POD_Inword_No='" + Inword + "'";
                    OdbcCommand cmbupdate = new OdbcCommand(update, con);
                    cmbupdate.ExecuteNonQuery();
                }
            }
            else
            {
                MessageBox.Show("No Data Found For Update");
                return;
            }

            MessageBox.Show(" UPDATE SUCESSFULLY");
            dataGridView1.DataSource = null;
            dataGridView2.DataSource = null;
        }
        public void UpdateDispatch()
        {
            if (dataGridView1.Rows.Count > 0)
            {
                for (int rows = 0; rows < dataGridView1.Rows.Count - 1; rows++)
                {
                    string Master = "";
                    string SP = "";
                    string Date = "";
                    string mode = "";
                    string sub = "";
                    for (int col = 0; col < dataGridView1.Rows[rows].Cells.Count - 2; col++)
                    {
                        if (col == 0)
                        {
                            Master = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 1)
                        {
                            SP = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 2)
                        {
                            Date = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 3)
                        {
                            mode = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }

                    }

                    OdbcDataAdapter daRS = new OdbcDataAdapter("SELECT * from lpo_trnsuccess WHERE VU_MasterID='" + Master + "'", con);
                    DataSet ds = new DataSet();
                    daRS.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {

                        if (SP == "")
                        {
                            sub = "";
                        }
                        else
                        {
                            sub = SP.Substring(0, 1);
                        }
                        //length = Convert.ToInt32(Speed_Post_OR_Registration_No.Length.ToString());

                        if (sub == "R")
                        {
                            OdbcCommand cmbexcute = new OdbcCommand("update lpo_trnsuccess set VU_DispatchMode='Registered Post AD',VU_SPEED_POST_NO='" + SP + "',VU_Dispatch_Date='" + Date + "' where VU_MasterID='" + Master + "'", con);
                            cmbexcute.ExecuteNonQuery();
                        }
                        else if (sub == "E")
                        {
                            OdbcCommand cmbexcute = new OdbcCommand("update lpo_trnsuccess set VU_DispatchMode='Speed Post AD',VU_SPEED_POST_NO='" + SP + "',VU_Dispatch_Date='" + Date + "' where VU_MasterID='" + Master + "'", con);
                            cmbexcute.ExecuteNonQuery();
                        }
                        else if (sub == "")
                        {
                            OdbcCommand cmbexcute = new OdbcCommand("update lpo_trnsuccess set VU_DispatchMode='Ordinary',VU_SPEED_POST_NO='" + SP + "',VU_Dispatch_Date='" + Date + "' where VU_MasterID='" + Master + "'", con);
                            cmbexcute.ExecuteNonQuery();
                        }
                        else if (sub != "R" && sub != "E")
                        {
                            OdbcCommand cmbexcute = new OdbcCommand("update lpo_trnsuccess set VU_DispatchMode='Courier',VU_SPEED_POST_NO='" + SP + "',VU_Dispatch_Date='" + Date + "' where VU_MasterID='" + Master + "'", con);
                            cmbexcute.ExecuteNonQuery();
                        }
                    }






                    
                    //string update = "update lpo_trnsuccess_demo set VU_RTO_POD_Date='" + Date + "',VU_RTO_POD_Inword_No='" + Inword + "',VU_RTO_POD_FLG='POD' where VU_MasterID='" + Master + "'";
                    //OdbcCommand cmbupdate = new OdbcCommand(update, con);
                    //cmbupdate.ExecuteNonQuery();
                }

                MessageBox.Show("DISPATCH MODE UPDATE SUCCESSFULLY ");
                dataGridView1.DataSource = null;
                dataGridView2.DataSource = null;
            }
            else
            {
                MessageBox.Show("No Data Found For Update");
                return;
            }

           // MessageBox.Show("DISPATCH DATA UPDATE SUCESSFULLY");
        }
        public void UpdatePOD()
        {
            if (dataGridView1.Rows.Count > 0)
            {
                for (int rows = 0; rows < dataGridView1.Rows.Count-1; rows++)
                {
                    string Master = "";
                    string Inword = "";
                    string Date = "";
                    for (int col = 0; col < dataGridView1.Rows[rows].Cells.Count - 4; col++)
                    {
                        if (col == 0)
                        {
                            Master = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 1)
                        {
                            Date = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 2)
                        {
                            Inword = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }

                    }

                    string update = "update lpo_trnsuccess set VU_RTO_POD_Date='" + Date + "',VU_RTO_POD_Inword_No='" + Inword + "',VU_RTO_POD_FLG='POD' where VU_MasterID='" + Master + "'";
                    OdbcCommand cmbupdate = new OdbcCommand(update, con);
                    cmbupdate.ExecuteNonQuery();
                    
                }
            }
            else
            {
                MessageBox.Show("No Data Found For Update");
                return;
            }

            MessageBox.Show(" UPDATE SUCESSFULLY");
            dataGridView1.DataSource = null;
            dataGridView2.DataSource = null;
        }

        public void UpdateRTO()
        {
            if (dataGridView1.Rows.Count > 0)
            {
                for (int rows = 0; rows < dataGridView1.Rows.Count-1; rows++)
                {
                    string Master = "";
                    string Inword = "";
                    string Reason = "";
                    string Date = "";
                    for (int col = 0; col < dataGridView1.Rows[rows].Cells.Count - 4; col++)
                    {
                        if (col == 0)
                        {
                            Master = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 1)
                        {
                            Reason = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 2)
                        {
                            Date = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }
                        else if (col == 3)
                        {
                            Inword = dataGridView1.Rows[rows].Cells[col].Value.ToString();
                        }

                    }

                    string update = "update lpo_trnsuccess set VU_RTO_POD_Date='" + Date + "',VU_RTO_POD_Reason='" + Reason + "',VU_RTO_POD_Inword_No='" + Inword + "',VU_RTO_POD_FLG='RTO' where VU_MasterID='" + Master + "'";
                    OdbcCommand cmbupdate = new OdbcCommand(update, con);
                    cmbupdate.ExecuteNonQuery();
                }
            }
            else
            {
                MessageBox.Show("No Data Found For Update");
                return;
            }


            MessageBox.Show(" UPDATE SUCESSFULLY");
            dataGridView1.DataSource = null;
            dataGridView2.DataSource = null;
        }

        private void btnMatchMIS_Click(object sender, EventArgs e)
        {
            string str = "Match case";
            ExportToExcelBulk(dt, str);
        }

        public void ExportToExcelBulk(DataTable dt2,string display)
        {
            try
            {
                DataTable dtdisplay = new DataTable();
                dtdisplay = dt2;
                Microsoft.Office.Interop.Excel.Application xlApp;
                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "RECORD '"+ display + "' -- '"+ dtdisplay.Rows.Count +"'";
                //xlWorkSheet.Cells[2, 1] = "ICICI Bank - " + Notice + " Bulk Register for Dispatch Mode Regd Post AD";
                //xlWorkSheet.Cells[3, 1] = "Mode of Dispatch - REGISTERED POST";
                //xlWorkSheet.Cells[4, 1] = "Date - " + DateTime.Now.ToString("dd/MM/yyyy");
                xlWorkSheet.Range["A1:" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;

                for (var i = 0; i < dtdisplay.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dtdisplay.Columns[i].ColumnName;
                }
                xlWorkSheet.Range["A2:" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A2:" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Interior.Color = Color.Cyan;
                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {
                        xlWorkSheet.Cells[i + 3, j + 1] = dtdisplay.Rows[i][j];
                        xlWorkSheet.Cells.Columns.AutoFit();
                    }
                }

                //xlWorkSheet.Range["A1" + ":" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Borders.LineStyle = LineStyle.SingleLine;


                //string[] BulkPart = txtPath.Text.Split('\\');
                //int lenBulk = Convert.ToInt32(BulkPart.Length.ToString());
                //string FileNameBulk = BulkPart[lenBulk - 1].ToString().Split('.')[0];
                //string FileName = FileNameBulk + "_BulkRegister";

                string path = @"C:\Scan\RTO POD DISPATCH\" + string.Concat(DateTime.Now.Day, DateTime.Now.Month, DateTime.Now.Year, "\\");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                xlWorkBook.SaveAs(path + "'-"+ display + "'");
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show("Match case Data Exported Successfully ,file Path: " + (path));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private string GetExcelColumnName(int ColNo)
        {
            string columnName = string.Empty;
            int modulo;

            while (ColNo > 0)
            {
                modulo = (ColNo - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                ColNo = (int)((ColNo - modulo) / 26);
            }

            return columnName;
        }

        private void btnUnmatchMIS_Click(object sender, EventArgs e)
        {
            string str1 = "UnMatch case";
            ExportToExcelBulk(dt, str1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void rtbADUpload_CheckedChanged(object sender, EventArgs e)
        {
            btnSelect.Enabled = true;
        }

        private void rtbrtoupload_CheckedChanged(object sender, EventArgs e)
        {
            btnSelect.Enabled = true;
        }

        private void rbtDispatch_CheckedChanged(object sender, EventArgs e)
        {
            btnSelect.Enabled = true;
        }

        private void rbtRetrival_CheckedChanged(object sender, EventArgs e)
        {
            btnSelect.Enabled = true;
        }
    }
}
