﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;


namespace LPO_Dev
{
    public partial class UserRegistration : Form
    {
        public UserRegistration()
        {
            InitializeComponent();
        }


        public void BindOperator()
        {
            try
            {
                string StrSql = "select GroupId,Group_Name from VU_Admin_GroupMaster ";
                DataTable dt = clsMain.GetData(StrSql);
                clsMain.Bind_Combo(CmbUserRole, dt, "Group_Name", "GroupId");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void BindGV()
        {
            try
            {
                String StrData = "select a.USER_TypeID, b.Group_Name ,a.User_Name,a.EXPDT,a.CAP_CAP,a.CAP_QC,a.PASSWORD,a.BLOCK,a.ID"
                      + "  from vu_admin_userinfo  as a inner join vu_admin_groupmaster as b on a.USER_TypeID = b.GroupID  WHERE IfNULL(IDFLAG,'')!='Y'  AND IfNULL(BLOCK,'')!='Y'";
                DataTable Objdt = new DataTable();
                Objdt = clsMain.GetData(StrData);
                if (Objdt.Rows.Count > 0)
                {
                    dtGrdVw.AutoGenerateColumns = false;

                    dtGrdVw.Columns[1].Name = "USER_TypeID";
                    dtGrdVw.Columns[1].HeaderText = "User Type";
                    dtGrdVw.Columns[1].DataPropertyName = "USER_TypeID";
                    dtGrdVw.Columns[1].Width = 100;

                    dtGrdVw.Columns[2].Name = "Group_Name";
                    dtGrdVw.Columns[2].HeaderText = "User Role";
                    dtGrdVw.Columns[2].DataPropertyName = "Group_Name";
                    dtGrdVw.Columns[2].Width = 150;


                    dtGrdVw.Columns[3].Name = "User_Name";
                    dtGrdVw.Columns[3].HeaderText = "User Name";
                    dtGrdVw.Columns[3].DataPropertyName = "User_Name";
                    dtGrdVw.Columns[3].Width = 150;


                    dtGrdVw.Columns[4].Name = "CAP_CAP";
                    dtGrdVw.Columns[4].HeaderText = "Capture Capcity";
                    dtGrdVw.Columns[4].DataPropertyName = "CAP_CAP";
                    dtGrdVw.Columns[4].Width = 150;

                    dtGrdVw.Columns[5].Name = "CAP_QC";
                    dtGrdVw.Columns[5].HeaderText = "CAP QC";
                    dtGrdVw.Columns[5].DataPropertyName = "CAP_QC";
                    dtGrdVw.Columns[5].Width = 150;

                    dtGrdVw.Columns[6].Name = "EXPDT";
                    dtGrdVw.Columns[6].HeaderText = "Expiry Date";
                    dtGrdVw.Columns[6].DataPropertyName = "EXPDT";
                    dtGrdVw.Columns[6].Width = 150;

                    dtGrdVw.Columns[7].Name = "PASSWORD";
                    dtGrdVw.Columns[7].HeaderText = "PASSWORD ";
                    dtGrdVw.Columns[7].DataPropertyName = "PASSWORD";
                    dtGrdVw.Columns[7].Width = 150;


                    dtGrdVw.Columns[8].Name = "BLOCK";
                    dtGrdVw.Columns[8].HeaderText = "BLOCK ";
                    dtGrdVw.Columns[8].DataPropertyName = "BLOCK";
                    dtGrdVw.Columns[8].Width = 150;

                    dtGrdVw.Columns[9].Name = "ID";
                    dtGrdVw.Columns[9].HeaderText = "ID";
                    dtGrdVw.Columns[9].DataPropertyName = "ID";
                    dtGrdVw.Columns[9].Width = 100;
                    dtGrdVw.AllowUserToAddRows = false;

                    dtGrdVw.DataSource = Objdt;

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        private void Operator_Master_Load(object sender, EventArgs e)
        {
            this.Width = 800;
            this.Height = 600;


            BindOperator();
            BindGV();
            txtPwd.Text = "";
            txtPwd.PasswordChar = '*';
            txtPwd.MaxLength = 10;
            chkActive.Checked = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string EncryptPwd = string.Empty;
                string DecryptPwd = string.Empty;
                string ActiveFlag = string.Empty;
                string StrSqlInsert = string.Empty;
                string StrSqlUpdate = string.Empty;
                if (CmbUserRole.SelectedIndex == -1)
                {
                    MessageBox.Show("Please Choose User Role");
                    return;
                }
                if (txtUserName.Text == "")
                {
                    MessageBox.Show("Please Enter UserName !!");
                    return;
                }
                if (txtPwd.Text == "")
                {
                    MessageBox.Show("Please Enter Password !!");
                    return;
                }
                if (chkActive.Checked == true)
                {
                    ActiveFlag = "N";
                }
                else
                {
                    ActiveFlag = "Y";
                }

                DateTime ExpiryDate = DateTime.ParseExact(dateTimePicker1.Text, "dd-MM-yyyy", null);
                DateTime currentDate = DateTime.Now;


                EncryptPwd = clsMain.Encrypt(txtPwd.Text);
               
                if (btnSave.Text == "Update")
                {
                    StrSqlUpdate = "Update  VU_Admin_UserInfo set USER_NAME='" + txtUserName.Text + "',EXPDT='" + ExpiryDate.ToString("dd-MM-yyyy") + "',CAP_CAP='" + txtcapCap.Text + "',CAP_QC='" + txtQcCap.Text + "',PASSWORD='" + EncryptPwd + "',BLOCK='" + ActiveFlag + "' "
                        + "where ID='" + ClsProperty.UserID + "'";


                    bool Update = clsMain.ExcuteDML(StrSqlUpdate);
                    if (Update == true)
                    {
                        MessageBox.Show("Data Update Successfully..");
                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }
                }
                else
                {

                    StrSqlInsert = "Insert into VU_Admin_UserInfo(USER_TypeID,USER_NAME  ,PASSWORD  ,EXPDT,BLOCK,IDCDATE,CAP_CAP,CAP_QC)"
                                         + "values ('" + CmbUserRole.SelectedValue.ToString() + "','" + txtUserName.Text.Trim() + "','" + EncryptPwd + "',"
                                         + "'" + ExpiryDate.ToString("dd-MM-yyyy") + "','" + ActiveFlag + "','" + currentDate.ToString("dd-MM-yyyy") + "','" + txtcapCap.Text + "','" + txtQcCap.Text + "')";

                    bool Insert = clsMain.ExcuteDML(StrSqlInsert);
                    if (Insert == true)
                    {
                        MessageBox.Show("Data Save Successfully..");
                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }
                }
                BindGV();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtcapCap_KeyPress(object sender, KeyPressEventArgs e)
        {
            const char Delete = (char)8;
            e.Handled = !Char.IsDigit(e.KeyChar) && e.KeyChar != Delete;
        }

        private void txtQcCap_KeyPress(object sender, KeyPressEventArgs e)
        {
            const char Delete = (char)8;
            e.Handled = !Char.IsDigit(e.KeyChar) && e.KeyChar != Delete;
        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtUserName.Text = "";
            txtPwd.Text = "";
            txtQcCap.Text = "";
            txtcapCap.Text = "";
            btnSave.Text = "Save";
        }

        private void dtGrdVw_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dtGrdVw_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int row;
               
                row = e.RowIndex;

                
                string UserTypeID = dtGrdVw.Rows[row].Cells["USER_TypeID"].Value.ToString();
                CmbUserRole.SelectedItem = UserTypeID;
                string User_Name = dtGrdVw.Rows[row].Cells["User_Name"].Value.ToString();
                txtUserName.Text = User_Name;
                string CAP_CAP = dtGrdVw.Rows[row].Cells["CAP_CAP"].Value.ToString();
                txtcapCap.Text = CAP_CAP;
                string CAP_QC = dtGrdVw.Rows[row].Cells["CAP_QC"].Value.ToString();
                txtQcCap.Text = CAP_QC;
                string PASSWORD = dtGrdVw.Rows[row].Cells["PASSWORD"].Value.ToString();
                txtPwd.Text = clsMain.Decrypt(PASSWORD);
                string EXPDT = dtGrdVw.Rows[row].Cells["EXPDT"].Value.ToString();
                dateTimePicker1.Text = EXPDT;
                string IDFLAG = dtGrdVw.Rows[row].Cells["BLOCK"].Value.ToString();
                string UserID = dtGrdVw.Rows[row].Cells["ID"].Value.ToString();
                ClsProperty.UserID = UserID;
                if (IDFLAG == "Y")
                {
                    chkActive.Checked = false;
                }
                else
                {
                    chkActive.Checked = true;
                }
                btnSave.Text = "Update";
            
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void dtGrdVw_UserDeletedRow(object sender, DataGridViewRowEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string StrDelete = string.Empty;
            try
            {
                List<DataGridViewRow> selectedRows = (from row in dtGrdVw.Rows.Cast<DataGridViewRow>()
                                                      where Convert.ToBoolean(row.Cells["ChkBoxColumn"].Value) == true
                                                      select row).ToList();
                if (MessageBox.Show(string.Format("Do you want to delete {0} rows?", selectedRows.Count), "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    foreach (DataGridViewRow row in selectedRows)
                    {
                        StrDelete = "Update VU_Admin_UserInfo  set IDFLAG='Y',BLOCK='Y'  WHERE ID='" + row.Cells["ID"].Value + "'";
                        bool Delete = clsMain.ExcuteDML(StrDelete);
                        if (Delete == true)
                        {
                            MessageBox.Show("Data Delete Successfully..");
                        }
                        else
                        {
                            MessageBox.Show("Please try again..");
                        }                        
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            this.BindGV();
        }
    }
}