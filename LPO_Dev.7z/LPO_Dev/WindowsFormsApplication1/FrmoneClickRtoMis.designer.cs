﻿namespace LPO_Dev
{
    partial class FrmoneClickRtoMis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbnoticeprocess = new System.Windows.Forms.RadioButton();
            this.rbrtopoddate = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rbselectedfield = new System.Windows.Forms.RadioButton();
            this.rballfield = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Todatetimepicker = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.frmdatetimepicker = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.btngenrate = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbnoticeprocess);
            this.groupBox1.Controls.Add(this.rbrtopoddate);
            this.groupBox1.Location = new System.Drawing.Point(3, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(312, 65);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Report Type";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // rbnoticeprocess
            // 
            this.rbnoticeprocess.AutoSize = true;
            this.rbnoticeprocess.Location = new System.Drawing.Point(157, 19);
            this.rbnoticeprocess.Name = "rbnoticeprocess";
            this.rbnoticeprocess.Size = new System.Drawing.Size(154, 17);
            this.rbnoticeprocess.TabIndex = 1;
            this.rbnoticeprocess.TabStop = true;
            this.rbnoticeprocess.Text = "NOTICE PROCESS DATE ";
            this.rbnoticeprocess.UseVisualStyleBackColor = true;
            // 
            // rbrtopoddate
            // 
            this.rbrtopoddate.AutoSize = true;
            this.rbrtopoddate.Location = new System.Drawing.Point(7, 20);
            this.rbrtopoddate.Name = "rbrtopoddate";
            this.rbrtopoddate.Size = new System.Drawing.Size(144, 17);
            this.rbrtopoddate.TabIndex = 0;
            this.rbrtopoddate.TabStop = true;
            this.rbrtopoddate.Text = "RTO /POD RECD DATE";
            this.rbrtopoddate.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rbselectedfield);
            this.groupBox2.Controls.Add(this.rballfield);
            this.groupBox2.Location = new System.Drawing.Point(12, 85);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(198, 66);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Field Type";
            // 
            // rbselectedfield
            // 
            this.rbselectedfield.AutoSize = true;
            this.rbselectedfield.Location = new System.Drawing.Point(99, 19);
            this.rbselectedfield.Name = "rbselectedfield";
            this.rbselectedfield.Size = new System.Drawing.Size(97, 17);
            this.rbselectedfield.TabIndex = 1;
            this.rbselectedfield.TabStop = true;
            this.rbselectedfield.Text = "Selected Fields";
            this.rbselectedfield.UseVisualStyleBackColor = true;
            // 
            // rballfield
            // 
            this.rballfield.AutoSize = true;
            this.rballfield.Location = new System.Drawing.Point(7, 20);
            this.rballfield.Name = "rballfield";
            this.rballfield.Size = new System.Drawing.Size(66, 17);
            this.rballfield.TabIndex = 0;
            this.rballfield.TabStop = true;
            this.rballfield.Text = "All Fields";
            this.rballfield.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Todatetimepicker);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.frmdatetimepicker);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(321, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(386, 65);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Date Range";
            // 
            // Todatetimepicker
            // 
            this.Todatetimepicker.Location = new System.Drawing.Point(233, 30);
            this.Todatetimepicker.Name = "Todatetimepicker";
            this.Todatetimepicker.Size = new System.Drawing.Size(142, 20);
            this.Todatetimepicker.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(184, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "ToDate";
            // 
            // frmdatetimepicker
            // 
            this.frmdatetimepicker.Location = new System.Drawing.Point(57, 30);
            this.frmdatetimepicker.Name = "frmdatetimepicker";
            this.frmdatetimepicker.Size = new System.Drawing.Size(121, 20);
            this.frmdatetimepicker.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "FromDate ";
            // 
            // btngenrate
            // 
            this.btngenrate.Location = new System.Drawing.Point(249, 104);
            this.btngenrate.Name = "btngenrate";
            this.btngenrate.Size = new System.Drawing.Size(176, 34);
            this.btngenrate.TabIndex = 3;
            this.btngenrate.Text = "Genrate MIS";
            this.btngenrate.UseVisualStyleBackColor = true;
            this.btngenrate.Click += new System.EventHandler(this.btngenrate_Click);
            // 
            // btnexit
            // 
            this.btnexit.Location = new System.Drawing.Point(495, 104);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(123, 34);
            this.btnexit.TabIndex = 4;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // FrmoneClickRtoMis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 156);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btngenrate);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FrmoneClickRtoMis";
            this.Text = "FrmoneClickRtoMis";
            this.Load += new System.EventHandler(this.FrmoneClickRtoMis_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rbnoticeprocess;
        private System.Windows.Forms.RadioButton rbrtopoddate;
        private System.Windows.Forms.RadioButton rbselectedfield;
        private System.Windows.Forms.RadioButton rballfield;
        private System.Windows.Forms.DateTimePicker Todatetimepicker;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker frmdatetimepicker;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btngenrate;
        private System.Windows.Forms.Button btnexit;
    }
}