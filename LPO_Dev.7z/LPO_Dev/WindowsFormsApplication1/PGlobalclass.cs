﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Odbc;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Text.RegularExpressions;

namespace LPO_Dev
{
    static class PGlobalclass
    {
        public static string pServer;
        public static string pDataBase;
        public static string pUid;
        public static string pPwd;
        public static string max_connetion;
        public static OdbcConnection con;
        public static string ConnStr;
        public static OleDbConnection conExcel = new OleDbConnection();
        public static DataTable dtCmb = new DataTable();

       

        public static string strGlbFileName = string.Empty;
        public static string strGlbBatchID = string.Empty;
        public static DataGridView GridCntrl;
        public static string strGlbPath = @"C:\MIS";
        public const string const_strReportTable = "LPO_trnReportTbl";


        public static string strGlbUploadTbl = string.Empty;
        public static string strGlbUploadSuccess = string.Empty;
        public static string strGlbUploadFailed = string.Empty;
        public static string strGlbCol = string.Empty;
        public static string strGlbTemplateName = string.Empty;
        public static ArrayList alSpList = new ArrayList();
        public static string strRTOPath = string.Empty;
        public static string strPODPath = string.Empty;
        public static string strDownloadPath = string.Empty;

        public static Hashtable htGlbColTyp;
        public static int iGlbRegNo = 0;


        public static string strGlbAppstartID = string.Empty;
        /// <summary>
        /// Connects to MySQL server
        /// </summary>
        /// <returns></returns>
        public static bool Connect()
        {
            bool OpenCon = false;
            try
            {
                pServer = ConfigurationManager.AppSettings["Server"].ToString();
                pDataBase = ConfigurationManager.AppSettings["DataBase"].ToString();
                pUid = ConfigurationManager.AppSettings["Uid"].ToString();
                pPwd = ConfigurationManager.AppSettings["Pwd"].ToString();
                max_connetion = ConfigurationManager.AppSettings["max_connection"].ToString();
                strRTOPath = ConfigurationManager.AppSettings["RTOLivePath"].ToString();
                strPODPath = ConfigurationManager.AppSettings["PODLivePath"].ToString();
                strDownloadPath = ConfigurationManager.AppSettings["DownloadPath"].ToString();

                ConnStr = "DRIVER={MySQL ODBC 3.51 Driver}; SERVER=" + pServer + "; DATABASE=" + pDataBase + "; UID=" + pUid + "; PWD=" + pPwd + ";max_connections = " + max_connetion + ";";

                con = new OdbcConnection();

                if (con.State.ToString() == "Closed")
                {
                    con.ConnectionString = ConnStr;
                    con.ConnectionTimeout = 60000;
                    con.Open();
                    OpenCon = true;
                }
            }
            catch (Exception Ex)
            {
                OpenCon = false;
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
            return OpenCon;
        }
        internal static void Showdata(frmQuickSearch frmQuickSearch, string strloanno, string strappno, string strBrowse)
        {
            //ShowdataOldSearch

            DBHelper objdbhelper = new DBHelper();
            GridCntrl = (DataGridView)frmQuickSearch.Controls.Find("dataGridView1", true).FirstOrDefault();
            try
            {
                string StrSqlInsert = string.Empty;             
                
                if (strappno == "")
                {          
                    string strCmbQry = "select VU_NoticeDate,VU_ApplicantName,VU_AppAdd1,VU_AppAdd2,VU_AppAdd3,VU_AppAdd4,VU_AppCity,VU_AppPincode,VU_Product,VU_LANNo,VU_Filename, VU_MasterID, VU_REGNO, VU_UploadDate, VU_Dispatch_Date,CASE VU_DispatchMode WHEN 'SP' THEN ''WHEN 'REG' THEN '' ELSE VU_DispatchMode END as DispatchMode , VU_SPEED_POST_NO,VU_RTO_POD_FLG as Status,VU_RTO_POD_Inword_No, VU_RTO_POD_Date, VU_RTO_POD_Reason, VU_Retrival_Name, VU_Retrival_Date, VU_Retrival_Dispatch_Mode,VU_Retrival_SP_REG_NO from lpo_trnsuccess where VU_LanNo like '" + strloanno + "' group by VU_MasterID ";
                    dtCmb = GetData(strCmbQry);
                    GridCntrl.DataSource = dtCmb;
                }

                else if (strloanno == "")
                {
                    string strCmbQry = "select VU_NoticeDate,VU_ApplicantName,VU_AppAdd1,VU_AppAdd2,VU_AppAdd3,VU_AppAdd4,VU_AppCity,VU_AppPincode,VU_Product,VU_LANNo,VU_Filename, VU_MasterID, VU_REGNO, VU_UploadDate, VU_Dispatch_Date,CASE VU_DispatchMode WHEN 'SP' THEN ''WHEN 'REG' THEN '' ELSE VU_DispatchMode END as DispatchMode , VU_SPEED_POST_NO,VU_RTO_POD_FLG as Status,VU_RTO_POD_Inword_No, VU_RTO_POD_Date, VU_RTO_POD_Reason, VU_Retrival_Name, VU_Retrival_Date, VU_Retrival_Dispatch_Mode,VU_Retrival_SP_REG_NO from lpo_trnsuccess where VU_masterID ='" + strappno + "' group by VU_MasterID  ";
                    dtCmb = GetData(strCmbQry);
                    GridCntrl.DataSource = dtCmb;
                }
                else
                {
                    string strCmbQry = "select VU_NoticeDate,VU_ApplicantName,VU_AppAdd1,VU_AppAdd2,VU_AppAdd3,VU_AppAdd4,VU_AppCity,VU_AppPincode,VU_Product,VU_LANNo,VU_Filename, VU_MasterID, VU_REGNO, VU_UploadDate, VU_Dispatch_Date,CASE VU_DispatchMode WHEN 'SP' THEN ''WHEN 'REG' THEN '' ELSE VU_DispatchMode END as DispatchMode , VU_SPEED_POST_NO,VU_RTO_POD_FLG as Status,VU_RTO_POD_Inword_No, VU_RTO_POD_Date, VU_RTO_POD_Reason, VU_Retrival_Name, VU_Retrival_Date, VU_Retrival_Dispatch_Mode,VU_Retrival_SP_REG_NO from lpo_trnsuccess where VU_masterID ='" + strappno + "' and VU_LanNo like '" + strloanno + "' group by VU_MasterID  ";
                    dtCmb = GetData(strCmbQry);
                    GridCntrl.DataSource = dtCmb;
                }
            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void ShowdataOldSearch(frmQuickSearch frmQuickSearch, string strloanno, string strappno, string strBrowse)
        {
            //

            DBHelper objdbhelper = new DBHelper();
            GridCntrl = (DataGridView)frmQuickSearch.Controls.Find("dataGridView2", true).FirstOrDefault();
            try
            {
                string StrSqlInsert = string.Empty;

                if (strappno == "")
                {
                    string strCmbQry = "Select Appno,Notice_Type,Loan_card_no,TableName,REGISTRATION_NO from llap.Upload_Details where Loan_Card_No like '" + strloanno + "' ";
                    dtCmb = GetData(strCmbQry);
                    GridCntrl.DataSource = dtCmb;
                }

                else if (strloanno == "")
                {
                    string strCmbQry = "Select Appno,Loan_card_no,Notice_Type,TableName,REGISTRATION_NO from llap.Upload_Details where AppNo ='" + strappno + "'";
                    dtCmb = GetData(strCmbQry);
                    GridCntrl.DataSource = dtCmb;
                }
                else
                {
                    string strCmbQry = "Select Appno,Notice_Type,Loan_card_no,TableName,REGISTRATION_NO from llap.Upload_Details where AppNo ='" + strappno + "' and Loan_Card_No like '" + strloanno + "' ";
                    dtCmb = GetData(strCmbQry);
                    GridCntrl.DataSource = dtCmb;
                }
                
            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void ShowInwardbulkAppno(FrmInwardMIS FrmInwardMIS, string strBrowse)
        {

            DataTable dtCmb = new DataTable();
            DBHelper objdbhelper = new DBHelper();
            GridCntrl = (DataGridView)FrmInwardMIS.Controls.Find("dgvStatus", true).FirstOrDefault();
            try
            {
                OleDbConnection my_con = new OleDbConnection();

                if (Path.GetExtension(strBrowse) == ".xls")
                    my_con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strBrowse + ";Extended Properties=Excel 8.0;Persist Security Info=False";
                else if (Path.GetExtension(strBrowse) == ".xlsx")
                    my_con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strBrowse + ";Extended Properties=Excel 8.0;Persist Security Info=False";


                OleDbCommand o_cmd = new OleDbCommand("select * from [Sheet1$]", my_con);
                OleDbDataAdapter da = new OleDbDataAdapter();

                da.SelectCommand = o_cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);

                DataTable dt1 = new DataTable();
                string query = "";
                string appnostrt = null;

                for (int i = 0; i < ds.Tables[0].Rows.Count - 1; i++)
                {
                    appnostrt += "'" + ds.Tables[0].Rows[i][0].ToString() + "'" + ",";
                }
                string str1 = appnostrt.TrimEnd(',');
                Console.WriteLine(appnostrt);
                string str2 = str1.Remove(str1.Length - 1);

                string strCmbQry = "select vu_Regno,vu_MasterID,VU_inward_IS_POD_RTO,vu_templateName from lpo_trnsuccess  where vu_MasterID in (" + str1 + ") and VU_inward_IS_POD_RTO <> ''";
                dtCmb = GetData(strCmbQry);
                DataTable Objdt = dtCmb;
                if (Objdt.Rows.Count > 0)
                {
                    GridCntrl.AutoGenerateColumns = false;

                    GridCntrl.Columns[1].Name = "vu_Regno";
                    GridCntrl.Columns[1].HeaderText = "Inward No.";
                    GridCntrl.Columns[1].DataPropertyName = "vu_Regno";

                    GridCntrl.Columns[2].Name = "VU_MasterID";
                    GridCntrl.Columns[2].HeaderText = "Master ID";
                    GridCntrl.Columns[2].DataPropertyName = "VU_MasterID";

                    GridCntrl.Columns[3].Name = "VU_inward_IS_POD_RTO";
                    GridCntrl.Columns[3].HeaderText = "Status";
                    GridCntrl.Columns[3].DataPropertyName = "VU_inward_IS_POD_RTO";

                    GridCntrl.Columns[4].Name = "VU_TemplateName";
                    GridCntrl.Columns[4].HeaderText = "Template Name";
                    GridCntrl.Columns[4].DataPropertyName = "VU_TemplateName";

                    GridCntrl.AllowUserToAddRows = false;

                    GridCntrl.DataSource = Objdt;

                }
            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void ShowInwardbulkLanno(FrmInwardMIS FrmInwardMIS, string strBrowse)
        {

            DataTable dtCmb = new DataTable();
            DBHelper objdbhelper = new DBHelper();
            GridCntrl = (DataGridView)FrmInwardMIS.Controls.Find("dgvStatus", true).FirstOrDefault();
            try
            {
                OleDbConnection my_con = new OleDbConnection();

                if (Path.GetExtension(strBrowse) == ".xls")
                    my_con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strBrowse + ";Extended Properties=Excel 8.0;Persist Security Info=False";
                else if (Path.GetExtension(strBrowse) == ".xlsx")
                    my_con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strBrowse + ";Extended Properties=Excel 8.0;Persist Security Info=False";


                OleDbCommand o_cmd = new OleDbCommand("select * from [Sheet1$]", my_con);
                OleDbDataAdapter da = new OleDbDataAdapter();

                da.SelectCommand = o_cmd;
                DataSet ds = new DataSet();
                da.Fill(ds);

                DataTable dt1 = new DataTable();
                string query = "";
                string appnostrt = null;

                for (int i = 0; i < ds.Tables[0].Rows.Count - 1; i++)
                {
                    appnostrt += "'" + ds.Tables[0].Rows[i][0].ToString() + "'" + ",";
                }
                string str1 = appnostrt.TrimEnd(',');
                Console.WriteLine(appnostrt);
                string str2 = str1.Remove(str1.Length - 1);

                string strCmbQry = "select vu_Regno,vu_MasterID,VU_inward_IS_POD_RTO,vu_templateName from lpo_trnsuccess  where vu_Lanno in (" + str1 + ") and VU_inward_IS_POD_RTO <> '' ";
                dtCmb = GetData(strCmbQry);
                DataTable Objdt = dtCmb;
                if (Objdt.Rows.Count > 0)
                {
                    GridCntrl.AutoGenerateColumns = false;

                    GridCntrl.Columns[1].Name = "vu_Regno";
                    GridCntrl.Columns[1].HeaderText = "Inward No.";
                    GridCntrl.Columns[1].DataPropertyName = "vu_Regno";

                    GridCntrl.Columns[2].Name = "VU_MasterID";
                    GridCntrl.Columns[2].HeaderText = "Master ID";
                    GridCntrl.Columns[2].DataPropertyName = "VU_MasterID";

                    GridCntrl.Columns[3].Name = "VU_inward_IS_POD_RTO";
                    GridCntrl.Columns[3].HeaderText = "Status";
                    GridCntrl.Columns[3].DataPropertyName = "VU_inward_IS_POD_RTO";

                    GridCntrl.Columns[4].Name = "VU_TemplateName";
                    GridCntrl.Columns[4].HeaderText = "Template Name";
                    GridCntrl.Columns[4].DataPropertyName = "VU_TemplateName";

                    GridCntrl.AllowUserToAddRows = false;

                    GridCntrl.DataSource = Objdt;

                }
            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }


        internal static void ShowInward(FrmInwardMIS FrmInwardMIS, string startDate, string enddate, string strBrowse)
        {
            DataTable dtCmb = new DataTable();
            DBHelper objdbhelper = new DBHelper();
            GridCntrl = (DataGridView)FrmInwardMIS.Controls.Find("dgvStatus", true).FirstOrDefault();
            try
            {

                dtCmb = objdbhelper.Select("call sp_Inward ('','" + startDate + "','" + enddate + "')", CommandType.StoredProcedure);

                DataTable Objdt = dtCmb;
                if (Objdt.Rows.Count > 0)
                {
                    GridCntrl.AutoGenerateColumns = false;
                                        
                    GridCntrl.Columns[1].Name = "vu_Regno";
                    GridCntrl.Columns[1].HeaderText = "Inward No.";
                    GridCntrl.Columns[1].DataPropertyName = "vu_Regno";
                 
                    GridCntrl.Columns[2].Name = "VU_MasterID";
                    GridCntrl.Columns[2].HeaderText = "Master ID";
                    GridCntrl.Columns[2].DataPropertyName = "VU_MasterID";

                    GridCntrl.Columns[3].Name = "VU_inward_IS_POD_RTO";
                    GridCntrl.Columns[3].HeaderText = "Status";
                    GridCntrl.Columns[3].DataPropertyName = "VU_inward_IS_POD_RTO";

                    GridCntrl.Columns[4].Name = "VU_TemplateName";
                    GridCntrl.Columns[4].HeaderText = "Template Name";
                    GridCntrl.Columns[4].DataPropertyName = "VU_TemplateName";
                                      
                    GridCntrl.AllowUserToAddRows = false;

                    GridCntrl.DataSource = Objdt;

                }
            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void ShowInwardsingle(FrmInwardMIS FrmInwardMIS, string strloanno, string strappno)
        {

            DBHelper objdbhelper = new DBHelper();
            GridCntrl = (DataGridView)FrmInwardMIS.Controls.Find("dgvStatus", true).FirstOrDefault();
            try
            {
               
                if (strappno == "")
                {                   
                    string strCmbQry = "select vu_Regno,vu_MasterID,VU_inward_IS_POD_RTO,vu_templateName from lpo_trnsuccess where VU_LanNo like '" + strloanno + "'  ";
                    dtCmb = GetData(strCmbQry);              
           
                        DataTable Objdt = dtCmb;
                        if (Objdt.Rows.Count > 0)
                        {
                            GridCntrl.AutoGenerateColumns = false;

                            GridCntrl.Columns[1].Name = "vu_Regno";
                            GridCntrl.Columns[1].HeaderText = "Inward No.";
                            GridCntrl.Columns[1].DataPropertyName = "vu_Regno";

                            GridCntrl.Columns[2].Name = "VU_MasterID";
                            GridCntrl.Columns[2].HeaderText = "Master ID";
                            GridCntrl.Columns[2].DataPropertyName = "VU_MasterID";

                            GridCntrl.Columns[3].Name = "VU_inward_IS_POD_RTO";
                            GridCntrl.Columns[3].HeaderText = "Status";
                            GridCntrl.Columns[3].DataPropertyName = "VU_inward_IS_POD_RTO";

                            GridCntrl.Columns[4].Name = "VU_TemplateName";
                            GridCntrl.Columns[4].HeaderText = "Template Name";
                            GridCntrl.Columns[4].DataPropertyName = "VU_TemplateName";

                            GridCntrl.AllowUserToAddRows = false;

                            GridCntrl.DataSource = Objdt;

                        }                
              
              }

                else if (strloanno == "")
                {                    
                    string strCmbQry = "select vu_Regno,vu_MasterID,VU_inward_IS_POD_RTO,vu_templateName from lpo_trnsuccess where VU_masterID ='" + strappno + "' ";
                    dtCmb = GetData(strCmbQry);
          
                    DataTable Objdt = dtCmb;
                    if (Objdt.Rows.Count > 0)
                    {
                        GridCntrl.AutoGenerateColumns = false;

                        GridCntrl.Columns[1].Name = "vu_Regno";
                        GridCntrl.Columns[1].HeaderText = "Inward No.";
                        GridCntrl.Columns[1].DataPropertyName = "vu_Regno";

                        GridCntrl.Columns[2].Name = "VU_MasterID";
                        GridCntrl.Columns[2].HeaderText = "Master ID";
                        GridCntrl.Columns[2].DataPropertyName = "VU_MasterID";

                        GridCntrl.Columns[3].Name = "VU_inward_IS_POD_RTO";
                        GridCntrl.Columns[3].HeaderText = "Status";
                        GridCntrl.Columns[3].DataPropertyName = "VU_inward_IS_POD_RTO";

                        GridCntrl.Columns[4].Name = "VU_TemplateName";
                        GridCntrl.Columns[4].HeaderText = "Template Name";
                        GridCntrl.Columns[4].DataPropertyName = "VU_TemplateName";

                        GridCntrl.AllowUserToAddRows = false;

                        GridCntrl.DataSource = Objdt;

                    }
                }
                else
                {
                    string strCmbQry = "select vu_Regno,vu_MasterID,VU_inward_IS_POD_RTO,vu_templateName from lpo_trnsuccess where VU_masterID ='" + strappno + "' and VU_LanNo like '" + strloanno + "' and VU_inward_IS_POD_RTO<>'' ";
                    dtCmb = GetData(strCmbQry);

                    DataTable Objdt = dtCmb;
                    if (Objdt.Rows.Count > 0)
                    {
                        GridCntrl.AutoGenerateColumns = false;

                        GridCntrl.Columns[1].Name = "vu_Regno";
                        GridCntrl.Columns[1].HeaderText = "Inward No.";
                        GridCntrl.Columns[1].DataPropertyName = "vu_Regno";

                        GridCntrl.Columns[2].Name = "VU_MasterID";
                        GridCntrl.Columns[2].HeaderText = "Master ID";
                        GridCntrl.Columns[2].DataPropertyName = "VU_MasterID";

                        GridCntrl.Columns[3].Name = "VU_inward_IS_POD_RTO";
                        GridCntrl.Columns[3].HeaderText = "Status";
                        GridCntrl.Columns[3].DataPropertyName = "VU_inward_IS_POD_RTO";

                        GridCntrl.Columns[4].Name = "VU_TemplateName";
                        GridCntrl.Columns[4].HeaderText = "Template Name";
                        GridCntrl.Columns[4].DataPropertyName = "VU_TemplateName";

                        GridCntrl.AllowUserToAddRows = false;

                        GridCntrl.DataSource = Objdt;

                    }
                }
            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        internal static void GenerateExcl(frmQuickSearch frmQuickSearch, string strloanno, string strappno)
        {

            DBHelper objdbhelper = new DBHelper();
            try
            {
                DataTable dt = dtCmb;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Cells[1, 1] = "Quick Search Report for " + strloanno + " or " + strappno;
       
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;

                for (var i = 0; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dt.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {

                        string str = "'" + dt.Rows[i][j].ToString();
                 
                        xlWorkSheet.Cells[i + 3, j + 1] = str;

                        xlWorkSheet.Cells.Columns.AutoFit();

                    }
                }
                CultureInfo ci = new CultureInfo("en-US");
                var month = DateTime.Now.ToString("MMMM", ci);
                            
                string path = @"C:\MIS\QuickSearchReport\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string path1 = "Single_QuickSearch" ;
                xlWorkBook.SaveAs(path + path1);
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show(" MIS Exported Successfully ");

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void GenerateExclbulk(frmQuickSearch frmQuickSearch, string strBrowse)
        {
            OleDbConnection my_con = new OleDbConnection();

            if (Path.GetExtension(strBrowse) == ".xls")
                my_con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strBrowse + ";Extended Properties=Excel 8.0;Persist Security Info=False";
            else if (Path.GetExtension(strBrowse) == ".xlsx")
                my_con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strBrowse + ";Extended Properties=Excel 8.0;Persist Security Info=False";


            OleDbCommand o_cmd = new OleDbCommand("select * from [Sheet1$]", my_con);
            OleDbDataAdapter da = new OleDbDataAdapter();

            da.SelectCommand = o_cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);

            DataTable dt1 = new DataTable();
            string query = "";
            string appnostrt = null;

            for (int i = 0; i < ds.Tables[0].Rows.Count ; i++)
            {
                appnostrt += "'" + ds.Tables[0].Rows[i][0].ToString() + "' or Vu_lanno like ";
            }
            string str1 = appnostrt.TrimEnd(',');
            Console.WriteLine(appnostrt);
            string str2 = str1.Remove(str1.Length - 17);

            string strCmbQry = "select VU_NoticeDate,VU_ApplicantName,VU_AppAdd1,VU_AppAdd2,VU_AppAdd3,VU_AppAdd4,VU_AppCity,VU_AppPincode,VU_Product,VU_LANNo,VU_Filename, VU_MasterID, VU_REGNO, VU_UploadDate, VU_Dispatch_Date,CASE VU_DispatchMode WHEN 'SP' THEN ''WHEN 'REG' THEN '' ELSE VU_DispatchMode END as DispatchMode , VU_SPEED_POST_NO,VU_RTO_POD_FLG as Status,VU_RTO_POD_Inword_No, VU_RTO_POD_Date, VU_RTO_POD_Reason, VU_Retrival_Name, VU_Retrival_Date, VU_Retrival_Dispatch_Mode,VU_Retrival_SP_REG_NO from lpo_trnsuccess where VU_LanNo like " + str2 + "  group by VU_MasterID  ";
            dtCmb = GetData(strCmbQry);

            DBHelper objdbhelper = new DBHelper();
            try
            {
                DataTable dt = dtCmb;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Cells[1, 1] = " Bulk Quick Search Report ";
            
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;
                
                for (var i = 0; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dt.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {

                        string str = "'" + dt.Rows[i][j].ToString();
                        //  string str =  dt.Rows[i][j].ToString();

                        xlWorkSheet.Cells[i + 3, j + 1] = str;

                        xlWorkSheet.Cells.Columns.AutoFit();

                    }
                }

                CultureInfo ci = new CultureInfo("en-US");
                var month = DateTime.Now.ToString("MMMM", ci);               
                string path = @"C:\MIS\QuickSearchReport\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string path1 = "QuickSearch_Bulk_LanNo";
                xlWorkBook.SaveAs(path + path1);
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show(" MIS Exported Successfully ");

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void GenerateExclbulkbyapp(frmQuickSearch frmQuickSearch, string strBrowse)
        {
            OleDbConnection my_con = new OleDbConnection();

            if (Path.GetExtension(strBrowse) == ".xls")
                my_con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strBrowse + ";Extended Properties=Excel 8.0;Persist Security Info=False";
            else if (Path.GetExtension(strBrowse) == ".xlsx")
                my_con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strBrowse + ";Extended Properties=Excel 8.0;Persist Security Info=False";


            OleDbCommand o_cmd = new OleDbCommand("select * from [Sheet1$]", my_con);
            OleDbDataAdapter da = new OleDbDataAdapter();

            da.SelectCommand = o_cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);

            DataTable dt1 = new DataTable();
            string query = "";
            string appnostrt = null;

            for (int i = 0; i < ds.Tables[0].Rows.Count ; i++)
            {
                appnostrt += "'" + ds.Tables[0].Rows[i][0].ToString() + "' or vu_MasterID = ";
            }
            string str1 = appnostrt.TrimEnd(',');
            Console.WriteLine(appnostrt);
            string str2 = str1.Remove(str1.Length - 17);

            string strCmbQry = "select VU_NoticeDate,VU_ApplicantName,VU_AppAdd1,VU_AppAdd2,VU_AppAdd3,VU_AppAdd4,VU_AppCity,VU_AppPincode,VU_Product,VU_LANNo,VU_Filename, VU_MasterID, VU_REGNO,VU_UploadDate, VU_Dispatch_Date,CASE VU_DispatchMode WHEN 'SP' THEN ''WHEN 'REG' THEN '' ELSE VU_DispatchMode END as DispatchMode , VU_SPEED_POST_NO,VU_RTO_POD_FLG as Status,VU_RTO_POD_Inword_No, VU_RTO_POD_Date, VU_RTO_POD_Reason, VU_Retrival_Name, VU_Retrival_Date, VU_Retrival_Dispatch_Mode,VU_Retrival_SP_REG_NO from lpo_trnsuccess where vu_MasterID = " + str2 + " group by VU_MasterID  ";
            dtCmb = GetData(strCmbQry);

            DBHelper objdbhelper = new DBHelper();
            try
            {
                DataTable dt = dtCmb;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Cells[1, 1] = " Bulk Quick Search Report ";
             
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;
                for (var i = 0; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dt.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {
                        string str = "'" + dt.Rows[i][j].ToString();                   

                        xlWorkSheet.Cells[i + 3, j + 1] = str;

                        xlWorkSheet.Cells.Columns.AutoFit();
                    }
                }

                CultureInfo ci = new CultureInfo("en-US");
                var month = DateTime.Now.ToString("MMMM", ci);
              
                string path = @"C:\MIS\QuickSearchReport\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string path1 = "QuickSearch_Bulk_AppNo";
                xlWorkBook.SaveAs(path + path1);
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show(" MIS Exported Successfully ");
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        internal static void cmbFillRTO(frmQuickSearch frmQuickSearch)
        {
            ComboBox cmbCntrl;
            DataTable dtCmb = new DataTable();
            try
            {
                int iCnt = 1;
                string strCmbQry = "select distinct TemplateName, TemplateID  from lpo_templatemaster order by TemplateID;";
                cmbCntrl = (ComboBox)frmQuickSearch.Controls.Find("cmbTemplate", true).FirstOrDefault();
                dtCmb = GetData(strCmbQry);
                cmbCntrl.Items.Insert(0, "-SELECT TEMPLATE-");
                foreach (DataRow row in dtCmb.Rows)
                {
                    cmbCntrl.Items.Insert(Convert.ToInt32(row["TemplateID"]), row["TemplateName"].ToString());
                    iCnt++;
                }
                cmbCntrl.SelectedIndex = 0;


                int iCnt1 = 1;
                string strCmbQry1 = "select distinct VU_DispatchMode from lpo_trnsuccess;";
                cmbCntrl = (ComboBox)frmQuickSearch.Controls.Find("cmbDispatchmode", true).FirstOrDefault();
                dtCmb = GetData(strCmbQry1);
                cmbCntrl.Items.Insert(0, "-SELECT Dispatch Mode-");
                foreach (DataRow row in dtCmb.Rows)
                {
                    cmbCntrl.Items.Insert(0, row["VU_DispatchMode"].ToString());
                    iCnt1++;
                }
                cmbCntrl.SelectedIndex = 0;


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void cmbFillReject(RejectionData RejectionData)
        {
            ComboBox cmbCntrl;
            DataTable dtCmb = new DataTable();
            try
            {               
                int iCnt = 1;
                string strCmbQry = "select distinct TemplateName, TemplateID  from lpo_templatemaster order by TemplateID;";
                cmbCntrl = (ComboBox)RejectionData.Controls.Find("cmbTemplate", true).FirstOrDefault();
                dtCmb = GetData(strCmbQry);
                cmbCntrl.Items.Insert(0, "-SELECT TEMPLATE-");
                cmbCntrl.Items.Insert(1, "SELECT ALL TEMPLATE");
                foreach (DataRow row in dtCmb.Rows)
                {
                    cmbCntrl.Items.Insert(Convert.ToInt32(row["TemplateID"]), row["TemplateName"].ToString());
                    iCnt++;
                }

                cmbCntrl.SelectedIndex = 0;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void cmbFillInward(frmInward frmInward)
        {
            ComboBox cmbCntrl;
            DataTable dtCmb = new DataTable();
            try
            {             
                int iCnt = 1;
                string strCmbQry = "select distinct (TemplateName)  from lpo_templatemaster;";
                cmbCntrl = (ComboBox)frmInward.Controls.Find("cmbTemplate", true).FirstOrDefault();
                dtCmb = GetData(strCmbQry);
                cmbCntrl.Items.Insert(0, "-SELECT TEMPLATE-");      
                foreach (DataRow row in dtCmb.Rows)
                {
                    cmbCntrl.Items.Insert(1, row["TemplateName"].ToString());
                    iCnt++;
                }

                cmbCntrl.SelectedIndex = 0;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void cmbFillFileName(RejectionData RejectionData, string strTempname, string strdate)
        {
            ComboBox cmbCntrl;
            DataTable dtCmb = new DataTable();
            try
            {
                int iCnt = 1;
                string strCmbQry = "select distinct VU_Filename from lpo_trnfailed where vu_templateName='" + strTempname + "' and vu_UploadDate='" + strdate + "' ";
                cmbCntrl = (ComboBox)RejectionData.Controls.Find("cmbFile_Name", true).FirstOrDefault();
                dtCmb = GetData(strCmbQry);
                cmbCntrl.Items.Insert(0, "-SELECT File Name-");

                foreach (DataRow row in dtCmb.Rows)
                {
                    cmbCntrl.Items.Insert(0, row["VU_Filename"].ToString());
                    iCnt++;
                }

              
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        internal static void GenerateExcloneclick(frmoneClickRtoDispatchMis frmRtoPodMis, string strdate, string enddate)
        {
          
            DataTable dtCmb = new DataTable();
            DBHelper objdbhelper = new DBHelper();
            try
            {
                dtCmb = objdbhelper.Select("call sp_Rtopodmis ('RTO','','" + strdate + "','" + enddate + "','' )", CommandType.StoredProcedure);
                DataTable dt = dtCmb;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Cells[1, 1] = "RTO POD Report " + strdate + "to" + enddate;
             
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;




                for (var i = 0; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dt.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {

                        string str = "'" + dt.Rows[i][j].ToString();
                 
                        xlWorkSheet.Cells[i + 3, j + 1] = str;

                        xlWorkSheet.Cells.Columns.AutoFit();

                    }
                }
                CultureInfo ci = new CultureInfo("en-US");
                var month = DateTime.Now.ToString("MMMM", ci);

                string path = @"C:\MIS\OneClick_RtoPodMIS\" + string.Concat(DateTime.Now.Day, " ", month, "", DateTime.Now.Year, "\\");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

              
                string path1 = "OneClick_RtoPodMis";
                xlWorkBook.SaveAs(path + path1);
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show(" MIS Exported Successfully ");

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void Inward(frmInward frmInward, string ImagePath, string Exelpath,Image  Pic)
        {
            ArrayList alImg = new ArrayList();
            ArrayList alExcel = new ArrayList();

            int i = 0;
            using (var fs = File.OpenRead(Exelpath))
            using (var reader = new StreamReader(fs))
            {

                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    string[] values = line.Split(';');
                    int CountLeng = line.Length;

                    alExcel.Add(values[0]);    
                    i++;
                }
            }

            DirectoryInfo d = new DirectoryInfo(ImagePath);
            FileInfo[] Files = d.GetFiles("*.TIF");
            int fileCount = Directory.GetFiles(ImagePath, "*.TIF").Length;
            i = 0;
            foreach (FileInfo file1 in Files)
            {
                string folderImageName = string.Empty;
                folderImageName = Convert.ToString(file1).Trim();
      
                alImg.Add(file1.Name);              
                  i++;
            }

            Hashtable htMap = new Hashtable();
            int iCnt = 0;
            foreach (string str in alImg)
            {
               
                if (!htMap.Contains(str))
                {
                    htMap.Add(str, alExcel[iCnt].ToString());

                    string OldFileName1 = ("@C:\\17022017HA08q" + "\\" + alExcel[iCnt].ToString()+ ".tif");
                    string newFileName2 = ("@C:\\30032017_114529" + "\\" + alImg[iCnt].ToString ());

           
                    Pic.Save(OldFileName1);
                    Pic.Save("@C:\\30032017_114529" + "\\" + alExcel[iCnt].ToString() + "tif");
            
                    string newFileName = Regex.Replace(alExcel[iCnt].ToString(), @"^(\d)+\-(\d)+", alImg[iCnt].ToString());


                }
                iCnt++;
            }          
         

            string str1 = "053505004684.TIF";
            if(htMap.Contains(str1))
            {
                string strRep = htMap[str1].ToString();
            }               


        }



        internal static void GenerateExclUpload(frmoneClickRtoDispatchMis frmRtoPodMis, string strdate, string enddate)
        {
            
            DataTable dtCmb = new DataTable();
            DBHelper objdbhelper = new DBHelper();
            try
            {
                dtCmb = objdbhelper.Select("call sp_Rtopodmis ('Dispatch','','" + strdate + "','" + enddate + "','' )", CommandType.StoredProcedure);
                DataTable dt = dtCmb;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Cells[1, 1] = "Dispatch MIS " + strdate + "to" + enddate;
        
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;

                for (var i = 0; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dt.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {

                        string str = "'" + dt.Rows[i][j].ToString();

                        xlWorkSheet.Cells[i + 3, j + 1] = str;

                        xlWorkSheet.Cells.Columns.AutoFit();

                    }
                }
                CultureInfo ci = new CultureInfo("en-US");
                var month = DateTime.Now.ToString("MMMM", ci);

                string path = @"C:\MIS\DispatchMis\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
         
                string path1 = "DispatchMis";
                xlWorkBook.SaveAs(path + path1);
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }


        public static string ExcelColName(int ColumeNo)
        {
            string colName = string.Empty;
            int mod;

            while (ColumeNo > 0)
            {
                mod = (ColumeNo - 1) % 26;
                colName = Convert.ToChar(65 + mod).ToString() + colName;
                ColumeNo = (int)((ColumeNo - mod) / 26);
            }

            return colName;
        }

        internal static void GenerateExcl(RejectionData RejectionData, string strTempname, string strdate, string strFileName)
        {
            ComboBox cmbCntrl;
            DataTable dtCmb = new DataTable();
            DBHelper objdbhelper = new DBHelper();
            try
            {             

                dtCmb = objdbhelper.Select("call sp_Rtopodmis ('Reject','" + strTempname + "','" + strdate + "','','" + strFileName + "' )", CommandType.StoredProcedure);

                DataTable dt = dtCmb;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "Rejcetion Data Of " + strTempname;
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;
                        
             
                for (var i = 0; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dt.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {

                        string str = "'" + dt.Rows[i][j].ToString();
                    
                        xlWorkSheet.Cells[i + 3, j + 1] = str;
                      
                        xlWorkSheet.Cells.Columns.AutoFit();
                    
                    }
                }

                CultureInfo ci = new CultureInfo("en-US");
                var month = DateTime.Now.ToString("MMMM", ci);

               
                string path = @"C:\MIS\RejectionData\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");
               
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string path1 = "Reject" + "_" + strFileName;
                xlWorkBook.SaveAs(path + path1);
                               
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void GenerateInwardPOD(frmInward frmInward, string strTempname)
        {
            ComboBox cmbCntrl;
            DataTable dtCmb = new DataTable();
            DBHelper objdbhelper = new DBHelper();
            try
            {             

                string strCmbQry = "select VU_Inwardno,VU_Inward_ApplicantName,VU_Inward_LANNo,VU_Inward_MasterID,VU_inward_OldImagename1,VU_inward_OldImagename2,VU_inward_NewImageName,VU_inward_image_serverPath,VU_inward_image_Date,VU_inward_image_Excelpath,VU_inward_TemplateName from lpo_image_inward order by VU_Inwardno";
                dtCmb = GetData(strCmbQry);

                DataTable dt = dtCmb;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "Inward Data POD Of " + strTempname;
               
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;




                for (var i = 0; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dt.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {

                        string str = "'" + dt.Rows[i][j].ToString();

                        xlWorkSheet.Cells[i + 3, j + 1] = str;

                        xlWorkSheet.Cells.Columns.AutoFit();

                    }
                }

                CultureInfo ci = new CultureInfo("en-US");
                var month = DateTime.Now.ToString("MMMM", ci);
              
                string path = @"C:\MIS\Inward\POD\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");
              
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string path1 = "Inward_POD";
                xlWorkBook.SaveAs(path + path1);                
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show(" MIS Exported Successfully ");
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        internal static void GenerateInwardRTO(frmInward frmInward, string strTempname)
        {
            ComboBox cmbCntrl;
            DataTable dtCmb = new DataTable();
            DBHelper objdbhelper = new DBHelper();
            try
            {

                string strCmbQry = "select VU_Inwardno,VU_Inward_ApplicantName,VU_Inward_LANNo,VU_Inward_MasterID,VU_inward_OldImagename1,VU_inward_OldImagename2,VU_inward_NewImageName,VU_inward_image_serverPath,VU_inward_image_Date,VU_inward_image_Excelpath,VU_inward_TemplateName from lpo_image_inward order by VU_Inwardno";
                dtCmb = GetData(strCmbQry);

                DataTable dt = dtCmb;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "Inward Data RTO Of " + strTempname;
          
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + ExcelColName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;
                

                for (var i = 0; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dt.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {

                        string str = "'" + dt.Rows[i][j].ToString();

                        xlWorkSheet.Cells[i + 3, j + 1] = str;

                        xlWorkSheet.Cells.Columns.AutoFit();

                    }
                }
                
                CultureInfo ci = new CultureInfo("en-US");
                var month = DateTime.Now.ToString("MMMM", ci);
                              
                string path = @"C:\MIS\Inward\RTO\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");
              
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string path1 = "Inward_RTO";
                xlWorkBook.SaveAs(path + path1);

                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }


        public static DataTable GetData(string strQry)
        {
            DataTable dtGetData = new DataTable();
            try
            {
              
                OdbcCommand Com;
                Com = new OdbcCommand(strQry, con);
                dtGetData.Load(Com.ExecuteReader());
                return dtGetData;
                //}

            }
            catch (Exception Ex)
            {
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return null;
           
            }
            return dtGetData;
        }
        public static bool SetData(string str)
        {
            try
            {
                if (Connect() == true)
                {
                    OdbcCommand Com;
                    Com = new OdbcCommand(str, con);
                    Com.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception Ex)
            {
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return false;
            }
            con.Close();
        }


    }
}
