﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    static class ClsMailMergeUpload
    {
        public static int iGlbRegNo = 0;
        private static string strGlbColumns;
        private static string strGlbUploadTbl;
        private static string strGlbUploadSuccess;
        private static string strGlbUploadFailed;
        private static string strGlbValidation;
        private static string strGlbFileName;

        private static string strGlbTemplates;

        private static string strGlbOutputPathBulk;
        private static string strGlbOutputPathSticker;
        public static string strGlbPath = @"C:\Output";

        internal static void ProcessMailMerge(int iTempIndex, string strFileName)
        {
            DataTable dtExcelData = new DataTable();
            try
            {

                int iExcelColCount = ClsGlobal.getExcelColcnt(iTempIndex);
                dtExcelData = ClsGlobal.getExcelData();
                int idtExcelCnt = dtExcelData.Columns.Count;


                strGlbFileName = Path.GetFileNameWithoutExtension(strFileName);


                if (iExcelColCount != idtExcelCnt)
                {
                    MessageBox.Show("File format not correct");
                    ClsGlobal.conExcel.Close();
                    return;
                }

                SetGlobalVars(iTempIndex);

                if (dtExcelData.Rows.Count > 0)
                {
                    UploadToDBMailMerge(iTempIndex, dtExcelData);
                    ClsGlobal.conExcel.Close();

                }


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void UploadToDBMailMerge(int iTempIndex, DataTable dtExcelData)
        {
            try
            {
                ArrayList alTemplates = new ArrayList();

                UploadToTempMailMerge(dtExcelData);

                RejectDuplicateUniqueID();

                UploadToSuccessMailMerge(iTempIndex);
                UploadToFailedMailMerge();


                CreateFolderStructureMailMerge(strGlbPath);

                alTemplates = getTemplatesInMailMerge();

                if (alTemplates.Count > 0)
                {
                    BulkRegisterMailMerge(alTemplates);
                }



                MessageBox.Show("Mailmerge Complete");

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void RejectDuplicateUniqueID()
        {
            try
            {
                string strDupQry = "insert into lpo_trnfailed("+strGlbColumns+")  " +
                    "(SELECT up.VU_Sno,up.VU_NoticeDate,up.VU_MasterID,up.VU_TemplateName,up.VU_LANNo,up.VU_ApplicantName, " +
                    "up.VU_AppAdd1,up.VU_AppAdd2,up.VU_AppAdd3,up.VU_AppAdd4,up.VU_AppCity,up.VU_AppPincode,up.VU_EMIOutstandingAmount, " +
                    "up.VU_OutstandingDate,up.VU_Product,up.VU_ManagerName,up.VU_ManagerMb,up.VU_RefNo,up.VU_MailMergeFilename,up.VU_REGNO, " +
                    "up.VU_BatchNO,up.VU_UploadDate,up.VU_IsPrinted,up.VU_UploadType,up.VU_FileName " +
                    "FROM lpo_trnupload up  " +
                    "Inner JOIN lpo_trnsuccess ON lpo_trnsuccess.VU_MasterID = up.VU_MasterID group by up.id); ";
                ClsGlobal.ExcuteDML(strDupQry);

                strDupQry = "DELETE  FROM lpo_trnupload WHERE EXISTS (SELECT * FROM lpo_trnfailed WHERE "+
                            "lpo_trnfailed.VU_MasterID = lpo_trnupload.VU_MasterID);";
                ClsGlobal.ExcuteDML(strDupQry);
            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static ArrayList getTemplatesInMailMerge()
        {
            try
            {
                ArrayList alTemplates = new ArrayList();
                DataTable dtTemplates = new DataTable();
                string strTmplates = "select distinct VU_TemplateName from lpo_trnSuccess where VU_FileName = '" + strGlbFileName + "'" +
                    "and VU_UploadDate= '" + DateTime.Now.ToShortDateString() + "' and VU_IsPrinted = 'N' " +
                    "and VU_UploadType = 'MailMerge'";

                dtTemplates = ClsGlobal.GetData(strTmplates);
                if (dtTemplates.Rows.Count > 0)
                {
                    foreach (DataRow dRow in dtTemplates.Rows)
                    {
                        alTemplates.Add(dRow["VU_TemplateName"].ToString());
                    }
                }
                dtTemplates.Clear();
                return alTemplates;


            }
            catch (Exception Ex)
            {

                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return null;
            }
        }

        internal static string GetMaxUniqueID()
        {
            string strUniqueId = string.Empty;
            DataTable dtUnique = new DataTable();
            try
            {
                string strIdQry = "select Max(VU_MasterId) as MaxUnique from lpo_trnSuccess " +
                                  "where VU_UploadType = 'MailMerge'";
                dtUnique = ClsGlobal.GetData(strIdQry);
                if (dtUnique.Rows.Count > 0)
                {
                    foreach (DataRow row in dtUnique.Rows)
                    {
                        strUniqueId = row["MaxUnique"].ToString();
                    }

                }

                return strUniqueId;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return null;
            }
        }

        private static void GenerateReportMailMerge(string strReportcond, string strRepoPath, string strserverRptPath)
        {
            try
            {
                string strQry = "truncate table " + ClsGlobal.const_strReportTable;
                ClsGlobal.ExcuteDML(strQry);

                string strInsertRpt = "Insert into " + ClsGlobal.const_strReportTable + "( " + strGlbColumns + ")" + "(select " + strGlbColumns +
                    " from " + strGlbUploadSuccess + strReportcond + " )";

                ClsGlobal.ExcuteDML(strInsertRpt);


                ReportDocument cryRpt = new ReportDocument();
                //cryRpt.Refresh();
                cryRpt.Load(strserverRptPath);

                cryRpt.Refresh();
                ExportOptions CrExportOptions;
                DiskFileDestinationOptions CrDiskFileDestinationOptions = new DiskFileDestinationOptions();
                PdfRtfWordFormatOptions CrFormatTypeOptions = new PdfRtfWordFormatOptions();
                CrDiskFileDestinationOptions.DiskFileName = strRepoPath;
                CrExportOptions = cryRpt.ExportOptions;
                {
                    CrExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
                    CrExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
                    CrExportOptions.DestinationOptions = CrDiskFileDestinationOptions;
                    CrExportOptions.FormatOptions = CrFormatTypeOptions;
                }

                cryRpt.Export();
                MessageBox.Show("Sticker Generated SuccessFully");
                cryRpt.Refresh();

                cryRpt.Close();
            }
            catch (Exception Ex)
            {

                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);

            }
        }

        private static void BulkRegisterMailMerge(ArrayList alTemplates)
        {
            string strCondition = string.Empty;
            string serverStickerPath = ClsGlobal.strGlbTemplateLocation + "CrystalReport3.rpt";
            try
            {
                foreach (string strTemplate in alTemplates)
                {
                    strGlbTemplates = strTemplate;
                    DataTable dtBulkReg = new DataTable();

                    string strBulkQry = "select IFNULL(concat(VU_TemplateName,'/', SUBSTRING(VU_NoticeDate, -4), '/', VU_REGNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                        "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                        "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                        "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnsuccess " +
                                        "where VU_FileName = '" + strGlbFileName + "'" +
                                        "and VU_UploadDate= '" + DateTime.Now.ToShortDateString() + "' and VU_IsPrinted = 'N' " +
                                        "and VU_UploadType = 'MailMerge' and VU_TemplateName = '" + strTemplate + "' Group By VU_MasterID";

                    //string strBulkQry = "select " + strGlbColumns + " from lpo_trnSuccess "+
                    //                    "where VU_FileName = '" + strGlbFileName + "'" +
                    //                    "and VU_UploadDate= '" + DateTime.Now.ToShortDateString() + "' and VU_IsPrinted = 'N' " +
                    //                    "and VU_UploadType = 'MailMerge' and VU_TemplateName = '"+ strTemplate +"'";


                    strCondition = " where VU_FileName = '" + strGlbFileName + "'" +
                                   "and VU_UploadDate= '" + DateTime.Now.ToShortDateString() + "' and VU_IsPrinted = 'N' " +
                                   "and VU_UploadType = 'MailMerge' and VU_TemplateName = '" + strTemplate + "'";

                    dtBulkReg = ClsGlobal.GetData(strBulkQry);
                    if (dtBulkReg.Rows.Count > 0)
                    {
                        GenerateBulkExcelMailMerge(strGlbOutputPathBulk + "\\" + strGlbFileName + "_" + strTemplate + "_BulkRegister", dtBulkReg, "Registered Post");
                        dtBulkReg.Clear();
                        GenerateReportMailMerge(strCondition,
                            strGlbOutputPathSticker + "\\" + strGlbFileName + "_" + strTemplate + "_Sticker.pdf", serverStickerPath);


                        string strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strCondition;
                        ClsGlobal.ExcuteDML(strSetPrintFlag);
                    }

                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void GenerateBulkExcelMailMerge(string strGlbOutputPathBulk, DataTable dtBulkReg, string strDispMode)
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application xlApp;
                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "IN CHARGE MBC, CHAKALA, MIDC POST OFFICE MUMBAI 400091";
                xlWorkSheet.Cells[2, 1] = "ICICI Bank - " + strGlbTemplates + " Bulk Register";
                xlWorkSheet.Cells[3, 1] = "Mode of Dispatch - " + strDispMode;
                xlWorkSheet.Cells[4, 1] = "Date - " + DateTime.Now.ToShortDateString();

                for (var i = 0; i < dtBulkReg.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[5, i + 1] = dtBulkReg.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dtBulkReg.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dtBulkReg.Columns.Count - 1; j++)
                    {

                        string str = "'" + dtBulkReg.Rows[i][j].ToString();
                        //if (j != 5)
                        //{
                        xlWorkSheet.Cells[i + 6, j + 1] = str;
                        //}
                        //else
                        //{
                        //    xlWorkSheet.Cells[i + 6, j + 1] = dtBulk.Rows[i][j];

                        //}
                        xlWorkSheet.Cells.Columns.AutoFit();
                    }
                }

                //xlWorkSheet.Range["A1" + ":" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Borders.LineStyle = LineStyle.SingleLine;
                xlWorkBook.SaveAs(strGlbOutputPathBulk);
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show("Data Exported Successfully ,file Path: " + (strGlbOutputPathBulk));
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void CreateFolderStructureMailMerge(string strGlbPath)
        {
            try
            {

                string strDt = DateTime.Now.ToString("dd MMM yyyy");
                string strOutputPath = strGlbPath + "\\MailMerge" + "\\" + strDt + "\\" + strGlbFileName;
                string strInputFile = strOutputPath + "\\" + "Input";

                strGlbOutputPathBulk = strOutputPath + "\\" + "BulkRegister";
                //strGlbOutputPathReport = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Report";
                strGlbOutputPathSticker = strOutputPath + "\\" + "Sticker";


                if (!Directory.Exists(strInputFile))
                {
                    Directory.CreateDirectory(strInputFile);

                }
                File.Copy(ClsGlobal.strGlbInputFilePath, strInputFile + "\\" + strGlbFileName + ".xls", true);
                if (!Directory.Exists(strOutputPath))
                {
                    Directory.CreateDirectory(strOutputPath);
                }
                if (!Directory.Exists(strGlbOutputPathBulk))
                {
                    Directory.CreateDirectory(strGlbOutputPathBulk);
                }

                if (!Directory.Exists(strGlbOutputPathSticker))
                {
                    Directory.CreateDirectory(strGlbOutputPathSticker);
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }


        private static void UploadToSuccessMailMerge(int iTempIndex)
        {
            try
            {
                StringBuilder sbValues = new StringBuilder();
                DataTable dtUploadData = new DataTable();
                string strSuccessQry = "select " + strGlbColumns + " from " + strGlbUploadTbl + " where  " + strGlbValidation;


                string strInsQry = "Insert into " + strGlbUploadSuccess + "( " + strGlbColumns + " ) Values (";

                dtUploadData = ClsGlobal.GetData(strSuccessQry);

                foreach (DataRow dRow in dtUploadData.Rows)
                {

                    foreach (DataColumn col in dtUploadData.Columns)
                    {

                        //bool bDate = false;
                        //bool bLan = false;

                        string strColName = col.ColumnName;

                        if (strColName == "VU_REGNO")
                        {
                            sbValues.Append("'" + dRow["VU_MasterId"].ToString() + "',");
                            iGlbRegNo++;
                            continue;
                        }
                        else
                        {
                            sbValues.Append("'" + dRow[strColName].ToString() + "',");
                        }

                    }

                    string strInsert = strInsQry + sbValues.ToString();
                    strInsert = strInsert.Remove(strInsert.LastIndexOf(","));
                    strInsert += ")";

                    ClsGlobal.ExcuteDML(strInsert);
                    sbValues.Clear();
                    string strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_RegNo = '" + dRow["VU_RegNo"].ToString() + "';";
                    ClsGlobal.ExcuteDML(strDeletermp);
                }



                string strUpdateRegNo = "update lpo_templatemaster set curRegNo = " + iGlbRegNo.ToString() + " where TemplateId = " + iTempIndex.ToString();
                ClsGlobal.ExcuteDML(strUpdateRegNo);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void UploadToFailedMailMerge()
        {
            try
            {

                string strFailedQry = "insert into lpo_trnFailed ( " + strGlbColumns + " ) " +
                                       "(select " + strGlbColumns + "  from lpo_TRNUpload);";
                ClsGlobal.ExcuteDML(strFailedQry);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void UploadToTempMailMerge(DataTable dtExcelData)
        {
            try
            {
                int iColCnt = dtExcelData.Columns.Count;
                StringBuilder sbValues = new StringBuilder();
                int iRegNo = 1;
                foreach (DataRow dRow in dtExcelData.Rows)
                {
                    for (int i = 0; i < iColCnt; i++)
                    {
                        string strRepSingleQuote = dRow[i].ToString();
                        strRepSingleQuote = strRepSingleQuote.Replace("'", "");
                        sbValues.Append("'" + strRepSingleQuote + "',");
                    }

                    sbValues.Append("'" + iRegNo.ToString() + "',");
                    sbValues.Append("'',");
                    sbValues.Append("'" + System.DateTime.Now.ToShortDateString() + "',");
                    sbValues.Append("'N',");
                    sbValues.Append("'MailMerge',");
                    sbValues.Append("'" + strGlbFileName + "')");

                    string strInsQry = "Insert into " + strGlbUploadTbl + "( " + strGlbColumns + ") Values (";
                    string strInsert = strInsQry + sbValues.ToString();
                    sbValues.Clear();
                    ClsGlobal.ExcuteDML(strInsert);
                    iRegNo++;
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void SetGlobalVars(int iTempIndex)
        {
            DataTable dtTables = new DataTable();
            try
            {
                string strGetTableQry = "select TemplateName, UploadTableName, UploadTableNameSuccess, " +
                "UploadTableNameFailed, TemplateID, CurRegNo, RegNoTO, Validation from lpo_templatemaster where TemplateID = " + iTempIndex.ToString();
                dtTables = ClsGlobal.GetData(strGetTableQry);
                foreach (DataRow row in dtTables.Rows)
                {
                    //strGlbColumns = row["TemplateName"].ToString();
                    iGlbRegNo = Convert.ToInt32(row["CurRegNo"]);
                    strGlbUploadTbl = row["UploadTableName"].ToString();
                    strGlbUploadSuccess = row["UploadTableNameSuccess"].ToString();
                    strGlbUploadFailed = row["UploadTableNameFailed"].ToString();
                    strGlbValidation = row["Validation"].ToString();

                }
                dtTables = new DataTable();
                string strTruncate = "TRUNCATE TABLE " + strGlbUploadTbl;
                ClsGlobal.ExcuteDML(strTruncate);
                string strColQry = "select Group_Concat(a.DB_ColName, '') as DBColumns from lpo_genericcolmaster a  JOIN lpo_excelcolmappingmaster b " +
                                    "ON a.Col_ID = b.Col_ID and b.TemplateID = " + iTempIndex.ToString() + " order by b.ExcelSquenceId; ; ";
                dtTables = ClsGlobal.GetData(strColQry);
                foreach (DataRow row in dtTables.Rows)
                {
                    strGlbColumns = row["DBColumns"].ToString();
                }
                dtTables.Clear();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);

            }
        }

        //private static void InsertIntoUploadtbl(int iTempIndex, string strGlbUploadTbl, object dtExcelData)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
