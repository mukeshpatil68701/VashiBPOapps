﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace LPO_Dev
{
    public partial class MenuAccess : Form
    {
        public MenuAccess()
        {
            InitializeComponent();
        }
        private void PopulateTreeView(int parentId, TreeNode parentNode)
        {

            DataTable dtChild = clsMain.GetData("SELECT SubMenu_Id,Sub_Menu_Name FROM vu_admin_submenumaster WHERE Menu_Id_fk = " + parentId);
            string SubMenu = string.Empty;
            string SubMenuId = string.Empty;
            TreeNode root = new TreeNode();

            TreeNode childNode = new TreeNode();

            if (dtChild.Rows.Count > 0)
            {
               
                for (int i = 0; i < dtChild.Rows.Count; i++)
                {

                    SubMenu = dtChild.Rows[i]["Sub_Menu_Name"].ToString();
                    SubMenuId = dtChild.Rows[i]["SubMenu_Id"].ToString();
                    childNode.Tag = dtChild.Rows[i]["SubMenu_Id"].ToString();
                    childNode.Text = dtChild.Rows[i]["Sub_Menu_Name"].ToString();
                    if (parentNode == null)

                        treeView1.Nodes.Add(SubMenu);

                    else
                        parentNode.Nodes.Add(SubMenu);

                }
            }
        }

        private void MenuAccess_Load_1(object sender, EventArgs e)
        {

            BindOperator();
            DataTable dt = new DataTable();
            dt = clsMain.GetData("SELECT MenuID, MenuName FROM vu_admin_menumaster");
            if (dt.Rows.Count > 0)
            {

                foreach (DataRow dr in dt.Rows)
                {
                    TreeNode parentNode = new TreeNode();
                    TreeNode _parentNode = new TreeNode();
                    parentNode.Tag = dr["MenuID"].ToString();
                    parentNode.Text = dr["MenuName"].ToString();
                    _parentNode.Text = dr["MenuName"].ToString();
                    treeView1.Nodes.Add(parentNode);
                  
                    PopulateTreeView(Convert.ToInt32(dr["MenuID"].ToString()), parentNode);
                }
                treeView1.ExpandAll();

            }
        }

        public void BindOperator()
        {
            try
            {
                string StrSql = "select GroupId,Group_Name from VU_Admin_GroupMaster ";
                DataTable dt = clsMain.GetData(StrSql);
                clsMain.Bind_Combo(cmdOperator, dt, "Group_Name", "GroupId");
            }
            catch (Exception ex)
            {


                MessageBox.Show(ex.Message);
            }
        }


       
        private bool updatingTreeView;
        private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
        {
            try
            {
                if (updatingTreeView) return;
                updatingTreeView = true;
                SelectParents(e.Node, e.Node.Checked);
                updatingTreeView = false;
                string ChildNode = e.Node.Text;

                ClsProperty.ChildTag = ChildNode;
             
                e.Node.TreeView.BeginUpdate();
                if (e.Node.Nodes.Count > 0)
                {
                    var parentNode = e.Node;
                    var nodes = e.Node.Nodes;
                    CheckedOrUnCheckedNodes(parentNode, nodes);
                }
            }
            finally
            {
                e.Node.TreeView.EndUpdate();
            }
        }
        private void SelectParents(TreeNode node, Boolean isChecked)
        {
            if (node.Parent != null)
            {
                
                node.Parent.Checked = isChecked;
                ClsProperty.ParentTag = node.Parent.Tag.ToString();
                SelectParents(node.Parent, isChecked);
               
            }
        }
        private void CheckedOrUnCheckedNodes(TreeNode parentNode, TreeNodeCollection nodes)
        {
            if (nodes.Count > 0)
            {
                foreach (TreeNode node in nodes)
                {
                    node.Checked = parentNode.Checked;
                    CheckedOrUnCheckedNodes(parentNode, node.Nodes);
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult cancel = new DialogResult();
            this.Close();
         
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string StrGetRC = string.Empty;
               
                string StrInsert = string.Empty;
                string StrMenu = string.Empty;
                string Child_node = string.Empty;
                string Parent_Tag = String.Empty;
                string ParentTag = string.Empty;
                DataTable dtSubMenu = new DataTable();
                string SubMenuID = string.Empty;
                string SubMenu_ID = string.Empty;
                string MenuID = string.Empty;
                string Value = string.Empty;
                if (treeView1.Nodes.Count > 0)
                {
                    foreach (TreeNode node in treeView1.Nodes)
                    {
                        if (node.Checked == true)
                        {
                        
                            ParentTag = node.Tag.ToString();
                            Parent_Tag += "'" + ParentTag.Trim() + "'" + ",";
                          
                            if (ParentTag != null)
                            {
                                StrMenu = "select * from vu_admin_submenumaster  where Menu_Id_fk in (" + ParentTag + " ) ";
                                DataTable dtMenu = clsMain.GetData(StrMenu);
                                if (dtMenu.Rows.Count > 0)
                                {      
                                    if (HasChildren == true)
                                    {
                                        if (node.Checked == true)
                                        {
                                            foreach (TreeNode childNode in node.Nodes)
                                            {
                                                if (childNode.Checked == true)
                                                {

                                                    var ChildNode = childNode.Text.Trim();
                                                    Child_node += "'" + ChildNode + "'" + ",";


                                                }

                                            }

                                       

                                        }
                                    }
                                }
                                else
                                {
                                    Value += " ('" + cmdOperator.SelectedValue + "','0','" + ParentTag + "','" + DateTime.Now.ToString("dd/MM/yyyy") + "','" + ClsProperty.UserName + "'),";
                                }


                            }

                        }

                    }
                    Child_node = Child_node.Remove(Child_node.LastIndexOf(","));
                    Parent_Tag = Parent_Tag.Remove(Parent_Tag.LastIndexOf(","));


                    StrGetRC = "select * from vu_admin_submenumaster  where Menu_Id_fk  in (" + Parent_Tag + " ) and Sub_Menu_Name in (" + Child_node + ");";
                    if (StrMenu != string.Empty)
                    {

                        dtSubMenu = clsMain.GetData(StrGetRC);
                        if (dtSubMenu.Rows.Count > 0)
                        {
                            for (int i = 0; i < dtSubMenu.Rows.Count; i++)
                            {
                                SubMenuID = dtSubMenu.Rows[i]["SubMenu_Id"].ToString();
                                MenuID = dtSubMenu.Rows[i]["Menu_Id_fk"].ToString();
                                Value += " ('" + cmdOperator.SelectedValue + "','" + SubMenuID + "','" + MenuID + "','" + DateTime.Now.ToString("dd/MM/yyyy") + "','" + ClsProperty.UserName + "'),";


                            }

                            string StrDelete = "delete from vu_admin_menuaccessmast  where Group_Id_fk='" + cmdOperator.SelectedValue + "'";
                            bool IsDelete = clsMain.ExcuteDML(StrDelete);
                            StrInsert = "Insert  Into vu_admin_menuaccessmast(Group_Id_fk,SubMenu_Id_fk,Menu_Id_fk,Created_On,Created_by)  Values " + Value.TrimEnd(',') + ";";

                            bool Insert = clsMain.ExcuteDML(StrInsert);
                            if (Insert == true)
                            {
                                MessageBox.Show("Insert Successfully..");
                                return;
                            }
                            else
                            {
                                MessageBox.Show("Please try again..");
                                return;
                            }
                        }
                    }
                }
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }
        }

    }
}
