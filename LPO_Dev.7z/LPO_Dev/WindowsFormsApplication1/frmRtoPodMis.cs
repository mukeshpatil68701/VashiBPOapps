﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    public partial class frmRtoPodMis : Form
    {
        public frmRtoPodMis()
        {
            InitializeComponent();
        }

        private void frmRtoPodMis_Load(object sender, EventArgs e)
        {
            frmDT.Format = DateTimePickerFormat.Short;
            frmDT.Format = DateTimePickerFormat.Custom;
            frmDT.CustomFormat = "dd/MM/yyyy";
            ToDT.Format = DateTimePickerFormat.Short;
            ToDT.Format = DateTimePickerFormat.Custom;
            ToDT.CustomFormat = "dd/MM/yyyy";

            bool bCon = false;

            bCon = PGlobalclass.Connect();
            if (bCon)
            {
                PGlobalclass.cmbFillRTO(this);
            }
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this .Close();
        }

        private void btnMIS_Click(object sender, EventArgs e)
        {
            bool bCon = false;
            bCon = PGlobalclass.Connect();
            if (bCon)
            {
                PGlobalclass.GenerateExcl(this, cmbTemplate.Text.ToString(), frmDT .Text.ToString(), ToDT.Text.ToString(), cmbDispatchmode.Text.ToString());

                MessageBox.Show(" MIS Exported Successfully ");
            }
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }
    }
}
