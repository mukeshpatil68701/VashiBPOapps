﻿namespace LPO_Dev
{
    partial class RejectionData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.btnMIS = new System.Windows.Forms.Button();
            this.cmbTemplate = new System.Windows.Forms.ComboBox();
            this.lblFileSelect = new System.Windows.Forms.Label();
            this.lblTemplate = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbFile_Name = new System.Windows.Forms.ComboBox();
            this.DTdate = new System.Windows.Forms.DateTimePicker();
            this.chkdt = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(234, 149);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnMIS
            // 
            this.btnMIS.Location = new System.Drawing.Point(151, 149);
            this.btnMIS.Name = "btnMIS";
            this.btnMIS.Size = new System.Drawing.Size(75, 23);
            this.btnMIS.TabIndex = 12;
            this.btnMIS.Text = "&Generate Report";
            this.btnMIS.UseVisualStyleBackColor = true;
            this.btnMIS.Click += new System.EventHandler(this.btnMIS_Click);
            // 
            // cmbTemplate
            // 
            this.cmbTemplate.FormattingEnabled = true;
            this.cmbTemplate.Location = new System.Drawing.Point(151, 31);
            this.cmbTemplate.Name = "cmbTemplate";
            this.cmbTemplate.Size = new System.Drawing.Size(159, 21);
            this.cmbTemplate.TabIndex = 9;
            this.cmbTemplate.Leave += new System.EventHandler(this.cmbTemplate_Leave);
            // 
            // lblFileSelect
            // 
            this.lblFileSelect.AutoSize = true;
            this.lblFileSelect.Location = new System.Drawing.Point(94, 99);
            this.lblFileSelect.Name = "lblFileSelect";
            this.lblFileSelect.Size = new System.Drawing.Size(54, 13);
            this.lblFileSelect.TabIndex = 8;
            this.lblFileSelect.Text = "File Name";
            // 
            // lblTemplate
            // 
            this.lblTemplate.AutoSize = true;
            this.lblTemplate.Location = new System.Drawing.Point(65, 35);
            this.lblTemplate.Name = "lblTemplate";
            this.lblTemplate.Size = new System.Drawing.Size(82, 13);
            this.lblTemplate.TabIndex = 7;
            this.lblTemplate.Text = "Template Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Select Date";
            // 
            // cmbFile_Name
            // 
            this.cmbFile_Name.FormattingEnabled = true;
            this.cmbFile_Name.Location = new System.Drawing.Point(151, 95);
            this.cmbFile_Name.Name = "cmbFile_Name";
            this.cmbFile_Name.Size = new System.Drawing.Size(273, 21);
            this.cmbFile_Name.TabIndex = 27;
            // 
            // DTdate
            // 
            this.DTdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DTdate.Location = new System.Drawing.Point(153, 62);
            this.DTdate.Name = "DTdate";
            this.DTdate.Size = new System.Drawing.Size(120, 20);
            this.DTdate.TabIndex = 28;
            this.DTdate.Value = new System.DateTime(2017, 4, 3, 0, 0, 0, 0);
            this.DTdate.ValueChanged += new System.EventHandler(this.DTdate_ValueChanged);
            // 
            // chkdt
            // 
            this.chkdt.AutoSize = true;
            this.chkdt.Location = new System.Drawing.Point(279, 65);
            this.chkdt.Name = "chkdt";
            this.chkdt.Size = new System.Drawing.Size(15, 14);
            this.chkdt.TabIndex = 29;
            this.chkdt.UseVisualStyleBackColor = true;
            this.chkdt.CheckedChanged += new System.EventHandler(this.chkdt_CheckedChanged);
            // 
            // RejectionData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 195);
            this.Controls.Add(this.chkdt);
            this.Controls.Add(this.DTdate);
            this.Controls.Add(this.cmbFile_Name);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnMIS);
            this.Controls.Add(this.cmbTemplate);
            this.Controls.Add(this.lblFileSelect);
            this.Controls.Add(this.lblTemplate);
            this.Name = "RejectionData";
            this.Text = "RejectionData";
            this.Load += new System.EventHandler(this.RejectionData_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnMIS;
        private System.Windows.Forms.ComboBox cmbTemplate;
        private System.Windows.Forms.Label lblFileSelect;
        private System.Windows.Forms.Label lblTemplate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbFile_Name;
        private System.Windows.Forms.DateTimePicker DTdate;
        private System.Windows.Forms.CheckBox chkdt;
    }
}