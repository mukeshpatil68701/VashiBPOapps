﻿namespace LPO_Dev
{
    partial class frmUpload
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlUpload = new System.Windows.Forms.Panel();
            this.gbD3CC = new System.Windows.Forms.GroupBox();
            this.rbInland = new System.Windows.Forms.RadioButton();
            this.rbCourier = new System.Windows.Forms.RadioButton();
            this.pnlMailMergeCnt = new System.Windows.Forms.Panel();
            this.lblMMCnt = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnUpload = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.cmbTemplate = new System.Windows.Forms.ComboBox();
            this.lblFileSelect = new System.Windows.Forms.Label();
            this.lblTemplate = new System.Windows.Forms.Label();
            this.ofdXlS = new System.Windows.Forms.OpenFileDialog();
            this.gbOdrn = new System.Windows.Forms.GroupBox();
            this.rbReg = new System.Windows.Forms.RadioButton();
            this.rbSP = new System.Windows.Forms.RadioButton();
            this.pnlUpload.SuspendLayout();
            this.gbD3CC.SuspendLayout();
            this.pnlMailMergeCnt.SuspendLayout();
            this.gbOdrn.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlUpload
            // 
            this.pnlUpload.Controls.Add(this.gbOdrn);
            this.pnlUpload.Controls.Add(this.gbD3CC);
            this.pnlUpload.Controls.Add(this.pnlMailMergeCnt);
            this.pnlUpload.Controls.Add(this.btnClose);
            this.pnlUpload.Controls.Add(this.btnUpload);
            this.pnlUpload.Controls.Add(this.btnBrowse);
            this.pnlUpload.Controls.Add(this.txtPath);
            this.pnlUpload.Controls.Add(this.cmbTemplate);
            this.pnlUpload.Controls.Add(this.lblFileSelect);
            this.pnlUpload.Controls.Add(this.lblTemplate);
            this.pnlUpload.Location = new System.Drawing.Point(13, 6);
            this.pnlUpload.Name = "pnlUpload";
            this.pnlUpload.Size = new System.Drawing.Size(414, 227);
            this.pnlUpload.TabIndex = 0;
            // 
            // gbD3CC
            // 
            this.gbD3CC.Controls.Add(this.rbInland);
            this.gbD3CC.Controls.Add(this.rbCourier);
            this.gbD3CC.Location = new System.Drawing.Point(28, 6);
            this.gbD3CC.Name = "gbD3CC";
            this.gbD3CC.Size = new System.Drawing.Size(232, 39);
            this.gbD3CC.TabIndex = 8;
            this.gbD3CC.TabStop = false;
            this.gbD3CC.Text = "SelectType";
            // 
            // rbInland
            // 
            this.rbInland.AutoSize = true;
            this.rbInland.Location = new System.Drawing.Point(124, 16);
            this.rbInland.Name = "rbInland";
            this.rbInland.Size = new System.Drawing.Size(54, 17);
            this.rbInland.TabIndex = 1;
            this.rbInland.TabStop = true;
            this.rbInland.Text = "Inland";
            this.rbInland.UseVisualStyleBackColor = true;
            // 
            // rbCourier
            // 
            this.rbCourier.AutoSize = true;
            this.rbCourier.Location = new System.Drawing.Point(22, 16);
            this.rbCourier.Name = "rbCourier";
            this.rbCourier.Size = new System.Drawing.Size(58, 17);
            this.rbCourier.TabIndex = 0;
            this.rbCourier.TabStop = true;
            this.rbCourier.Text = "Courier";
            this.rbCourier.UseVisualStyleBackColor = true;
            // 
            // pnlMailMergeCnt
            // 
            this.pnlMailMergeCnt.Controls.Add(this.lblMMCnt);
            this.pnlMailMergeCnt.Location = new System.Drawing.Point(74, 169);
            this.pnlMailMergeCnt.Name = "pnlMailMergeCnt";
            this.pnlMailMergeCnt.Size = new System.Drawing.Size(260, 37);
            this.pnlMailMergeCnt.TabIndex = 7;
            this.pnlMailMergeCnt.Visible = false;
            // 
            // lblMMCnt
            // 
            this.lblMMCnt.AutoSize = true;
            this.lblMMCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMMCnt.Location = new System.Drawing.Point(40, 11);
            this.lblMMCnt.Name = "lblMMCnt";
            this.lblMMCnt.Size = new System.Drawing.Size(46, 17);
            this.lblMMCnt.TabIndex = 0;
            this.lblMMCnt.Text = "label1";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(200, 131);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnUpload
            // 
            this.btnUpload.Location = new System.Drawing.Point(117, 131);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(75, 23);
            this.btnUpload.TabIndex = 5;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(282, 84);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 4;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(117, 86);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(159, 20);
            this.txtPath.TabIndex = 3;
            // 
            // cmbTemplate
            // 
            this.cmbTemplate.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbTemplate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbTemplate.FormattingEnabled = true;
            this.cmbTemplate.Location = new System.Drawing.Point(117, 51);
            this.cmbTemplate.Name = "cmbTemplate";
            this.cmbTemplate.Size = new System.Drawing.Size(159, 21);
            this.cmbTemplate.TabIndex = 2;
            this.cmbTemplate.SelectedIndexChanged += new System.EventHandler(this.cmbTemplate_SelectedIndexChanged);
            // 
            // lblFileSelect
            // 
            this.lblFileSelect.AutoSize = true;
            this.lblFileSelect.Location = new System.Drawing.Point(25, 94);
            this.lblFileSelect.Name = "lblFileSelect";
            this.lblFileSelect.Size = new System.Drawing.Size(56, 13);
            this.lblFileSelect.TabIndex = 1;
            this.lblFileSelect.Text = "Select File";
            // 
            // lblTemplate
            // 
            this.lblTemplate.AutoSize = true;
            this.lblTemplate.Location = new System.Drawing.Point(25, 51);
            this.lblTemplate.Name = "lblTemplate";
            this.lblTemplate.Size = new System.Drawing.Size(82, 13);
            this.lblTemplate.TabIndex = 0;
            this.lblTemplate.Text = "Template Name";
            // 
            // ofdXlS
            // 
            this.ofdXlS.FileName = "openFileDialog1";
            this.ofdXlS.Title = "Select File To Upload";
            // 
            // gbOdrn
            // 
            this.gbOdrn.Controls.Add(this.rbReg);
            this.gbOdrn.Controls.Add(this.rbSP);
            this.gbOdrn.Location = new System.Drawing.Point(86, 167);
            this.gbOdrn.Name = "gbOdrn";
            this.gbOdrn.Size = new System.Drawing.Size(232, 39);
            this.gbOdrn.TabIndex = 9;
            this.gbOdrn.TabStop = false;
            this.gbOdrn.Text = "SelectType";
            this.gbOdrn.Visible = false;
            // 
            // rbReg
            // 
            this.rbReg.AutoSize = true;
            this.rbReg.Location = new System.Drawing.Point(124, 16);
            this.rbReg.Name = "rbReg";
            this.rbReg.Size = new System.Drawing.Size(45, 17);
            this.rbReg.TabIndex = 1;
            this.rbReg.TabStop = true;
            this.rbReg.Text = "Reg";
            this.rbReg.UseVisualStyleBackColor = true;
            // 
            // rbSP
            // 
            this.rbSP.AutoSize = true;
            this.rbSP.Location = new System.Drawing.Point(22, 16);
            this.rbSP.Name = "rbSP";
            this.rbSP.Size = new System.Drawing.Size(39, 17);
            this.rbSP.TabIndex = 0;
            this.rbSP.TabStop = true;
            this.rbSP.Text = "SP";
            this.rbSP.UseVisualStyleBackColor = true;
            // 
            // frmUpload
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 240);
            this.Controls.Add(this.pnlUpload);
            this.Name = "frmUpload";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmUpload_Load);
            this.pnlUpload.ResumeLayout(false);
            this.pnlUpload.PerformLayout();
            this.gbD3CC.ResumeLayout(false);
            this.gbD3CC.PerformLayout();
            this.pnlMailMergeCnt.ResumeLayout(false);
            this.pnlMailMergeCnt.PerformLayout();
            this.gbOdrn.ResumeLayout(false);
            this.gbOdrn.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlUpload;
        private System.Windows.Forms.Label lblFileSelect;
        private System.Windows.Forms.Label lblTemplate;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.ComboBox cmbTemplate;
        private System.Windows.Forms.OpenFileDialog ofdXlS;
        private System.Windows.Forms.Panel pnlMailMergeCnt;
        private System.Windows.Forms.Label lblMMCnt;
        private System.Windows.Forms.GroupBox gbD3CC;
        private System.Windows.Forms.RadioButton rbInland;
        private System.Windows.Forms.RadioButton rbCourier;
        private System.Windows.Forms.GroupBox gbOdrn;
        private System.Windows.Forms.RadioButton rbReg;
        private System.Windows.Forms.RadioButton rbSP;
    }
}

