﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LPO_Dev
{
    public partial class MenuMaster : Form
    {
        public MenuMaster()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string ActiveFlag = string.Empty;
                if (txtMenu.Text == "")
                {
                    MessageBox.Show("Please Enter Menu name !!");
                    return;
                }

                if (chkActive.Checked == true)
                {
                    ActiveFlag = "Y";
                }
                else
                {
                    ActiveFlag = "N";
                }

                DateTime currentDate = DateTime.Now;
                if (btnSave.Text == "Update")
                {

                    string StrSqlUpdate = "Update vu_admin_menumaster  set MenuName='" + txtMenu.Text.Trim() + "',IsFlag='" + ActiveFlag + "' where MenuId='" + ClsProperty.MenuID + "'";
                    bool Update = clsMain.ExcuteDML(StrSqlUpdate);
                    if (Update == true)
                    {
                        MessageBox.Show("Data Update Successfully..");

                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }
                }
                else
                {
                    string StrSqlInsert = "Insert into vu_admin_menumaster(MenuName,IsFlag,Created_On,Created_by )"
                       + "values ('" + txtMenu.Text.Trim() + "','Y','" + currentDate.ToString("dd-MM-yyyy") + "','" + ClsProperty.UserName + "')";


                    bool Insert = clsMain.ExcuteDML(StrSqlInsert);
                    if (Insert == true)
                    {
                        MessageBox.Show("Data Save Successfully..");
                    
                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }

                }
                BindGV();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        public void BindGV()
        {
            try
            {
                String StrData = "select* from vu_admin_menumaster  where IsFlag='Y'";

                DataTable Objdt = new DataTable();
                Objdt = clsMain.GetData(StrData);
                if (Objdt.Rows.Count > 0)
                {

                    dtGvMenu.AutoGenerateColumns = false;
                    dtGvMenu.Columns[1].Name = "MenuID";
                    dtGvMenu.Columns[1].HeaderText = "Menu ID";
                    dtGvMenu.Columns[1].DataPropertyName = "MenuID";
                    dtGvMenu.Columns[1].Width = 100;

                    dtGvMenu.Columns[2].Name = "MenuName";
                    dtGvMenu.Columns[2].HeaderText = "Menu Name";
                    dtGvMenu.Columns[2].DataPropertyName = "MenuName";
                    dtGvMenu.Columns[2].Width = 200;

                    dtGvMenu.Columns[3].Name = "IsFlag";
                    dtGvMenu.Columns[3].HeaderText = "Is Flag";
                    dtGvMenu.Columns[3].DataPropertyName = "IsFlag";
                    dtGvMenu.Columns[3].Width = 100;

                    dtGvMenu.AllowUserToAddRows = false;

                    dtGvMenu.DataSource = Objdt;

                }
            }
            catch (Exception ex)
            {


                MessageBox.Show(ex.Message);
            }
        }

        private void MenuMaster_Load(object sender, EventArgs e)
        {
            BindGV();
        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtMenu.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string StrDelete = string.Empty;
            List<DataGridViewRow> selectedRows = (from row in dtGvMenu.Rows.Cast<DataGridViewRow>()
                                                  where Convert.ToBoolean(row.Cells["ChkColumn"].Value) == true
                                                  select row).ToList();
            if (MessageBox.Show(string.Format("Do you want to delete {0} rows?", selectedRows.Count), "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (DataGridViewRow row in selectedRows)
                {
                    StrDelete = "Delete  from vu_admin_menumaster  WHERE MenuID='" + row.Cells["MenuID"].Value + "'";
                    bool Delete = clsMain.ExcuteDML(StrDelete);
                    if (Delete == true)
                    {
                        MessageBox.Show("Data Delete Successfully..");
                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }
               
                }

                this.BindGV();
            }
        }

        private void dtGvMenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int row;

                row = e.RowIndex;

                string Menu_Id = dtGvMenu.Rows[row].Cells["MenuID"].Value.ToString();
                ClsProperty.MenuID = Menu_Id;
                string MenuName = dtGvMenu.Rows[row].Cells["MenuName"].Value.ToString();
                txtMenu.Text = MenuName;
                string ISFlag = dtGvMenu.Rows[row].Cells["IsFlag"].Value.ToString();
                if (ISFlag == "Y")
                {
                    chkActive.Checked = true;
                }
                else
                {
                    chkActive.Checked = false;
                }

                btnSave.Text = "Update";
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

       
    }

}
