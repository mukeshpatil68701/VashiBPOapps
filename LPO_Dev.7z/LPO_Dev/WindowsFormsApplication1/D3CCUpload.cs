﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LPO_Dev
{
    static class D3CCUpload
    {
        static int iGlbRegNo = 0;
        static string strGlbUploadTbl = string.Empty;
        static string strGlbUploadSuccess = string.Empty;
        static string strGlbUploadFailed = string.Empty;
        static string strGlbValidation = string.Empty;
        static string strGlbColumns = string.Empty;
        static string strGlbFileName = string.Empty;
        static string strGlbAppstartID = string.Empty;
        public static string strGlbBatchID = string.Empty;
        public static Hashtable htGlbColTyp = new Hashtable();

        static string strGlbTemplateName = string.Empty;
        static string strGlbInputFilePath = string.Empty;
        static string strGlbTemplateLocation = string.Empty;



        internal static void ProcessD3CC(int iTempIndex, string txtPath, string strDispatchMode)
        {
            try
            {
                strGlbFileName = Path.GetFileNameWithoutExtension(txtPath);
                int iFieldCount = ClsGlobal.getExcelColcnt(iTempIndex);
                int iColCntfile = getFileColCount(txtPath);
                if (iFieldCount != iColCntfile)
                {
                    MessageBox.Show("Incorrect file format");
                    return;
                }

                strGlbInputFilePath = txtPath;
                SetGlobalVars(iTempIndex);
                tempUpload(txtPath);
                updateBasicValues(strDispatchMode);
                generateAppStart();

                //if (strDispatchMode == "INLAND")
                //{
                //    DataTable dtUploadData = new DataTable();
                //    string strUploadqry = "select ID," + strGlbColumns + " from " + strGlbUploadTbl + " where " + strGlbValidation +
                //        " Order by VU_AppPincode";
                //    dtUploadData = ClsGlobal.GetData(strUploadqry);
                //    uploadToSuccess(strDispatchMode, dtUploadData);
                //}


                if (strDispatchMode == "INLAND")
                {
                    DataTable dtUploadData = new DataTable();
                    string strUploadqry = "select ID," + strGlbColumns + " from " + strGlbUploadTbl + " where " + strGlbValidation +
                        " Order by VU_AppPincode";
                    dtUploadData = ClsGlobal.GetData(strUploadqry);
                    uploadToSuccess(strDispatchMode, dtUploadData, iTempIndex);
                }

                if (strDispatchMode == "COURIER")
                {
                    DataTable dtUploadData = new DataTable();
                    string strUploadqry = "select ID," + strGlbColumns + " from " + strGlbUploadTbl + " where " + strGlbValidation +
                        " And VU_DispatchMode = 'COURIER' Order by VU_AppPincode";
                    dtUploadData = ClsGlobal.GetData(strUploadqry);
                    if (dtUploadData.Rows.Count > 0)
                    {
                        uploadToSuccess(strDispatchMode, dtUploadData, iTempIndex);
                    }

                    dtUploadData = new DataTable();
                    strUploadqry = "select ID," + strGlbColumns + " from " + strGlbUploadTbl + " where " + strGlbValidation +
                        " And VU_DispatchMode = 'INLAND' Order by VU_AppPincode";
                    dtUploadData = ClsGlobal.GetData(strUploadqry);
                    if (dtUploadData.Rows.Count > 0)
                    {
                        dtUploadData = ClsGlobal.GetData(strUploadqry);
                        uploadToSuccess(strDispatchMode, dtUploadData, iTempIndex);
                    }



                }

                uploadToFailed();

                int iSuccessCnt = 0;
                iSuccessCnt = getSuccessCnt(strGlbUploadSuccess, strGlbFileName, strGlbTemplateName);

                string strUpdateRegNo = "update lpo_templatemaster set curRegNo = " + iGlbRegNo.ToString() + " where TemplateId = " + iTempIndex.ToString();
                ClsGlobal.ExcuteDML(strUpdateRegNo);

                UpdateLogFile(strGlbFileName, strGlbAppstartID, strGlbBatchID, 0, strGlbTemplateName);
                CreateFolderStructure(ClsGlobal.strGlbPath);

                MessageBox.Show("File Upload Successfully !!");

                reportGeneration(strDispatchMode);

                

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void reportGeneration(string strDispatchMode)
        {
            try
            {
                if (strDispatchMode == "INLAND")
                {
                    string strInlandCondition = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'INLAND'";
                    string strInlandRptPath = strGlbTemplateLocation + "CrRptD3CCInland.rpt";

                    GenerateReport(strInlandCondition, ClsGlobal.strGlbOutputPathReport + "\\" + strGlbFileName + "_INLAND.pdf", strInlandRptPath);


                    string strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strInlandCondition;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);

                }

                else if (strDispatchMode == "COURIER")
                {
                    string strInlandCondition = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'INLAND'";
                    string strInlandRptPath = strGlbTemplateLocation + "CrRptD3CCInland.rpt";

                    GenerateReport(strInlandCondition, ClsGlobal.strGlbOutputPathReport + "\\" + strGlbFileName + "_INLAND.pdf", strInlandRptPath);

                    string strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strInlandCondition;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);

                    strInlandCondition = string.Empty;
                    strInlandCondition = " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'COURIER'";
                    strInlandRptPath = strGlbTemplateLocation + "CrRptD3CCCourier.rpt";

                    GenerateReport(strInlandCondition, ClsGlobal.strGlbOutputPathReport + "\\" + strGlbFileName + "_COURIER.pdf", strInlandRptPath);

                    strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strInlandCondition;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);

                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        public static void UpdateLogFile(string strGlbFileName, string strGlbAppstartID, string strGlbBatchID, int iRowCont, string strGlbTemplateName)
        {
            try
            {
                string strUpdateFileLog = "Insert into vu_fileuploadlog (FileName, " +
                " UploadDate, BatchId, AppStartNo,NumberofRecords,TemplateName) Values ('" +
                 strGlbFileName + "','" + DateTime.Now.ToShortDateString() + "','" + strGlbBatchID + "','" + strGlbAppstartID + "','" +
                  iRowCont.ToString() + "','" + strGlbTemplateName + "')";

                ClsGlobal.ExcuteDML(strUpdateFileLog);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void CreateFolderStructure(string strGlbPath)
        {
            try
            {

                String strDt = DateTime.Now.ToString("dd MMM yyyy");
                string strOutputPath = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt;
                string strInputFile = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Input";

                //strGlbOutputPathBulk = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "BulkRegister";
                ClsGlobal.strGlbOutputPathReport = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Report";
                //strGlbOutputPathSticker = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Sticker";


                if (!Directory.Exists(strInputFile))
                {
                    Directory.CreateDirectory(strInputFile);

                }
                File.Copy(strGlbInputFilePath, strInputFile + "\\" + strGlbFileName + ".txt", true);
                if (!Directory.Exists(strOutputPath))
                {
                    Directory.CreateDirectory(strOutputPath);
                }

                if (!Directory.Exists(ClsGlobal.strGlbOutputPathReport))
                {
                    Directory.CreateDirectory(ClsGlobal.strGlbOutputPathReport);
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }


        private static void GenerateReport(string strReportcond, string strRepoPath, string strserverRptPath)
        {
            try
            {
                string strSudiptoSign = ConfigurationManager.AppSettings["defaultSignatureSudipto"].ToString();
                string strQry = "truncate table " + ClsGlobal.const_strReportTable;
                ClsGlobal.ExcuteDML(strQry);

                string strInsertRpt = "Insert into " + ClsGlobal.const_strReportTable + "( " + strGlbColumns + ")" + "(select " + strGlbColumns +
                    " from " + strGlbUploadSuccess + strReportcond + " )";

                ClsGlobal.ExcuteDML(strInsertRpt);

                if (strGlbTemplateName == "D3CC")
                {
                    string strNonDunning = "update " + ClsGlobal.const_strReportTable + " set  VU_SignaturePath = " +
                                            "'" + strSudiptoSign + "'";


                    ClsGlobal.ExcuteDML(strNonDunning);

                }




                ReportDocument cryRpt = new ReportDocument();
                //cryRpt.Refresh();
                cryRpt.Load(strserverRptPath);

                cryRpt.Refresh();
                ExportOptions CrExportOptions;
                DiskFileDestinationOptions CrDiskFileDestinationOptions = new DiskFileDestinationOptions();
                PdfRtfWordFormatOptions CrFormatTypeOptions = new PdfRtfWordFormatOptions();
                CrDiskFileDestinationOptions.DiskFileName = strRepoPath;
                CrExportOptions = cryRpt.ExportOptions;
                {
                    CrExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
                    CrExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
                    CrExportOptions.DestinationOptions = CrDiskFileDestinationOptions;
                    CrExportOptions.FormatOptions = CrFormatTypeOptions;
                }

                cryRpt.Export();
                MessageBox.Show("Report Generated SuccessFully");
                cryRpt.Refresh();

                cryRpt.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void uploadToFailed()
        {
            try
            {
                string strInsertRpt = "Insert into " + strGlbUploadFailed + "( " + strGlbColumns + ")" + "(select " +
                    strGlbColumns +
                    " from " + strGlbUploadTbl + " )";

                ClsGlobal.ExcuteDML(strInsertRpt);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void uploadToSuccess(string strDispatchMode, DataTable dtUploadData, int TemplateID)
        {
            //DataTable dtUploadData = new DataTable();
            StringBuilder sbValues = new StringBuilder();
            Hashtable htRegNo = new Hashtable();
            Hashtable htMasterId = new Hashtable();

            double dAppstart = Convert.ToDouble(strGlbAppstartID);
            string strInsQry = "Insert into " + strGlbUploadSuccess + "( " + strGlbColumns + ") Values (";

            try
            {
                //if (strDispatchMode == "INLAND")
                //{
                //    string strUploadqry = "select ID," + strGlbColumns + " from " + strGlbUploadTbl + " where " + strGlbValidation +
                //        " Order by VU_AppPincode";
                //    dtUploadData = ClsGlobal.GetData(strUploadqry);
                //}


                foreach (DataRow dRow in dtUploadData.Rows)
                {

                    bool bExecute = true;
                    foreach (DataColumn col in dtUploadData.Columns)
                    {
                        bool bDate = false;
                        //bool bLan = false;
                        string strColName = col.ColumnName;
                        string strColType = string.Empty;

                        if (strColName != "ID")
                        {
                            strColType = htGlbColTyp[strColName].ToString();
                        }

                        if (strColType == "Date")
                        {
                            bDate = ClsValidations.DateValidate(dRow[strColName].ToString(), "");
                            if (bDate)
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }


                        else if (strColName == "VU_REGNO")
                        {
                            if (!htRegNo.Contains(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()))
                            {
                                htRegNo.Add(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString(), iGlbRegNo.ToString());
                                sbValues.Append("'" + iGlbRegNo.ToString() + "',");
                                iGlbRegNo += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }

                        }
                        else if (strColName == "VU_IsPrinted")
                        {
                            sbValues.Append("'N'" + ",");
                            continue;
                        }

                        else if (strColName == "VU_MasterID")
                        {
                            if (!htMasterId.Contains(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()))
                            {
                                htMasterId.Add(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()
                                   , dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }

                        }
                        else if (strColName == "VU_BatchNO")
                        {
                            sbValues.Append(strGlbBatchID + ",");
                            continue;
                        }
                        else
                        {
                            if (strColName != "ID")
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                            }

                        }
                    }

                    if (bExecute)
                    {


                        string strInsert = strInsQry + sbValues.ToString();

                        //sbValues.Replace()
                        strInsert = strInsert.Remove(strInsert.LastIndexOf(","));
                        strInsert += ")";


                        ClsGlobal.ExcuteDML(strInsert);
                        string strDeletermp = "Delete from " + strGlbUploadTbl + " where ID = '" + dRow["ID"].ToString() + "';";
                        ClsGlobal.ExcuteDML(strDeletermp);

                        sbValues.Clear();
                    }



                }
                //string StrRegNo = "update lpo_templatemaster set curRegNo = " + iGlbRegNo.ToString() + " where TemplateId = " + TemplateID.ToString();
                //string strBatchNoQry = "update lpo_trnsuccess set vu_batchno= '" + strGlbBatchID + "'";
               // ClsGlobal.ExcuteDML(strBatchNoQry);
                strGlbAppstartID = (dAppstart).ToString();


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }


        private static int getSuccessCnt(string strGlbUploadSuccess, string strGlbFileName, string strGlbTemplateName)
        {
            int icntSuccess = 0;
            DataTable dtCnt = new DataTable();
            try
            {
                string strQry = "select * from " + strGlbUploadSuccess + " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "'  group by VU_MasterID";
                dtCnt = ClsGlobal.GetData(strQry);
                icntSuccess = dtCnt.Rows.Count;
                return icntSuccess;
            }
            catch (Exception Ex)
            {

                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return 0;
            }
            finally
            {
                dtCnt.Clear();
            }
        }

        private static void updateBasicValues(string strDispatchMode)

        {
            try
            {
                //string strSudiptoSign = ConfigurationManager.AppSettings["defaultSignatureSudipto"].ToString();


                string strQry = "update " + strGlbUploadTbl + " set VU_LAnMask= VU_LAnNo, vu_FileName = '" +
                    strGlbFileName + "', vu_lanmask = Replace(vu_lanmask, SUBSTRING(vu_lanmask FROM 5 FOR(length(vu_lanmask) - 8)), 'XXXXXXXX')" +
                     ", VU_LoanOrCard = 'CARD' , VU_TemplateName = 'D3CC', VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "'";
                ClsGlobal.ExcuteDML(strQry);
                if (strDispatchMode == "INLAND")
                {
                    strQry = "update " + strGlbUploadTbl + " set VU_DispatchMode = 'INLAND'";
                    ClsGlobal.ExcuteDML(strQry);
                }
                else
                {
                    strQry = "update " + strGlbUploadTbl + " r join lpo_pincodematser_d3cc a on r.VU_AppPinCode = a.VU_Pin_Codes " +
                      "set r.VU_DispatchMode = 'COURIER'  where r.VU_AppPinCode = a.VU_Pin_Codes";
                    ClsGlobal.ExcuteDML(strQry);

                    strQry = "update " + strGlbUploadTbl + " set VU_DispatchMode = 'INLAND'" +
                     " where VU_DispatchMode <> 'COURIER' or VU_DispatchMode  is null";
                    ClsGlobal.ExcuteDML(strQry);
                }




            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void tempUpload(string strPath)
        {
            try
            {
                // strPath = "\\" + strPath;

                strPath = strPath.Replace("\\", "\\\\");
                //                string strQry = "LOAD DATA LOCAL INFILE '" + strPath + "' INTO TABLE " + strGlbUploadTbl +
                //                                 " FIELDS TERMINATED BY '|' LINES TERMINATED BY '\r\n' IGNORE 1 LINES " +
                //"(@ACCOUNT_NO, @CUS_NAME, @STMT_DATE, @DPD, @CLOSING_BAL, @MIN_DUE, @ADD0, @ADD1, @ADD2, @ADD3, @ADD4, @ADD5, @CITY, @STATE, @PINCODE, @COLL_AGENCY_CODE, " +
                //"@COLL_AGENCY_NAME, @COLL_AGENCY_ADD1, @COLL_AGENCY_ADD2, @COLL_AGENCY_ADD3, @COLL_AGENCY_ADD4, @COLL_AGENCY_ADD_CITY, @COLL_AGENCY_ADD_STATE " +
                //" , @COLL_AGENCY_ADD_PINCODE, @COLL_AGENCY_CONTACT_NO, @EMI_CYCLE_DATE, @EMI_AMOUNT) " +
                //" set VU_LANNo = @ACCOUNT_NO, VU_ApplicantName = @CUS_NAME, VU_STMTDT = @STMT_DATE, VU_DPD = @DPD, VU_CLOSINGBAL = @CLOSING_BAL, VU_MINAMTDUE = @MIN_DUE, " +
                //"  VU_AppAdd0 = @ADD0, VU_AppAdd1 = @ADD1, VU_AppAdd2 = @ADD2, VU_AppAdd3 = @ADD3, VU_AppAdd4 = @ADD4, VU_AppAdd5 = @ADD5, VU_AppCity = @CITY, " +
                //" VU_AppState = @STATE, VU_AppPincode = @PINCODE, VU_COLL_AGENCY_CODE = @COLL_AGENCY_CODE, VU_COLL_AGENCY_NAME = @COLL_AGENCY_NAME, VU_COLL_AGENCY_ADD1 = " +
                //" @COLL_AGENCY_ADD1, VU_COLL_AGENCY_ADD2 = @COLL_AGENCY_ADD2, VU_COLL_AGENCY_ADD3 = @COLL_AGENCY_ADD3, VU_COLL_AGENCY_ADD4 = @COLL_AGENCY_ADD4, " +
                //" VU_COLL_AGENCY_ADD_CITY = @COLL_AGENCY_ADD_CITY, VU_COLL_AGENCY_ADD_STATE = @COLL_AGENCY_ADD_STATE, VU_COLL_AGENCY_ADD_PINCODE = @COLL_AGENCY_ADD_PINCODE, " +
                //" VU_COLL_AGENCY_CONTACT_NO = @COLL_AGENCY_CONTACT_NO, VU_EMI_CYCLE_DATE = @EMI_CYCLE_DATE, VU_EMIAmt = @EMI_AMOUNT";


                string strQry = "LOAD DATA LOCAL INFILE '" + strPath + "' INTO TABLE " + strGlbUploadTbl +
                                    " FIELDS TERMINATED BY '|' LINES TERMINATED BY '\r\n' IGNORE 1 LINES" +
                   " (@ACCOUNT_NO, @CUS_NAME, @STMT_DATE, @CLOSING_BAL, @ADD1, @ADD2, @ADD3, @CITY, @STATE, @PINCODE," +
                    "@COLL_AGENCY_NAME, @COLL_AGENCY_ADD1, @COLL_AGENCY_ADD_CITY, @COLL_AGENCY_ADD_STATE " +
                   ", @COLL_AGENCY_ADD_PINCODE, @COLL_AGENCY_CONTACT_NO, @Type) " +
                   " set VU_LANNo = @ACCOUNT_NO, VU_ApplicantName = @CUS_NAME, VU_STMTDT = @STMT_DATE, VU_CLOSINGBAL = @CLOSING_BAL, VU_AppAdd1 = @ADD1," +
                   "VU_AppAdd2 = @ADD2, VU_AppAdd3 = @ADD3, VU_AppCity = @CITY, VU_AppState = @STATE, VU_AppPincode = @PINCODE, VU_COLL_AGENCY_NAME = @COLL_AGENCY_NAME," +
                   " VU_COLL_AGENCY_ADD1 = @COLL_AGENCY_ADD1, VU_COLL_AGENCY_ADD_CITY = @COLL_AGENCY_ADD_CITY, VU_COLL_AGENCY_ADD_STATE = @COLL_AGENCY_ADD_STATE," +
                   "VU_COLL_AGENCY_ADD_PINCODE = @COLL_AGENCY_ADD_PINCODE, VU_COLL_AGENCY_CONTACT_NO = @COLL_AGENCY_CONTACT_NO, VU_Type = @Type";


                ClsGlobal.ExcuteDML(strQry);



            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void SetGlobalVars(int iTempIndex)
        {
            DataTable dtTables = new DataTable();
            try
            {
                strGlbTemplateLocation = ConfigurationManager.AppSettings["ReportPath"].ToString();
                string strGetTableQry = "select TemplateName, UploadTableName, UploadTableNameSuccess, " +
                "UploadTableNameFailed, TemplateID, CurRegNo, RegNoTO, Validation from lpo_templatemaster where TemplateID = " + iTempIndex.ToString();
                dtTables = ClsGlobal.GetData(strGetTableQry);
                foreach (DataRow row in dtTables.Rows)
                {
                    //strGlbColumns = row["TemplateName"].ToString();
                    iGlbRegNo = Convert.ToInt32(row["CurRegNo"]);
                    strGlbUploadTbl = row["UploadTableName"].ToString();
                    strGlbUploadSuccess = row["UploadTableNameSuccess"].ToString();
                    strGlbUploadFailed = row["UploadTableNameFailed"].ToString();
                    strGlbValidation = row["Validation"].ToString();
                    strGlbTemplateName = row["TemplateName"].ToString();

                }
                dtTables = new DataTable();
                string strTruncate = "TRUNCATE TABLE " + strGlbUploadTbl;
                ClsGlobal.ExcuteDML(strTruncate);
                string strColQry = "select Group_Concat(a.DB_ColName, '') as DBColumns from lpo_genericcolmaster a  JOIN lpo_excelcolmappingmaster b " +
                                    "ON a.Col_ID = b.Col_ID and b.TemplateID = " + iTempIndex.ToString() + " order by b.ExcelSquenceId; ; ";
                dtTables = ClsGlobal.GetData(strColQry);
                foreach (DataRow row in dtTables.Rows)
                {
                    strGlbColumns = row["DBColumns"].ToString();
                }
                dtTables = new DataTable();




                strColQry = "select a.Col_ID,b.Col_ID,a.DB_ColName,b.ExcelColName, b.Type from lpo_genericcolmaster a  JOIN lpo_excelcolmappingmaster b " +
                                   "ON a.Col_ID = b.Col_ID and b.TemplateID = " + iTempIndex.ToString() + " order by b.ExcelSquenceId;";
                dtTables = ClsGlobal.GetData(strColQry);
                if (dtTables.Rows.Count > 0)
                {
                    foreach (DataRow row in dtTables.Rows)
                    {
                        if (!htGlbColTyp.Contains(row["DB_ColName"]))
                        {
                            htGlbColTyp.Add(row["DB_ColName"].ToString(), row["Type"].ToString());
                        }
                        //sbCol.Append(row["DB_ColName"].ToString() + ",");
                    }
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);

            }
        }


        private static int getFileColCount(string txtPath)
        {
            try
            {
                int iCnt = 0;
                string strHeading = string.Empty;
                strHeading = File.ReadLines(txtPath).First();

                string[] strCols = strHeading.Split('|');

                iCnt = strCols.Length;


                return iCnt;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return 0;
            }
        }


        internal static void generateAppStart()
        {
            DataTable dtFileUploadLog = new DataTable();
            string strUploadDate = string.Empty;
            string strBatchId = string.Empty;
            string strNumberofRecords = string.Empty;
            string strApp = string.Empty;
            try
            {
                string strAppStartQry = "select FileName, UploadDate, BatchId, AppStartNo,NumberofRecords" +
                     " from vu_fileuploadlog order by ID desc limit 1;";
                dtFileUploadLog = ClsGlobal.GetData(strAppStartQry);
                if (dtFileUploadLog.Rows.Count > 0)
                {
                    foreach (DataRow row in dtFileUploadLog.Rows)
                    {
                        strUploadDate = row["UploadDate"].ToString();
                        strBatchId = row["BatchId"].ToString();
                        strNumberofRecords = row["NumberofRecords"].ToString();
                        strApp = row["AppStartNo"].ToString();
                    }


                    DateTime dtUpload = Convert.ToDateTime(strUploadDate);
                    DateTime dtToday = DateTime.Now;

                    if (dtToday.Date > dtUpload.Date)
                    {
                        string strYr = DateTime.Now.Year.ToString();
                        string strDay = DateTime.Now.DayOfYear.ToString();
                        const string const_strAppNo = "0000001";

                        if (strDay.Length == 2)
                        {
                            strDay = "0" + strDay;
                        }
                        else if (strDay.Length == 1)
                        {
                            strDay = "00" + strDay;
                        }
                        strGlbAppstartID = strYr + strDay + const_strAppNo;
                        int iBatch = 1;
                        strGlbBatchID = iBatch.ToString();

                        return;
                    }
                    else
                    {
                        double iBatch = Convert.ToDouble(strBatchId) + 1;
                        strGlbBatchID = iBatch.ToString();
                        double iAppNo = Convert.ToDouble(strApp) + Convert.ToDouble(strNumberofRecords);
                        strGlbAppstartID = iAppNo.ToString();
                    }
                }


                else
                {
                    string strYr = DateTime.Now.Year.ToString();
                    string strDay = DateTime.Now.DayOfYear.ToString();
                    const string const_strAppNo = "0000001";

                    if (strDay.Length == 2)
                    {
                        strDay = "0" + strDay;
                    }
                    else if (strDay.Length == 1)
                    {
                        strDay = "00" + strDay;
                    }
                    strGlbAppstartID = strYr + strDay + const_strAppNo;
                    strGlbBatchID = "1";
                }



            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
    }
}
