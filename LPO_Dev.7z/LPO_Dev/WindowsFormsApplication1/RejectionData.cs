﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    public partial class RejectionData : Form
    {
        public RejectionData()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void RejectionData_Load(object sender, EventArgs e)
        {

            DTdate.Format = DateTimePickerFormat.Short;
            DTdate.Format = DateTimePickerFormat.Custom;
            DTdate.CustomFormat = "dd/MM/yyyy";
            DTdate.Text= DateTime.Now.ToString("dd/MM/yyyy");
            bool bCon = false;

            bCon = PGlobalclass .Connect();
            if (bCon)
            {
                PGlobalclass.cmbFillReject(this);
            }
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }      

        private void btnMIS_Click(object sender, EventArgs e)
        {
            string fname = string.Empty;
            if (cmbTemplate.Text == "SELECT ALL TEMPLATE")
            {
                DataTable dt = new DataTable();
                dt = clsMain.GetData("select distinct(VU_TemplateName) from lpo_trnfailed where  VU_uploadDate='"+ DTdate.Text.ToString() + "'");
                foreach (DataRow dr in dt.Rows)
                {
                    fname = dr["VU_TemplateName"].ToString();

                    dt = clsMain.GetData("select distinct(VU_Filename) from lpo_trnfailed where  VU_uploadDate='" + DTdate.Text.ToString() + "' and VU_TemplateName= '" + fname + "' ");
                    foreach (DataRow dr1 in dt.Rows)
                    {
                      
                            PGlobalclass.GenerateExcl(this, fname, DTdate.Text.ToString(), dr1["VU_Filename"].ToString());
                        
                     }

              
                }

                MessageBox.Show(" MIS Exported Successfully ");
            }

            else
            {
                bool bCon = false;
                bCon = PGlobalclass.Connect();
                if (bCon)
                {
                    PGlobalclass.GenerateExcl(this, cmbTemplate.Text.ToString(), DTdate.Text.ToString(), cmbFile_Name.Text.ToString());

                    MessageBox.Show(" MIS Exported Successfully ");
                }
                else
                {
                    MessageBox.Show("Unable to connect to Server");
                    return;
                }
            }

        }

        private void DTdate_ValueChanged(object sender, EventArgs e)
        {
            //bool bCon = false;
            //bCon = Rejectclass.Connect();
            //if (bCon)
            //{
            //    Rejectclass.cmbFillFileName(this, cmbTemplate.Text.ToString(), DTdate.Text.ToString());
            //}
            //else
            //{
            //    MessageBox.Show("Unable to connect to Server");
            //    return;
            //}
        }

        private void chkdt_CheckedChanged(object sender, EventArgs e)
        {
            bool bCon = false;
            bCon = PGlobalclass.Connect();
            if (bCon)
            {
                PGlobalclass.cmbFillFileName(this, cmbTemplate.Text.ToString(), DTdate.Text.ToString());
            }
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }

        private void cmbTemplate_Leave(object sender, EventArgs e)
        {
            if (cmbTemplate.Text == "SELECT ALL TEMPLATE")
            {
                lblFileSelect.Visible = false;
                cmbFile_Name.Visible = false;
            }
        }
    }
}
