﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    public partial class frmoneClickRtoDispatchMis : Form
    {
        public frmoneClickRtoDispatchMis()
        {
            InitializeComponent();
        }

        private void frmRtoPodMis_Load(object sender, EventArgs e)
        {
            frmDT.Format = DateTimePickerFormat.Short;
            frmDT.Format = DateTimePickerFormat.Custom;
            frmDT.CustomFormat = "dd/MM/yyyy";
            ToDT.Format = DateTimePickerFormat.Short;
            ToDT.Format = DateTimePickerFormat.Custom;
            ToDT.CustomFormat = "dd/MM/yyyy";        

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this .Close();
        }

        private void btnMIS_Click(object sender, EventArgs e)
        {
            DataTable dttemp = new DataTable();
            DBHelper objdb = new DBHelper();
            if (rbtRtoMIS.Checked == true)
            {

                bool bCon = false;
                bCon = PGlobalclass.Connect();
                if (bCon)
                {
                    PGlobalclass.GenerateExcloneclick(this,frmDT.Text.ToString(), ToDT.Text.ToString());

                 //   MessageBox.Show(" MIS Exported Successfully ");
                }
                else
                {
                    MessageBox.Show("Unable to connect to Server");
                    return;
                }
            }
            else if(rbtuploadMIS.Checked == true)
            {
                
                    bool bCon = false;
                bCon = PGlobalclass.Connect();
                if (bCon)
                {
                    PGlobalclass.GenerateExclUpload(this, frmDT.Text.ToString(), ToDT.Text.ToString());

                    MessageBox.Show(" MIS Exported Successfully ");
                }
                else
                {
                    MessageBox.Show("Unable to connect to Server");
                    return;
                }

            }
                    }
    }
}
