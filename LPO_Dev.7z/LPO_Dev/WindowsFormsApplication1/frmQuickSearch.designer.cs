﻿namespace LPO_Dev
{
    partial class frmQuickSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.btnExel = new System.Windows.Forms.Button();
            this.pnlbulk = new System.Windows.Forms.Panel();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.textBrowse = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.rbtnAppno = new System.Windows.Forms.RadioButton();
            this.rbtnLoanno = new System.Windows.Forms.RadioButton();
            this.btnRecords = new System.Windows.Forms.Button();
            this.Pnlsingle = new System.Windows.Forms.Panel();
            this.textAppno = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLoanno = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.rbtnBulkSearch = new System.Windows.Forms.RadioButton();
            this.rbtnSingleSearch = new System.Windows.Forms.RadioButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ofdbox = new System.Windows.Forms.OpenFileDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.pnlbulk.SuspendLayout();
            this.Pnlsingle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.btnExel);
            this.panel1.Controls.Add(this.pnlbulk);
            this.panel1.Controls.Add(this.btnRecords);
            this.panel1.Controls.Add(this.Pnlsingle);
            this.panel1.Controls.Add(this.rbtnBulkSearch);
            this.panel1.Controls.Add(this.rbtnSingleSearch);
            this.panel1.Location = new System.Drawing.Point(7, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(764, 147);
            this.panel1.TabIndex = 19;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(495, 103);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(59, 36);
            this.button4.TabIndex = 17;
            this.button4.Text = "Exit";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnExel
            // 
            this.btnExel.Location = new System.Drawing.Point(361, 103);
            this.btnExel.Name = "btnExel";
            this.btnExel.Size = new System.Drawing.Size(126, 36);
            this.btnExel.TabIndex = 16;
            this.btnExel.Text = "Export To Excel";
            this.btnExel.UseVisualStyleBackColor = true;
            this.btnExel.Click += new System.EventHandler(this.btnExel_Click);
            // 
            // pnlbulk
            // 
            this.pnlbulk.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlbulk.Controls.Add(this.btnBrowse);
            this.pnlbulk.Controls.Add(this.textBrowse);
            this.pnlbulk.Controls.Add(this.label2);
            this.pnlbulk.Controls.Add(this.rbtnAppno);
            this.pnlbulk.Controls.Add(this.rbtnLoanno);
            this.pnlbulk.Location = new System.Drawing.Point(381, 26);
            this.pnlbulk.Name = "pnlbulk";
            this.pnlbulk.Size = new System.Drawing.Size(374, 73);
            this.pnlbulk.TabIndex = 15;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(291, 38);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(60, 23);
            this.btnBrowse.TabIndex = 7;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // textBrowse
            // 
            this.textBrowse.Location = new System.Drawing.Point(140, 39);
            this.textBrowse.Name = "textBrowse";
            this.textBrowse.Size = new System.Drawing.Size(146, 20);
            this.textBrowse.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(35, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select Excel File";
            // 
            // rbtnAppno
            // 
            this.rbtnAppno.AutoSize = true;
            this.rbtnAppno.Location = new System.Drawing.Point(140, 16);
            this.rbtnAppno.Name = "rbtnAppno";
            this.rbtnAppno.Size = new System.Drawing.Size(97, 17);
            this.rbtnAppno.TabIndex = 1;
            this.rbtnAppno.TabStop = true;
            this.rbtnAppno.Text = "Application No.";
            this.rbtnAppno.UseVisualStyleBackColor = true;
            // 
            // rbtnLoanno
            // 
            this.rbtnLoanno.AutoSize = true;
            this.rbtnLoanno.Location = new System.Drawing.Point(30, 16);
            this.rbtnLoanno.Name = "rbtnLoanno";
            this.rbtnLoanno.Size = new System.Drawing.Size(93, 17);
            this.rbtnLoanno.TabIndex = 0;
            this.rbtnLoanno.TabStop = true;
            this.rbtnLoanno.Text = "Card/Loan No";
            this.rbtnLoanno.UseVisualStyleBackColor = true;
            // 
            // btnRecords
            // 
            this.btnRecords.Location = new System.Drawing.Point(222, 105);
            this.btnRecords.Name = "btnRecords";
            this.btnRecords.Size = new System.Drawing.Size(133, 34);
            this.btnRecords.TabIndex = 14;
            this.btnRecords.Text = "Find Records";
            this.btnRecords.UseVisualStyleBackColor = true;
            this.btnRecords.Click += new System.EventHandler(this.btnRecords_Click);
            // 
            // Pnlsingle
            // 
            this.Pnlsingle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Pnlsingle.Controls.Add(this.textAppno);
            this.Pnlsingle.Controls.Add(this.label3);
            this.Pnlsingle.Controls.Add(this.txtLoanno);
            this.Pnlsingle.Controls.Add(this.label1);
            this.Pnlsingle.Location = new System.Drawing.Point(12, 26);
            this.Pnlsingle.Name = "Pnlsingle";
            this.Pnlsingle.Size = new System.Drawing.Size(343, 73);
            this.Pnlsingle.TabIndex = 13;
            // 
            // textAppno
            // 
            this.textAppno.Location = new System.Drawing.Point(104, 40);
            this.textAppno.Name = "textAppno";
            this.textAppno.Size = new System.Drawing.Size(146, 20);
            this.textAppno.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Application No.";
            // 
            // txtLoanno
            // 
            this.txtLoanno.Location = new System.Drawing.Point(104, 11);
            this.txtLoanno.Name = "txtLoanno";
            this.txtLoanno.Size = new System.Drawing.Size(146, 20);
            this.txtLoanno.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Loan / Card No";
            // 
            // rbtnBulkSearch
            // 
            this.rbtnBulkSearch.AutoSize = true;
            this.rbtnBulkSearch.Location = new System.Drawing.Point(140, 2);
            this.rbtnBulkSearch.Name = "rbtnBulkSearch";
            this.rbtnBulkSearch.Size = new System.Drawing.Size(86, 17);
            this.rbtnBulkSearch.TabIndex = 12;
            this.rbtnBulkSearch.TabStop = true;
            this.rbtnBulkSearch.Text = "Bulk Search ";
            this.rbtnBulkSearch.UseVisualStyleBackColor = true;
            this.rbtnBulkSearch.CheckedChanged += new System.EventHandler(this.rbtnBulkSearch_CheckedChanged);
            // 
            // rbtnSingleSearch
            // 
            this.rbtnSingleSearch.AutoSize = true;
            this.rbtnSingleSearch.Location = new System.Drawing.Point(26, 3);
            this.rbtnSingleSearch.Name = "rbtnSingleSearch";
            this.rbtnSingleSearch.Size = new System.Drawing.Size(91, 17);
            this.rbtnSingleSearch.TabIndex = 11;
            this.rbtnSingleSearch.TabStop = true;
            this.rbtnSingleSearch.Text = "Single Search";
            this.rbtnSingleSearch.UseVisualStyleBackColor = true;
            this.rbtnSingleSearch.CheckedChanged += new System.EventHandler(this.rbtnSingleSearch_CheckedChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(15, 181);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(756, 220);
            this.dataGridView1.TabIndex = 20;
            // 
            // ofdbox
            // 
            this.ofdbox.FileName = "openFileDialog1";
            // 
            // frmQuickSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 425);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Name = "frmQuickSearch";
            this.Text = "frmQuickSearch";
            this.Load += new System.EventHandler(this.frmQuickSearch_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlbulk.ResumeLayout(false);
            this.pnlbulk.PerformLayout();
            this.Pnlsingle.ResumeLayout(false);
            this.Pnlsingle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnExel;
        private System.Windows.Forms.Panel pnlbulk;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox textBrowse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbtnAppno;
        private System.Windows.Forms.RadioButton rbtnLoanno;
        private System.Windows.Forms.Button btnRecords;
        private System.Windows.Forms.Panel Pnlsingle;
        private System.Windows.Forms.TextBox textAppno;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLoanno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbtnBulkSearch;
        private System.Windows.Forms.RadioButton rbtnSingleSearch;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.OpenFileDialog ofdbox;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}