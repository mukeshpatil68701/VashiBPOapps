﻿namespace LPO_Dev
{
    partial class frmoneClickRtoDispatchMis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbtuploadMIS = new System.Windows.Forms.RadioButton();
            this.rbtRtoMIS = new System.Windows.Forms.RadioButton();
            this.btnMIS = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.frmDT = new System.Windows.Forms.DateTimePicker();
            this.ToDT = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // rbtuploadMIS
            // 
            this.rbtuploadMIS.AutoSize = true;
            this.rbtuploadMIS.Location = new System.Drawing.Point(203, 29);
            this.rbtuploadMIS.Name = "rbtuploadMIS";
            this.rbtuploadMIS.Size = new System.Drawing.Size(89, 17);
            this.rbtuploadMIS.TabIndex = 43;
            this.rbtuploadMIS.TabStop = true;
            this.rbtuploadMIS.Text = "Dispatch MIS";
            this.rbtuploadMIS.UseVisualStyleBackColor = true;
            // 
            // rbtRtoMIS
            // 
            this.rbtRtoMIS.AutoSize = true;
            this.rbtRtoMIS.Location = new System.Drawing.Point(312, 29);
            this.rbtRtoMIS.Name = "rbtRtoMIS";
            this.rbtRtoMIS.Size = new System.Drawing.Size(70, 17);
            this.rbtRtoMIS.TabIndex = 44;
            this.rbtRtoMIS.TabStop = true;
            this.rbtRtoMIS.Text = "RTO MIS";
            this.rbtRtoMIS.UseVisualStyleBackColor = true;
            // 
            // btnMIS
            // 
            this.btnMIS.Location = new System.Drawing.Point(211, 154);
            this.btnMIS.Name = "btnMIS";
            this.btnMIS.Size = new System.Drawing.Size(75, 23);
            this.btnMIS.TabIndex = 33;
            this.btnMIS.Text = "&Generate Report";
            this.btnMIS.UseVisualStyleBackColor = true;
            this.btnMIS.Click += new System.EventHandler(this.btnMIS_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(294, 154);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 34;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(104, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 35;
            this.label1.Text = "From Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(326, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 13);
            this.label3.TabIndex = 41;
            this.label3.Text = "To Date";
            // 
            // frmDT
            // 
            this.frmDT.Location = new System.Drawing.Point(166, 99);
            this.frmDT.Name = "frmDT";
            this.frmDT.Size = new System.Drawing.Size(131, 20);
            this.frmDT.TabIndex = 45;
            // 
            // ToDT
            // 
            this.ToDT.Location = new System.Drawing.Point(378, 99);
            this.ToDT.Name = "ToDT";
            this.ToDT.Size = new System.Drawing.Size(131, 20);
            this.ToDT.TabIndex = 46;
            // 
            // frmoneClickRtoDispatchMis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 256);
            this.Controls.Add(this.ToDT);
            this.Controls.Add(this.frmDT);
            this.Controls.Add(this.rbtRtoMIS);
            this.Controls.Add(this.rbtuploadMIS);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnMIS);
            this.Name = "frmoneClickRtoDispatchMis";
            this.Text = "frmRtoPodMis";
            this.Load += new System.EventHandler(this.frmRtoPodMis_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RadioButton rbtuploadMIS;
        private System.Windows.Forms.RadioButton rbtRtoMIS;
        private System.Windows.Forms.Button btnMIS;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker frmDT;
        private System.Windows.Forms.DateTimePicker ToDT;
    }
}