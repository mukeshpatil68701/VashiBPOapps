﻿using CrystalDecisions.Shared;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    public partial class frmInward : Form
    {
        string LivePath = string.Empty;
        string RTOLivePath = string.Empty;
        string PODLivepath = string.Empty;
        string MasterID = string.Empty;
        string ApplicantName = string.Empty;
        string LANNo = string.Empty;
        string ImageNameMI = string.Empty;
        DBHelper objdbhelper = new DBHelper();
        DataTable dt = new DataTable();
        ArrayList alImg = new ArrayList();
        ArrayList alExcel = new ArrayList();
        ArrayList alExcelR = new ArrayList();
        ArrayList alImgOdd = new ArrayList();
        ArrayList alImgEven = new ArrayList();
        public frmInward()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            filebrowserdialogue.ShowDialog();
            txtInwardImagePath.Text = filebrowserdialogue.SelectedPath;
        }

        private void btnGenStat_Click(object sender, EventArgs e)
        {
            bool bCon = false;
            bCon = PGlobalclass.Connect();

            if (bCon)
            {
                if (RbtNew.Checked == true)
                {

                    int i = 0;

                    OleDbConnection my_con = new OleDbConnection();

                    if (Path.GetExtension(txtInwardExcelPath.Text) == ".xls")
                        my_con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + txtInwardExcelPath.Text + ";Extended Properties=Excel 8.0;Persist Security Info=False";
                    else if (Path.GetExtension(txtInwardExcelPath.Text) == ".xlsx")
                        my_con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + txtInwardExcelPath.Text + ";Extended Properties=Excel 8.0;Persist Security Info=False";


                    //OleDbCommand o_cmd = new OleDbCommand("select number from [Sheet1$] where  number NOT LIKE '' ", my_con);
                    //OleDbDataAdapter da = new OleDbDataAdapter();
                    OleDbCommand o_cmd = new OleDbCommand("select * from [Sheet1$] ", my_con);
                    OleDbDataAdapter da = new OleDbDataAdapter();

                    da.SelectCommand = o_cmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    int result = ds.Tables[0].Rows.Count;
                    string alexcelString = string.Empty;

                    for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                    {

                        alexcelString += "'" + (ds.Tables[0].Rows[j][0].ToString()) + "'" + ",";
                        alExcel.Add(ds.Tables[0].Rows[j][0].ToString());
                    }

                    alexcelString = alexcelString.Remove(alexcelString.LastIndexOf(","));

                    DirectoryInfo d = new DirectoryInfo(txtInwardImagePath.Text);
                    FileInfo[] Files = d.GetFiles("*.TIF");
                    int fileCount = Directory.GetFiles(txtInwardImagePath.Text, "*.TIF").Length;
                    i = 0;
                    foreach (FileInfo file1 in Files)
                    {
                        string folderImageName = string.Empty;
                        folderImageName = Convert.ToString(file1).Trim();

                        alImg.Add(file1.Name);

                        i++;
                    }

                    if (rbtRTO.Checked == true)
                    {
                        if (result * 2 == fileCount)
                        {

                            string strQc1 = "select distinct(VU_MasterID) from lpo_trnsuccess where VU_RTO_POD_Inword_No in (" + alexcelString + ") and Vu_TemplateName='" + cmbTemplate.Text + "' ";
                            dt = PGlobalclass.GetData(strQc1);
                            if (dt.Rows.Count == result)
                            {
                                string strQc12 = "truncate lpo_image_inward";
                                dt = PGlobalclass.GetData(strQc12);


                                Hashtable htMapodd = new Hashtable();

                                for (int P = 0; P < alImg.Count; P += 2)
                                {
                                    alImgOdd.Add(alImg[P].ToString());
                                }

                                Hashtable htMapEven = new Hashtable();

                                for (int P = 1; P < alImg.Count; P += 2)
                                {
                                    alImgEven.Add(alImg[P].ToString());
                                }

                                Hashtable htMap = new Hashtable();

                                for (int P = 0; P < alImg.Count / 2; P++)

                                {
                                    string path = (txtInwardImagePath.Text.ToString() + "\\" + alImgOdd[P]);

                                    pictureBox1.ImageLocation = (path);
                                    pictureBox1.Dock = DockStyle.Fill;
                                    Image Imgpath1 = new Bitmap(path);
                                    //Imgpath1.RotateFlip(RotateFlipType.Rotate270FlipXY);
                                    Imgpath1.RotateFlip(RotateFlipType.Rotate180FlipXY);
                                    pictureBox1.Image = Imgpath1;
                                    string path2 = (txtInwardImagePath.Text.ToString() + "\\" + alImgEven[P]);
                                    ClsProperty.ImgPath1 = pictureBox1.Image;
                                    pictureBox2.ImageLocation = (path2);
                                    pictureBox2.Dock = DockStyle.Fill;
                                    Image imgPath2 = new Bitmap(path2);
                                    imgPath2.RotateFlip(RotateFlipType.RotateNoneFlipNone);
                                    pictureBox2.Image = imgPath2;
                                    ClsProperty.ImgPath2 = pictureBox2.Image;
                                    Image Merge = MergeTwoImages(ClsProperty.ImgPath1, ClsProperty.ImgPath2);

                                    DataTable dt = new DataTable();
                                    string strQc = "select distinct(VU_MasterID),VU_ApplicantName,VU_LANNo from lpo_trnsuccess where VU_RTO_POD_Inword_No='" + alExcel[P] + "'and Vu_TemplateName='" + cmbTemplate.Text + "'";
                                    dt = PGlobalclass.GetData(strQc);
                                    MasterID = dt.Rows[0]["VU_MasterID"].ToString();
                                    ApplicantName = dt.Rows[0]["VU_ApplicantName"].ToString();
                                    LANNo = dt.Rows[0]["VU_LANNo"].ToString();
                                    ImageNameMI = MasterID + ".TIF";

                                    string destinationPath = PGlobalclass.strRTOPath + MasterID + ".TIF";

                                    Merge.Save(destinationPath);


                                    string excelpath = txtInwardExcelPath.Text.Replace("\\", "\\\\").Trim();
                                    string serverPath = PGlobalclass.strRTOPath + ImageNameMI;

                                    //CultureInfo ci = new CultureInfo("en-US");
                                    //var month = DateTime.Now.ToString("MMMM", ci);

                                    //string path = @"C:\MIS\Inward\POD\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");

                                    //if (!Directory.Exists(path))
                                    //{
                                    //    Directory.CreateDirectory(path);
                                    //}

                                    string StrSqlInsert = ("Insert into lpo_image_inward(VU_Inwardno,VU_Inward_MasterID,VU_inward_OldImagename1,VU_inward_OldImagename2,VU_inward_NewImageName,VU_inward_TemplateName,VU_inward_image_serverPath,VU_inward_image_Date,VU_inward_image_Excelpath,VU_inward_IS_POD_RTO,VU_inward_ApplicantName,VU_inward_LANNo)values('" + alExcel[P] + "','" + MasterID + "','" + alImgOdd[P] + "','" + alImgEven[P] + "','" + ImageNameMI + "','" + cmbTemplate.Text + "','" + serverPath + "','" + DateTime.Now.ToShortDateString() + "','" + excelpath + "','RTO','" + ApplicantName + "','" + LANNo + "' )");
                                    bool Insert = clsMain.ExcuteDML(StrSqlInsert);

                                }

                                MessageBox.Show("RTO inward Done Successfully");
                            }
                            else
                            {
                                MessageBox.Show("Invalid Inward number in Excel File");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Inward number count Not Match with image count");
                        }
                    }

                    //

                    if (rbtpod.Checked == true)
                    {
                        if (result == fileCount)
                        {

                            DataTable dt1 = new DataTable();
                            string strQc1 = "select distinct(VU_MasterID) from lpo_trnsuccess where VU_RTO_POD_Inword_No in (" + alexcelString + ") and Vu_TemplateName='" + cmbTemplate.Text + "'";
                            dt1 = PGlobalclass.GetData(strQc1);
                            if (dt1.Rows.Count == result)
                            {
                                string strQc12 = "truncate lpo_image_inward";
                                dt = PGlobalclass.GetData(strQc12);

                                Hashtable htMap = new Hashtable();
                                int iCnt = 0;
                                foreach (string str in alImg)
                                {

                                    if (!htMap.Contains(str))
                                    {

                                        string strQc = "select distinct(VU_MasterID),VU_ApplicantName,VU_LANNo from lpo_trnsuccess where VU_RTO_POD_Inword_No='" + alExcel[iCnt] + "' and Vu_TemplateName='" + cmbTemplate.Text + "'";
                                        dt = PGlobalclass.GetData(strQc);
                                        MasterID = dt.Rows[0]["VU_MasterID"].ToString();
                                        ApplicantName = dt.Rows[0]["VU_ApplicantName"].ToString();
                                        LANNo = dt.Rows[0]["VU_LANNo"].ToString();

                                        string path = PGlobalclass.strPODPath + "\\" + MasterID + ".TIF";
                                        string srPath = txtInwardImagePath.Text + "\\" + alImg[iCnt].ToString();

                                        if (File.Exists(path))
                                        {
                                            //   MessageBox.Show("indexing already Done ");
                                        }
                                        else
                                        {
                                            File.Copy(srPath, path);
                                        }


                                        htMap.Add(str, alExcel[iCnt].ToString());

                                        string newimagename = alExcel[iCnt].ToString() + ".TIF";

                                        string excelpath = txtInwardExcelPath.Text.Replace("\\", "\\\\").Trim();
                                        ImageNameMI = MasterID + ".TIF";
                                        string serverPath = PGlobalclass.strPODPath + ImageNameMI;

                                        string StrSqlInsert = ("Insert into lpo_image_inward(VU_Inwardno,VU_Inward_MasterID,VU_inward_OldImagename1, "
                                            + " VU_inward_OldImagename2,VU_inward_NewImageName,VU_inward_TemplateName,VU_inward_image_serverPath,VU_inward_image_Date,VU_inward_image_Excelpath,"
                                            + " VU_inward_IS_POD_RTO,VU_Inward_ApplicantName,VU_Inward_LANNo)values('" + alExcel[iCnt] + "','" + MasterID + "','" + alImg[iCnt].ToString() + "','',"
                                            + " '" + newimagename + "','" + cmbTemplate.Text + "','" + serverPath + "','" + DateTime.Now.ToShortDateString() + "','" + excelpath + "','POD','" + ApplicantName + "','" + LANNo + "' )");
                                        bool Insert = clsMain.ExcuteDML(StrSqlInsert);
                                    }
                                    iCnt++;
                                }

                                MessageBox.Show("POD inward Done Successfully");

                            }
                            else
                            {
                                MessageBox.Show("Invalid Inward number in Excel File");
                            }
                        }


                        else
                        {
                            MessageBox.Show("Inward number count Not Match with image count");
                        }
                    }
                }

                if(Rbtold.Checked== true)
                {
                    int i = 0;

              

                    OleDbConnection my_con = new OleDbConnection();

                    if (Path.GetExtension(txtInwardExcelPath.Text) == ".xls")
                        my_con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + txtInwardExcelPath.Text + ";Extended Properties=Excel 8.0;Persist Security Info=False";
                    else if (Path.GetExtension(txtInwardExcelPath.Text) == ".xlsx")
                        my_con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + txtInwardExcelPath.Text + ";Extended Properties=Excel 8.0;Persist Security Info=False";


                    //OleDbCommand o_cmd = new OleDbCommand("select number from [Sheet1$] where  number NOT LIKE '' ", my_con);
                    //OleDbDataAdapter da = new OleDbDataAdapter();
                    OleDbCommand o_cmd = new OleDbCommand("select * from [Sheet1$] ", my_con);
                    OleDbDataAdapter da = new OleDbDataAdapter();

                    da.SelectCommand = o_cmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    int result = ds.Tables[0].Rows.Count;
                    string alexcelString = string.Empty;

                    for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                    {

                        alexcelString += "'" + (ds.Tables[0].Rows[j][0].ToString()) + "'" + ",";
                        alExcel.Add(ds.Tables[0].Rows[j][0].ToString());
                    }

                    alexcelString = alexcelString.Remove(alexcelString.LastIndexOf(","));

                    DirectoryInfo d = new DirectoryInfo(txtInwardImagePath.Text);
                    FileInfo[] Files = d.GetFiles("*.TIF");
                    int fileCount = Directory.GetFiles(txtInwardImagePath.Text, "*.TIF").Length;
                    i = 0;
                    foreach (FileInfo file1 in Files)
                    {
                        string folderImageName = string.Empty;
                        folderImageName = Convert.ToString(file1).Trim();

                        alImg.Add(file1.Name);

                        i++;
                    }

                    if (rbtRTO.Checked == true)
                    {
                        if (result * 2 == fileCount)
                        {
                            //  dt = objdbhelper.Select("call SP_InwardRTOPOD ('" + cmbTemplate.Text.ToUpper() + "','RTO','" + strlanno + "','')", CommandType.StoredProcedure);

                            string strQc1 = "select distinct(Appno) from llap.upload_details where REGISTRATION_NO in (" + alexcelString + ")  ";
                            dt = PGlobalclass.GetData(strQc1);
                            if (dt.Rows.Count == result)
                            {
                                string strQc12 = "truncate lpo_image_inward";
                                dt = PGlobalclass.GetData(strQc12);


                                Hashtable htMapodd = new Hashtable();

                                for (int P = 0; P < alImg.Count; P += 2)
                                {
                                    alImgOdd.Add(alImg[P].ToString());
                                }

                                Hashtable htMapEven = new Hashtable();

                                for (int P = 1; P < alImg.Count; P += 2)
                                {
                                    alImgEven.Add(alImg[P].ToString());
                                }

                                Hashtable htMap = new Hashtable();

                                for (int P = 0; P < alImg.Count / 2; P++)

                                {
                                    string path = (txtInwardImagePath.Text.ToString() + "\\" + alImgOdd[P]);

                                    pictureBox1.ImageLocation = (path);
                                    pictureBox1.Dock = DockStyle.Fill;
                                    Image Imgpath1 = new Bitmap(path);
                                    Imgpath1.RotateFlip(RotateFlipType.Rotate180FlipXY );
                                    pictureBox1.Image = Imgpath1;
                                    string path2 = (txtInwardImagePath.Text.ToString() + "\\" + alImgEven[P]);
                                    ClsProperty.ImgPath1 = pictureBox1.Image;
                                    pictureBox2.ImageLocation = (path2);
                                    pictureBox2.Dock = DockStyle.Fill;
                                    Image imgPath2 = new Bitmap(path2);
                                    imgPath2.RotateFlip(RotateFlipType.RotateNoneFlipNone      );
                                    pictureBox2.Image = imgPath2;
                                    ClsProperty.ImgPath2 = pictureBox2.Image;
                                    Image Merge = MergeTwoImages(ClsProperty.ImgPath1, ClsProperty.ImgPath2);

                                    DataTable dt = new DataTable();
                                    string strQc = "select distinct(Appno),Loan_Card_No from llap.upload_details where REGISTRATION_NO='" + alExcel[P] + "'";
                                    dt = PGlobalclass.GetData(strQc);

                                    //   dt = objdbhelper.Select("call SP_InwardRTOPOD ('" + cmbTemplate.Text.ToUpper() + "','RTO','" + alExcel[P] + "')", CommandType.StoredProcedure);

                                    MasterID = dt.Rows[0]["Appno"].ToString();
                                    //ApplicantName = dt.Rows[0]["VU_ApplicantName"].ToString();
                                    LANNo = dt.Rows[0]["Loan_Card_No"].ToString();
                                    ImageNameMI = MasterID + ".TIF";

                                    string destinationPath = PGlobalclass.strRTOPath + MasterID + ".TIF";

                                    Merge.Save(destinationPath);


                                    string excelpath = txtInwardExcelPath.Text.Replace("\\", "\\\\").Trim();
                                    string serverPath = PGlobalclass.strRTOPath + ImageNameMI;

                                    //CultureInfo ci = new CultureInfo("en-US");
                                    //var month = DateTime.Now.ToString("MMMM", ci);

                                    //string path = @"C:\MIS\Inward\POD\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");

                                    //if (!Directory.Exists(path))
                                    //{
                                    //    Directory.CreateDirectory(path);
                                    //}

                                    string StrSqlInsert = ("Insert into lpo_image_inward(VU_Inwardno,VU_Inward_MasterID,VU_inward_OldImagename1,VU_inward_OldImagename2,VU_inward_NewImageName,VU_inward_TemplateName,VU_inward_image_serverPath,VU_inward_image_Date,VU_inward_image_Excelpath,VU_inward_IS_POD_RTO,VU_inward_ApplicantName,VU_inward_LANNo)values('" + alExcel[P] + "','" + MasterID + "','" + alImgOdd[P] + "','" + alImgEven[P] + "','" + ImageNameMI + "','" + cmbTemplate.Text + "','" + serverPath + "','" + DateTime.Now.ToShortDateString() + "','" + excelpath + "','RTO',' ','" + LANNo + "' )");
                                    bool Insert = clsMain.ExcuteDML(StrSqlInsert);

                                }

                                MessageBox.Show("RTO inward Done Successfully");
                            }
                            else
                            {
                                MessageBox.Show("Invalid Inward number in Excel File");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Inward number count Not Match with image count");
                        }
                    }

                    //

                    if (rbtpod.Checked == true)
                    {
                        if (result == fileCount)
                        {

                            DataTable dt1 = new DataTable();
                            string strQc1 = "select distinct(Appno) from llap.upload_details where REGISTRATION_NO in (" + alexcelString + ") ";
                            dt1 = PGlobalclass.GetData(strQc1);
                            if (dt1.Rows.Count == result)
                            {
                                string strQc12 = "truncate lpo_image_inward";
                                dt = PGlobalclass.GetData(strQc12);

                                Hashtable htMap = new Hashtable();
                                int iCnt = 0;
                                foreach (string str in alImg)
                                {

                                    if (!htMap.Contains(str))
                                    {

                                        string strQc = "select distinct(Appno),Loan_Card_No from llap.upload_details where REGISTRATION_NO='" + alExcel[iCnt] + "'";
                                        dt = PGlobalclass.GetData(strQc);
                                        MasterID = dt.Rows[0]["Appno"].ToString();
                                      //  ApplicantName = dt.Rows[0]["VU_ApplicantName"].ToString();
                                        LANNo = dt.Rows[0]["Loan_Card_No"].ToString();

                                        string path = PGlobalclass.strPODPath + "\\" + MasterID + ".TIF";
                                        string srPath = txtInwardImagePath.Text + "\\" + alImg[iCnt].ToString();

                                        if (File.Exists(path))
                                        {
                                            //   MessageBox.Show("indexing already Done ");
                                        }
                                        else
                                        {
                                            File.Copy(srPath, path);
                                        }


                                        htMap.Add(str, alExcel[iCnt].ToString());

                                        string newimagename = alExcel[iCnt].ToString() + ".TIF";

                                        string excelpath = txtInwardExcelPath.Text.Replace("\\", "\\\\").Trim();
                                        ImageNameMI = MasterID + ".TIF";
                                        string serverPath = PGlobalclass.strPODPath + ImageNameMI;

                                        string StrSqlInsert = ("Insert into lpo_image_inward(VU_Inwardno,VU_Inward_MasterID,VU_inward_OldImagename1, "
                                            + " VU_inward_OldImagename2,VU_inward_NewImageName,VU_inward_TemplateName,VU_inward_image_serverPath,VU_inward_image_Date,VU_inward_image_Excelpath,"
                                            + " VU_inward_IS_POD_RTO,VU_Inward_ApplicantName,VU_Inward_LANNo)values('" + alExcel[iCnt] + "','" + MasterID + "','" + alImg[iCnt].ToString() + "','',"
                                            + " '" + newimagename + "','" + cmbTemplate.Text + "','" + serverPath + "','" + DateTime.Now.ToShortDateString() + "','" + excelpath + "','POD',' ','" + LANNo + "' )");
                                        bool Insert = clsMain.ExcuteDML(StrSqlInsert);
                                    }
                                    iCnt++;
                                }

                                MessageBox.Show("POD inward Done Successfully");

                            }
                            else
                            {
                                MessageBox.Show("Invalid Inward number in Excel File");
                            }
                        }


                        else
                        {
                            MessageBox.Show("Inward number count Not Match with image count");
                        }
                    }



                }


            }
            
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }

        private void bulkRename(string fPath, string fNewName)
        {
            string fExt;
            string fFromName;
            string fToName;
            int i = 1;

         
            FileInfo[] files = new DirectoryInfo(fPath).GetFiles();
      
            foreach (var f in files)
            {

                fFromName = Path.GetFileNameWithoutExtension(f.Name);
           
                fExt = Path.GetExtension(f.Name);

                fFromName = string.Format("{0}{1}", fPath, f.Name);
           
                fToName = string.Format("{0}{1}", fPath, f.Name);
            
                File.Move(fFromName, fToName);
         
                i++;
            }
        }

        public static Bitmap MergeTwoImages(Image firstImage, Image secondImage)
        {
            if (firstImage == null)
            {
                throw new ArgumentNullException("firstImage");
            }

            if (secondImage == null)
            {
                throw new ArgumentNullException("secondImage");
            }

            int outputImageWidth = firstImage.Width > secondImage.Width ? firstImage.Width : secondImage.Width;

            int outputImageHeight = firstImage.Height + secondImage.Height + 1;

            // Bitmap outputImage = new Bitmap(outputImageWidth, outputImageHeight, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

            Bitmap outputImage = new Bitmap(outputImageWidth, outputImageHeight, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

            using (Graphics graphics = Graphics.FromImage(outputImage))
            {
                graphics.DrawImage(firstImage, new Rectangle(new Point(), firstImage.Size),
                    new Rectangle(new Point(), firstImage.Size), GraphicsUnit.Pixel);
                graphics.DrawImage(secondImage, new Rectangle(new Point(0, firstImage.Height + 1), secondImage.Size),
                    new Rectangle(new Point(), secondImage.Size), GraphicsUnit.Pixel);
            }

            return outputImage;
            
        }

        private void frmInward_Load(object sender, EventArgs e)
        {
            bool bCon = false;
            bCon = PGlobalclass.Connect();
            if (bCon)
            {
                //if (RbtNew.Checked == true)
                //{
                    PGlobalclass.cmbFillInward(this);
              //  }
              //  else if (Rbtold.Checked== true)
              //  {
                  //  PGlobalclass.cmbFillInwardOLD(this);
             //   }
                //dt = clsMain.GetData("select vu_Live_path from lpo_serverpath;");

                //LivePath  = dt.Rows[0]["vu_Live_path"].ToString();

                //RTOLivePath = LivePath + "\\vara_dev_bpo\\Inward\\RTO" + "\\";
                if (!Directory.Exists(PGlobalclass.strRTOPath ))
                {
                    Directory.CreateDirectory(PGlobalclass.strRTOPath);
                }
                //PODLivepath = LivePath + "\\vara_dev_bpo\\Inward\\POD" + "\\";
                if (!Directory.Exists(PODLivepath))
                {
                    Directory.CreateDirectory(PGlobalclass.strPODPath);
                }

            }
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openfileExel.FileName = "*.xls";
            openfileExel.Filter = "*.xls|xls Files";
            openfileExel.Title = "Select xls File to Upload";
            openfileExel.ShowDialog();
            txtInwardExcelPath.Text = openfileExel.FileName;
        }

        private void BtnMIS_Click(object sender, EventArgs e)
        {
            bool bCon = false;
            bCon = ClsCaseMIS.Connect();
            if (bCon)
            {
                if (rbtpod.Checked == true)
                {
                    PGlobalclass.GenerateInwardPOD(this, cmbTemplate.Text.ToString());             
                }
                else if (rbtRTO.Checked== true)
                {
                    PGlobalclass.GenerateInwardRTO(this, cmbTemplate.Text.ToString());
                    MessageBox.Show(" MIS Exported Successfully ");
                }
            }
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {     

        }

        private void btnupload_Click(object sender, EventArgs e)
        {
          
            int i = 0;

            OleDbConnection my_con = new OleDbConnection();

            if (Path.GetExtension(txtInwardExcelPath.Text) == ".xls")
                my_con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + txtInwardExcelPath.Text + ";Extended Properties=Excel 8.0;Persist Security Info=False";
            else if (Path.GetExtension(txtInwardExcelPath.Text) == ".xlsx")
                my_con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + txtInwardExcelPath.Text + ";Extended Properties=Excel 8.0;Persist Security Info=False";


            //OleDbCommand o_cmd = new OleDbCommand("select number from [Sheet1$] where  number NOT LIKE '' ", my_con);
            OleDbCommand o_cmd = new OleDbCommand("select * from [Sheet1$] ", my_con);
            OleDbDataAdapter da = new OleDbDataAdapter();

            da.SelectCommand = o_cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);

            int result = ds.Tables[0].Rows.Count;
            string alexcelString = string.Empty;

            if (rbtRTO.Checked == true)
            {
              
                for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                {
                    string refno = (ds.Tables[0].Rows[j][0].ToString()) ;


                    string StrSqlupdate = " UPDATE lpo_trnsuccess t1, lpo_image_inward t2 "
                + "  SET t1.VU_inward_OldImagename1 = t2.VU_inward_OldImagename1, "
                + "  t1.VU_inward_OldImagename2 = t2.VU_inward_OldImagename2, "
                + "  t1.VU_inward_NewImageName = t2.VU_inward_NewImageName, "
                + "  t1.VU_inward_image_serverPath = t2.VU_inward_image_serverPath, "
                + "  t1.VU_inward_image_Date = t2.VU_inward_image_Date, "
                + "  t1.VU_inward_image_Excelpath = t2.VU_inward_image_Excelpath, "
                + "  t1.VU_inward_IS_POD_RTO = t2.VU_inward_IS_POD_RTO "
                + "  WHERE t1.VU_RTO_POD_Inword_No = '" + refno + "' and t2.VU_Inwardno ='" + refno + "' and "
                + " t1.VU_TemplateName ='"+ cmbTemplate.Text +"' and  t2.VU_inward_TemplateName='" + cmbTemplate.Text + "' and t2.VU_Inward_IS_POD_RTO='RTO'" ;
                    bool Update = clsMain.ExcuteDML(StrSqlupdate);
                }

                string StrSqlInsert = ("Insert into lpo_image_inward_mis(select * from  lpo_image_inward)");
                bool Insert = clsMain.ExcuteDML(StrSqlInsert);

                MessageBox.Show("RTO File Uploaded successfully");
            }
            else if(rbtpod.Checked== true)
            {
                for (int j = 0; j < ds.Tables[0].Rows.Count; j++)
                {
                    string refno = (ds.Tables[0].Rows[j][0].ToString());


                    string StrSqlupdate = " UPDATE lpo_trnsuccess t1, lpo_image_inward t2 "
                + "  SET t1.VU_inward_OldImagename1 = t2.VU_inward_OldImagename1, "
                + "  t1.VU_inward_OldImagename2 = t2.VU_inward_OldImagename2, "
                + "  t1.VU_inward_NewImageName = t2.VU_inward_NewImageName, "
                + "  t1.VU_inward_image_serverPath = t2.VU_inward_image_serverPath, "
                + "  t1.VU_inward_image_Date = t2.VU_inward_image_Date, "
                + "  t1.VU_inward_image_Excelpath = t2.VU_inward_image_Excelpath, "
                + "  t1.VU_inward_IS_POD_RTO = t2.VU_inward_IS_POD_RTO "
                + "  WHERE t1.VU_RTO_POD_Inword_No = '" + refno + "' and t2.VU_Inwardno ='" + refno + "' and "
                + " t1.VU_TemplateName ='" + cmbTemplate.Text + "' and  t2.VU_inward_TemplateName='" + cmbTemplate.Text + "' and t2.VU_Inward_IS_POD_RTO='POD'";
                    bool Update = clsMain.ExcuteDML(StrSqlupdate);
                }

                string StrSqlInsert = ("Insert into lpo_image_inward_mis(select * from  lpo_image_inward)");
                bool Insert = clsMain.ExcuteDML(StrSqlInsert);

                MessageBox.Show("POD File Uploaded successfully");
            }
        }

        private void rbtRTO_CheckedChanged(object sender, EventArgs e)
        {         
            txtInwardImagePath.Text = "";
            txtInwardExcelPath.Text = "";
        }

        private void rbtpod_CheckedChanged(object sender, EventArgs e)
        {          
            txtInwardImagePath.Text = "";
            txtInwardExcelPath.Text = "";
        }

        private void Rbtold_CheckedChanged(object sender, EventArgs e)
        {
            lblTemplate.Visible = false;
          cmbTemplate.Visible = false;

         //   BtnMIS.Enabled = false;
            btnupload.Enabled = true  ;

           //if (Rbtold.Checked == true)
           // {
           //     PGlobalclass.cmbFillInwardOLD(this);
           // }
        }

        private void RbtNew_CheckedChanged(object sender, EventArgs e)
        {
            lblTemplate.Visible = true ;
          cmbTemplate.Visible = true;

         //   BtnMIS.Enabled = true ;
            btnupload.Enabled = true;
            //if (RbtNew.Checked == true)
            //{
            //    PGlobalclass.cmbFillInward(this);
            //}
            
        }
    }
}
