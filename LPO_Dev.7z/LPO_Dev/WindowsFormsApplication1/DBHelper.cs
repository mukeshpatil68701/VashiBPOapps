﻿using System.Data.Odbc;
using System.Configuration;
using System.Data;
using System;
using System.Windows.Forms;

namespace LPO_Dev
{
    public class DBHelper
    {
        public string connString = ConfigurationManager.ConnectionStrings["odbcConnection"].ConnectionString;
        OdbcConnection con;
        OdbcCommand cmd;
        OdbcDataAdapter adp;

        /// <summary>
        /// Use for insert, update and delete database activity.
        /// </summary>
        /// <param name="CommandText"></param>
        /// <param name="cmdType"></param>
        public void ExecuteNonQuery(string CommandText, CommandType cmdType)
        {
            try
            {
                using (con = new OdbcConnection(connString))
                {
                    cmd = new OdbcCommand { CommandType = cmdType, CommandText = CommandText, Connection = con };
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        /// <summary>
        /// Executes select command and return datatable.
        /// </summary>
        /// <param name="CommandText"></param>
        /// <param name="cmdType"></param>
        /// <returns></returns>
        public DataTable Select(string CommandText, CommandType cmdType)
        {
            DataTable dt = new DataTable();
            try
            {
                using (con = new OdbcConnection(connString))
                {
                    // con = new OdbcConnection(connString);
                    
                    cmd = new OdbcCommand { CommandType = cmdType, CommandText = CommandText, Connection = con };

                    con.Open();
                    adp = new OdbcDataAdapter(cmd);
                    cmd.CommandType = CommandType.StoredProcedure;
                    adp.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dt;
        }

        public DataTable SelectSP(string CommandText, CommandType cmdType)
        {
            DataTable dt = new DataTable();
            try
            {
                OdbcConnection sqlConnection1 = new OdbcConnection(connString);
                OdbcCommand cmd = new OdbcCommand();
                OdbcDataReader reader;

                cmd.CommandText = CommandText;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = sqlConnection1;

                sqlConnection1.Open();

                reader = cmd.ExecuteReader();
                // Data is accessible through the DataReader object here.

                sqlConnection1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return dt;
        }

        public bool ExcuteDML(string CommandText, CommandType cmdType)
        {
            try
            {
                using (con = new OdbcConnection(connString))
                {
                    
                    cmd = new OdbcCommand { CommandType = cmdType, CommandText = CommandText, Connection = con };
                    con.Open();
                    cmd.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }

        }
    }
}
