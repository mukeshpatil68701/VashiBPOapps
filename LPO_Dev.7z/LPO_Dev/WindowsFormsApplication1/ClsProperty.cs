﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace LPO_Dev
{
    public static class ClsProperty
    {
        public static string GroupID { get; set; }
        public static string UserName { get; set; }
        public static string Pwd { get; set; }
        public static string UserTypeID { get; set; }
        public static string Machine { get; set; }
        public static string IsFlag { get; set; }
        public static string ParentTag { get; set; }
        public static string ChildTag { get; set; }

        public static string UserID { get; set; }

        public static string SubMenuID { get; set; }
        public static string MenuID { get; set; }

        public static Image ImgPath1 { get; set; }
        public static Image ImgPath2 { get; set; }
    }
}
