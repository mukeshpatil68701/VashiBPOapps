﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection;

namespace LPO_Dev
{
    public partial class FrmDailyPrintMis : Form
    {
        public FrmDailyPrintMis()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmDailyPrintMis_Load(object sender, EventArgs e)
        {
            FrmdateTimePicker.Format = DateTimePickerFormat.Short;
            FrmdateTimePicker.Format = DateTimePickerFormat.Custom;
            FrmdateTimePicker.CustomFormat = "dd/MM/yyyy";
            TodateTimePicker.Format = DateTimePickerFormat.Short;
            TodateTimePicker.Format = DateTimePickerFormat.Custom;
            TodateTimePicker.CustomFormat = "dd/MM/yyyy";


            bool bConmis = false;
            bConmis = ClsDailyMis.Connect();

            if (bConmis)
            {
                ClsDailyMis.cmbFill(this);
            }
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool bCon = false;
            bCon = ClsDailyMis.Connect();
            if (bCon)
            {
                
                ClsDailyMis.ExpertToMisexcel(this, cmbtemplateName.Text.ToString(),FrmdateTimePicker.Text.ToString(),TodateTimePicker.Text.ToString());
               // MessageBox.Show(" MIS Exported Successfully ");
            }

            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
