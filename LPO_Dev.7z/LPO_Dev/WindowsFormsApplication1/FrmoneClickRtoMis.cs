﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    public partial class FrmoneClickRtoMis : Form
    {
        public FrmoneClickRtoMis()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btngenrate_Click(object sender, EventArgs e)
        {
            try
            {
                string fromdate = frmdatetimepicker.Value.ToString("dd/MM/yyyy");
                string todate = Todatetimepicker.Value.ToString("dd/MM/yyyy");
                DBHelper objdb = new DBHelper();
                ClsOneClickRtoMis.Connect();
                DataTable dttemp = new DataTable();
               // string template = "";
                //string qry = "select distinct TemplateName, TemplateID  from lpo_templatemaster order by TemplateID";
                //dttemp = ClsOneClickRtoMis.GetData(qry);

                if (rbnoticeprocess.Checked == true)
                {
                    
                            //template = dttemp.Rows[i]["TemplateName"].ToString();

                            // switch(template)
                            // {


                            if (rballfield.Checked == true)
                            {

                        // string str = "call sp_oneclickRtoMis ('NoticeRtoProcess','AllField' , '" + fromdate + " ' ,' " + todate + " '";
                           dttemp = objdb.Select("call sp_OneRtoMis ('NoticeRtoProcess','AllField' , '" + fromdate + " ' ,' " + todate + " ' )", CommandType.StoredProcedure);

                        //dttemp = objdb.Select("call aa()", CommandType.StoredProcedure);


                        ClsOneClickRtoMis.RtoMIsExcel(this, dttemp, "NoticeProcessWise", "AllFiled");
                                


                            }
                            else if (rbselectedfield.Checked == true)

                            {
                                dttemp = objdb.Select("call sp_OneRtoMis ('NoticeRtoProcess','SelectedField','" + fromdate + "' ,'" + todate + "' )", CommandType.StoredProcedure);
                                
                                
                                    ClsOneClickRtoMis.RtoMIsExcel(this, dttemp, "NoticeProcessWise", "SelectedField");
                                

                            }
                    

                }



                else if (rbrtopoddate.Checked == true)
                {


                    if (rballfield.Checked == true)
                    {
                        dttemp = objdb.Select("call sp_OneRtoMis ('RtoProcessWise','AllField','" + fromdate + "' ,'" + todate + "' )", CommandType.StoredProcedure);



                        ClsOneClickRtoMis.RtoMIsExcel(this, dttemp, "RtoProcessWise", "AllFiled");

                    }

                    else if (rbselectedfield.Checked == true)

                    {
                        dttemp = objdb.Select("call sp_OneRtoMis ('RtoProcessWise','SelectedField','" + fromdate + "' ,'" + todate + "' )", CommandType.StoredProcedure);


                        ClsOneClickRtoMis.RtoMIsExcel(this, dttemp, "RtoProcessWise", "SelectedField");

                    }

                 }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void FrmoneClickRtoMis_Load(object sender, EventArgs e)
        {
            rbrtopoddate.Checked = false;
            rbnoticeprocess.Checked = false;
            rballfield.Checked = false;
            rbselectedfield.Checked = false;

            frmdatetimepicker.Format = DateTimePickerFormat.Short;
            frmdatetimepicker.Format = DateTimePickerFormat.Custom;
            frmdatetimepicker.CustomFormat = "dd/MM/yyyy";
            Todatetimepicker.Format = DateTimePickerFormat.Short;
            Todatetimepicker.Format = DateTimePickerFormat.Custom;
            Todatetimepicker.CustomFormat = "dd/MM/yyyy";
        }
    }
}
