﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Odbc;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    static class D3Upload
    {
        static string StrFileName = string.Empty;
        static string StrInputFileName = string.Empty;
        static string strTemplateLocation = string.Empty;
        static string strUploadTbl = string.Empty;
        static string strUploadSuccess = string.Empty;
        static string strUploadFailed = string.Empty;
        static string strValidation = string.Empty;
        static string strTemplateName = string.Empty;
        static string strColumns = string.Empty;
        static string strDispatchMode = string.Empty;
        static string strAppstartID = string.Empty;
        static string strBatchID = string.Empty;
        public static Hashtable htGlbColTyp = new Hashtable();
        static int iRegNo = 0;
        internal static void ProcessD3(int iTempIndex, string txtPath, string strDispatchMode)
        {
            try
            {
                StrFileName = Path.GetFileName(txtPath);
                int iFieldCount = ClsGlobal.getExcelColcnt(iTempIndex);
                int iColCntfile = getFileColCount(txtPath);
                if (iFieldCount != iColCntfile)
                {
                    MessageBox.Show("Incorrect file format");
                    return;
                }

                StrInputFileName = txtPath;
                SetGlobalVars(iTempIndex);
                tempUpload(txtPath);
                updateBasicValidation(strDispatchMode);
                generateAppStart();
                if (strDispatchMode == "INLAND")
                {
                    DataTable dtUploadData = new DataTable();
                    string strUploadqry = "select ID," + strColumns + " from " + strUploadTbl + " where " + strValidation +
                        " Order by VU_AppPincode";
                    dtUploadData = ClsGlobal.GetData(strUploadqry);
                    uploadToSuccess(strDispatchMode, dtUploadData, iTempIndex);
                }

                if (strDispatchMode == "COURIER")
                {
                    DataTable dtUploadData = new DataTable();
                    string strUploadqry = "select ID," + strColumns + " from " + strUploadTbl + " where " + strValidation +
                        " And VU_DispatchMode = 'COURIER' Order by VU_AppPincode";
                    dtUploadData = ClsGlobal.GetData(strUploadqry);
                    if (dtUploadData.Rows.Count > 0)
                    {
                        uploadToSuccess(strDispatchMode, dtUploadData, iTempIndex);
                    }

                    dtUploadData = new DataTable();
                    strUploadqry = "select ID," + strColumns + " from " + strUploadTbl + " where " + strValidation +
                        " And VU_DispatchMode = 'INLAND' Order by VU_AppPincode";
                    if (dtUploadData.Rows.Count > 0)
                    {
                        dtUploadData = ClsGlobal.GetData(strUploadqry);
                        uploadToSuccess(strDispatchMode, dtUploadData, iTempIndex);
                    }

                }
                uploadToFailed();

                // int iSuccessCnt = 0;
                // iSuccessCnt = getSuccessCnt(strGlbUploadSuccess, strGlbFileName, strGlbTemplateName);

                string strUpdateRegNo = "update lpo_templatemaster set curRegNo = " + iRegNo.ToString() + " where TemplateId = " + iTempIndex.ToString();
                ClsGlobal.ExcuteDML(strUpdateRegNo);

                UpdateLogFile(StrFileName, strAppstartID, strBatchID, 0, strTemplateName);
                CreateFolderStructure(ClsGlobal.strGlbPath);
                MessageBox.Show("File Upload Successfully !!");

                reportGeneration(strDispatchMode);
                MessageBox.Show("Completed");
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + ex.Message);

            }

        }
        private static void CreateFolderStructure(string strGlbPath)
        {
            try
            {

                String strDt = DateTime.Now.ToString("dd MMM yyyy");
                string strOutputPath = strGlbPath + "\\" + strTemplateName + "\\" + strDt;
                string strInputFile = strGlbPath + "\\" + strTemplateName + "\\" + strDt + "\\" + "Input";

                //strGlbOutputPathBulk = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "BulkRegister";
                ClsGlobal.strGlbOutputPathReport = strGlbPath + "\\" + strTemplateName + "\\" + strDt + "\\" + "Report";
                //strGlbOutputPathSticker = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Sticker";


                if (!Directory.Exists(strInputFile))
                {
                    Directory.CreateDirectory(strInputFile);

                }
                File.Copy(StrInputFileName, strInputFile + "\\" + StrFileName + ".txt", true);
                if (!Directory.Exists(strOutputPath))
                {
                    Directory.CreateDirectory(strOutputPath);
                }

                if (!Directory.Exists(ClsGlobal.strGlbOutputPathReport))
                {
                    Directory.CreateDirectory(ClsGlobal.strGlbOutputPathReport);
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void reportGeneration(string strDispatchMode)
        {
            try
            {
                if (strDispatchMode == "INLAND")
                {
                    //with Hypothecation
                    string strInlandCondition = " where VU_FileName = '" + StrFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strTemplateName + "' and VU_DispatchMode = 'INLAND' and VU_LanNo REGEXP '^(AT|AV|BT|CA|CT|CU|DV|E7|EA|ES|HV|LA|" +
                                        "AA|LK|LT|LU|LV|LW|MV|SA|SU|TS|TT|UV|CV|RA|RT|SV)'";
                    string strInlandRptPath = strTemplateLocation + "CrRptD3InlandWH.rpt";

                    GenerateReport(strInlandCondition, ClsGlobal.strGlbOutputPathReport + "\\" + StrFileName + "_INLAND.pdf", strInlandRptPath);


                    string strSetPrintFlag = "Update  " + strUploadSuccess + " set VU_IsPrinted = 'Y' " + strInlandCondition;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);


                    //without Hypothecation
                    strInlandCondition = " where VU_FileName = '" + StrFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strTemplateName + "' and VU_DispatchMode = 'INLAND'";
                    strInlandRptPath = strTemplateLocation + "CrRptD3InlandH.rpt";

                    GenerateReport(strInlandCondition, ClsGlobal.strGlbOutputPathReport + "\\" + StrFileName + "_INLAND.pdf", strInlandRptPath);


                    strSetPrintFlag = "Update  " + strUploadSuccess + " set VU_IsPrinted = 'Y' " + strInlandCondition;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);

                }

                else if (strDispatchMode == "COURIER")
                {
                    //with  Inland Hypothecation
                    string strInlandCondition = " where VU_FileName = '" + StrFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strTemplateName + "' and VU_DispatchMode = 'INLAND' and VU_LanNo REGEXP '^(AT|AV|BT|CA|CT|CU|DV|E7|EA|ES|HV|LA|" +
                                        "AA|LK|LT|LU|LV|LW|MV|SA|SU|TS|TT|UV|CV|RA|RT|SV)'";


                    string strInlandRptPath = strTemplateLocation + "CrRptD3InlandWH.rpt";

                    GenerateReport(strInlandCondition, ClsGlobal.strGlbOutputPathReport + "\\" + StrFileName + "_INLAND_Hypothecation.pdf", strInlandRptPath);


                    string strSetPrintFlag = "Update  " + strUploadSuccess + " set VU_IsPrinted = 'Y' " + strInlandCondition;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);


                    //Inland without Hypothecation
                    strInlandCondition = " where VU_FileName = '" + StrFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strTemplateName + "' and VU_DispatchMode = 'INLAND'";
                    strInlandRptPath = strTemplateLocation + "CrRptD3InlandH.rpt";

                    GenerateReport(strInlandCondition, ClsGlobal.strGlbOutputPathReport + "\\" + StrFileName + "_INLAND.pdf", strInlandRptPath);

                    strSetPrintFlag = "Update  " + strUploadSuccess + " set VU_IsPrinted = 'Y' " + strInlandCondition;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);


                    //with Courier  Hypothecation

                    strInlandCondition = " where VU_FileName = '" + StrFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strTemplateName + "' and VU_DispatchMode = 'COURIER' and VU_LanNo REGEXP '^(AT|AV|BT|CA|CT|CU|DV|E7|EA|ES|HV|LA|" +
                                        "AA|LK|LT|LU|LV|LW|MV|SA|SU|TS|TT|UV|CV|RA|RT|SV)'";
                    strInlandRptPath = strTemplateLocation + "CrRptD3CourierWH.rpt";

                    GenerateReport(strInlandCondition, ClsGlobal.strGlbOutputPathReport + "\\" + StrFileName + "_COURIER_Hypothecation.pdf", strInlandRptPath);

                    strSetPrintFlag = "Update  " + strUploadSuccess + " set VU_IsPrinted = 'Y' " + strInlandCondition;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);


                    //Courier without Hypothecation
                    strInlandCondition = " where VU_FileName = '" + StrFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_IsPrinted = 'N' " +
                                        "and VU_TemplateName = '" + strTemplateName + "' and VU_DispatchMode = 'COURIER'";
                    strInlandRptPath = strTemplateLocation + "CrRptD3CourierH.rpt";

                    GenerateReport(strInlandCondition, ClsGlobal.strGlbOutputPathReport + "\\" + StrFileName + "_COURIER.pdf", strInlandRptPath);

                    strSetPrintFlag = "Update  " + strUploadSuccess + " set VU_IsPrinted = 'Y' " + strInlandCondition;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);

                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void GenerateReport(string strReportcond, string strRepoPath, string strserverRptPath)
        {
            try
            {
                string strSudiptoSign = ConfigurationManager.AppSettings["defaultSignatureSudipto"].ToString();
                string strQry = "truncate table " + ClsGlobal.const_strReportTable;
                ClsGlobal.ExcuteDML(strQry);

                string strInsertRpt = "Insert into " + ClsGlobal.const_strReportTable + "( " + strColumns + ")" + "(select " + strColumns +
                    " from " + strUploadSuccess + strReportcond + " )";
                ClsGlobal.ExcuteDML(strInsertRpt);

                string StrReportData = "select * from lpo_trnreporttbl";
                DataTable Objdt = ClsGlobal.GetData(StrReportData);
                if (Objdt.Rows.Count > 0)
                {
                    //TO DO
                    if (strTemplateName == "D3")
                    {
                        string strNonDunning = "update " + ClsGlobal.const_strReportTable + " set VU_TotOutstandingDues=ifnull(VU_AmountOverDues,0)+ifnull(VU_CHQ_BOU_CHARGES,0)+ifnull(VU_OVDCHARGES,0),  VU_SignaturePath = " +
                                                "'" + strSudiptoSign + "' where VU_LanNo REGEXP '^(AC|AM|AQ|AT|AV|BT|CA|CQ|CT|CU|DI|DV|E2|E7|E9|EA|EP|ES|HV|IP|L0|L2|L9|LA|LC|LD|LE|LF|LG|LI|AA|LJ" +
                                    "|LK|LL|LM|LN|LO|LP|LQ|LT|LU|LV|LW|MV|NC|RO|SA|SP|SU|TC|TM|TS|TT|UV|LB|LH|EF|EV|F5|H9|JP|L5|L8|M5|MA|MP|MT|UP|UQ|M9" +
                                            "|MF|NH|CV|L3|KF|K9|RA|RP|WP|NU|B2|EB|L1|M1|M2|M3|MB|R1|R5|RB|RT|SH|SV)' ";


                        ClsGlobal.ExcuteDML(strNonDunning);



                    }


                    ReportDocument cryRpt = new ReportDocument();
                    //cryRpt.Refresh();
                    cryRpt.Load(strserverRptPath);

                    cryRpt.Refresh();
                    ExportOptions CrExportOptions;
                    DiskFileDestinationOptions CrDiskFileDestinationOptions = new DiskFileDestinationOptions();
                    PdfRtfWordFormatOptions CrFormatTypeOptions = new PdfRtfWordFormatOptions();
                    CrDiskFileDestinationOptions.DiskFileName = strRepoPath;
                    CrExportOptions = cryRpt.ExportOptions;
                    {
                        CrExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
                        CrExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
                        CrExportOptions.DestinationOptions = CrDiskFileDestinationOptions;
                        CrExportOptions.FormatOptions = CrFormatTypeOptions;
                    }

                    cryRpt.Export();
                    MessageBox.Show("Report Generated SuccessFully");
                    cryRpt.Refresh();

                    cryRpt.Close();
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void uploadToFailed()
        {
            try
            {
                string strInsertRpt = "Insert into " + strUploadFailed + "( " + strColumns + ")" + "(select " +
                    strColumns + " from " + strUploadTbl + " )";

                ClsGlobal.ExcuteDML(strInsertRpt);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void SetGlobalVars(int iTempIndex)
        {
            DataTable dtTables = new DataTable();
            try
            {
                strTemplateLocation = ConfigurationManager.AppSettings["ReportPath"].ToString();
                string strGetTableQry = "select TemplateName, UploadTableName, UploadTableNameSuccess, " +
                "UploadTableNameFailed, TemplateID, CurRegNo, RegNoTO, Validation from lpo_templatemaster where TemplateID = " + iTempIndex.ToString();
                dtTables = ClsGlobal.GetData(strGetTableQry);
                foreach (DataRow row in dtTables.Rows)
                {
                    //strGlbColumns = row["TemplateName"].ToString();
                    iRegNo = Convert.ToInt32(row["CurRegNo"]);
                    strUploadTbl = row["UploadTableName"].ToString();
                    strUploadSuccess = row["UploadTableNameSuccess"].ToString();
                    strUploadFailed = row["UploadTableNameFailed"].ToString();
                    strValidation = row["Validation"].ToString();
                    strTemplateName = row["TemplateName"].ToString();

                }
                dtTables = new DataTable();
                string strTruncate = "TRUNCATE TABLE " + strUploadTbl;
                ClsGlobal.ExcuteDML(strTruncate);
                string strColQry = "select Group_Concat(a.DB_ColName, '') as DBColumns from lpo_genericcolmaster a  JOIN lpo_excelcolmappingmaster b " +
                                    "ON a.Col_ID = b.Col_ID and b.TemplateID = " + iTempIndex.ToString() + "  order by b.ExcelSquenceId; ; ";
                dtTables = ClsGlobal.GetData(strColQry);
                foreach (DataRow row in dtTables.Rows)
                {
                    strColumns = row["DBColumns"].ToString();
                }
                dtTables = new DataTable();

                strColQry = "select a.Col_ID,b.Col_ID,a.DB_ColName,b.ExcelColName, b.Type from lpo_genericcolmaster a  JOIN lpo_excelcolmappingmaster b " +
                                   "ON a.Col_ID = b.Col_ID and b.TemplateID = " + iTempIndex.ToString() + " order by b.ExcelSquenceId;";
                dtTables = ClsGlobal.GetData(strColQry);
                if (dtTables.Rows.Count > 0)
                {
                    foreach (DataRow row in dtTables.Rows)
                    {
                        if (!htGlbColTyp.Contains(row["DB_ColName"]))
                        {
                            htGlbColTyp.Add(row["DB_ColName"].ToString(), row["Type"].ToString());
                        }
                        //sbCol.Append(row["DB_ColName"].ToString() + ",");
                    }
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);

            }
        }
        private static void updateBasicValidation(string strDispatchMode)

        {
            try
            {
                //string strSudiptoSign = ConfigurationManager.AppSettings["defaultSignatureSudipto"].ToString();


                string strQry = "update " + strUploadTbl + " set  vu_FileName = '" +
                    StrFileName + "', VU_TemplateName = 'D3', VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "'";
                ClsGlobal.ExcuteDML(strQry);
                if (strDispatchMode == "INLAND")
                {
                    strQry = "update " + strUploadTbl + " set VU_DispatchMode = 'INLAND'";
                    ClsGlobal.ExcuteDML(strQry);
                }
                else
                {
                    strQry = "update " + strUploadTbl + " r join lpo_pincodematser_d3cc a on r.VU_AppPinCode = a.VU_Pin_Codes " +
                      "set r.VU_DispatchMode = 'COURIER'  where r.VU_AppPinCode = a.VU_Pin_Codes";
                    ClsGlobal.ExcuteDML(strQry);

                    strQry = "update " + strUploadTbl + " set VU_DispatchMode = 'INLAND'" +
                     " where VU_DispatchMode <> 'COURIER' or VU_DispatchMode  is null";
                    ClsGlobal.ExcuteDML(strQry);
                }




            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        internal static void generateAppStart()
        {
            DataTable dtFileUploadLog = new DataTable();
            string strUploadDate = string.Empty;
            string strBatchId = string.Empty;
            string strNumberofRecords = string.Empty;
            string strApp = string.Empty;
            try
            {
                string strAppStartQry = "select FileName, UploadDate, BatchId, AppStartNo,NumberofRecords" +
                     " from vu_fileuploadlog order by ID desc limit 1;";
                dtFileUploadLog = ClsGlobal.GetData(strAppStartQry);
                if (dtFileUploadLog.Rows.Count > 0)
                {
                    foreach (DataRow row in dtFileUploadLog.Rows)
                    {
                        strUploadDate = row["UploadDate"].ToString();
                        strBatchId = row["BatchId"].ToString();
                        strNumberofRecords = row["NumberofRecords"].ToString();
                        strApp = row["AppStartNo"].ToString();
                    }

                    //DateTime dtUpload = DateTime.ParseExact(strUploadDate, @"M/d/yyyy",
                    //    System.Globalization.CultureInfo.InvariantCulture);
                     DateTime dtUpload = Convert.ToDateTime(strUploadDate);
                    // DateTime dtUpload = DateTime.Parse(strUploadDate, null);
                    DateTime dtToday = DateTime.Now;

                    if (dtToday.Date > dtUpload.Date)
                    {
                        string strYr = DateTime.Now.Year.ToString();
                        string strDay = DateTime.Now.DayOfYear.ToString();
                        const string const_strAppNo = "0000001";

                        if (strDay.Length == 2)
                        {
                            strDay = "0" + strDay;
                        }
                        else if (strDay.Length == 1)
                        {
                            strDay = "00" + strDay;
                        }
                        strAppstartID = strYr + strDay + const_strAppNo;
                        int iBatch = 1;
                        strBatchID = iBatch.ToString();

                        return;
                    }
                    else
                    {
                        double iBatch = Convert.ToDouble(strBatchId) + 1;
                        strBatchID = iBatch.ToString();
                        double iAppNo = Convert.ToDouble(strApp) + Convert.ToDouble(strNumberofRecords);
                        strAppstartID = iAppNo.ToString();
                    }
                }


                else
                {
                    string strYr = DateTime.Now.Year.ToString();
                    string strDay = DateTime.Now.DayOfYear.ToString();
                    const string const_strAppNo = "0000001";

                    if (strDay.Length == 2)
                    {
                        strDay = "0" + strDay;
                    }
                    else if (strDay.Length == 1)
                    {
                        strDay = "00" + strDay;
                    }
                    strAppstartID = strYr + strDay + const_strAppNo;
                    strBatchID = "1";
                }



            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void uploadToSuccess(string strDispatchMode, DataTable dtUploadData, int TemplateID)
        {
            StringBuilder sbValues = new StringBuilder();
            Hashtable htRegNo = new Hashtable();
            Hashtable htMasterId = new Hashtable();
            double TotOutStandingAmt = 0.0;
            double BounceCh = 0.0;
            double OvDCh = 0.0;
            double dAppstart = Convert.ToDouble(strAppstartID);
            string strInsQry = "Insert into " + strUploadSuccess + "( " + strColumns + ") Values (";

            try
            {
                foreach (DataRow dRow in dtUploadData.Rows)
                {

                    bool bExecute = true;
                    foreach (DataColumn col in dtUploadData.Columns)
                    {
                        bool bDate = false;
                        //bool bLan = false;
                        string strColName = col.ColumnName;
                        string strColType = string.Empty;
                        if (strColName != "ID")
                        {
                            strColType = htGlbColTyp[strColName].ToString();
                        }
                        if (strColType == "Date")
                        {
                            bDate = ClsValidations.DateValidate(dRow[strColName].ToString(), "");
                            if (bDate)
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }
                        else if (strColName == "VU_LANNo")
                        {
                            string LANNO = dRow[strColName].ToString();
                            Regex r1 = new Regex("^[A-Z0-9]{16}$");
                            if (r1.IsMatch(LANNO))
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }
                        else if (strColName == "VU_REGNO")
                        {
                            if (!String.IsNullOrEmpty(dRow["VU_CHQ_BOU_CHARGES"].ToString()) == true)
                            {
                                BounceCh = Convert.ToDouble(dRow["VU_CHQ_BOU_CHARGES"].ToString());
                            }
                            if (!String.IsNullOrEmpty(dRow["VU_OVDCHARGES"].ToString()) == true)
                            {
                                OvDCh = Convert.ToDouble(dRow["VU_OVDCHARGES"].ToString());
                            }
                            TotOutStandingAmt = (Convert.ToDouble(dRow["VU_AmountOverDues"].ToString()) + BounceCh + OvDCh);
                            if (!htRegNo.Contains(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString() + ", " + TotOutStandingAmt.ToString()))
                            {
                                htRegNo.Add(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString(), iRegNo.ToString() +
                                "," + dRow["VU_AmountOverDues"].ToString() + "," + dRow["VU_CHQ_BOU_CHARGES"].ToString() +
                                ", " + dRow["VU_OVDCHARGES"].ToString());
                                sbValues.Append("'" + iRegNo.ToString() + "',");
                                iRegNo += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }

                        }
                        else if (strColName == "VU_IsPrinted")
                        {
                            sbValues.Append("'N'" + ",");
                            continue;
                        }

                        else if (strColName == "VU_MasterID")
                        {
                            if (!htMasterId.Contains(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()))
                            {
                                htMasterId.Add(dRow["VU_ApplicantName"].ToString().Trim() +
                                "," + dRow["VU_LANNO"].ToString()
                                   , dAppstart.ToString());
                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                dAppstart += 1;
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }

                        }
                        else if (strColName == "VU_BatchNO")
                        {
                            sbValues.Append(strBatchID + ",");
                            continue;
                        }
                        else
                        {
                            if (strColName != "ID")
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                            }

                        }
                    }

                    if (bExecute)
                    {


                        string strInsert = strInsQry + sbValues.ToString();

                        //sbValues.Replace()
                        strInsert = strInsert.Remove(strInsert.LastIndexOf(","));
                        strInsert += ")";


                        ClsGlobal.ExcuteDML(strInsert);
                        string strDeletermp = "Delete from " + strUploadTbl + " where ID = '" + dRow["ID"].ToString() + "';";
                        ClsGlobal.ExcuteDML(strDeletermp);

                        sbValues.Clear();
                    }



                }
                strAppstartID = (dAppstart).ToString();


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void tempUpload(string strPath)
        {
            try
            {
                strPath = strPath.Replace("\\", "\\\\");
                string strQry = "LOAD DATA LOCAL INFILE '" + strPath + "' INTO TABLE " + strUploadTbl +
                                    " FIELDS TERMINATED BY '|' LINES TERMINATED BY '\r\n' IGNORE 1 LINES" +
                   " (@LOAN_NO, @AMOUNT_OVERDUE, @BUCKET, @CUSTOMER_NAME, @CUST_MAILING_ADDR1, @CUST_MAILING_ADDR2, @CUST_MAILING_ADDR3,@CUST_MAILING_ADDR4 " +
                   ", @CUST_MAILING_CITY, @CUST_MAILING_PIN,@AS_ON_DATE, @BOUNCE_CHARGE," +
                    "@OVD_CHARGE, @COLL_AGENCY_CODE, @COLL_AGENCY_NAME, @COLL_AGENCY_ADD1 " +
                   ", @COLL_AGENCY_ADD2, @COLL_AGENCY_ADD_CITY, @COLL_AGENCY_ADD_STATE,@COLL_AGENCY_ADD_PINCODE,@COLL_AGENCY_CONTACT_NO,@Type) " +
                   " set VU_LANNo = @LOAN_NO,VU_AmountOverDues=@AMOUNT_OVERDUE,VU_BUCKET=@BUCKET, VU_ApplicantName = @CUSTOMER_NAME,VU_AppAdd1=@CUST_MAILING_ADDR1,VU_AppAdd2=@CUST_MAILING_ADDR2,VU_AppAdd3=@CUST_MAILING_ADDR3,VU_AppAdd4=@CUST_MAILING_ADDR4," +
                   "VU_AppCity = @CUST_MAILING_CITY,VU_AppPincode = @CUST_MAILING_PIN,VU_DuesAsOn=@AS_ON_DATE,VU_CHQ_BOU_CHARGES=@BOUNCE_CHARGE,VU_OVDCHARGES=@OVD_CHARGE" +
                   ", VU_COLAGENCYCD=@COLL_AGENCY_CODE,VU_COLL_AGENCY_NAME=@COLL_AGENCY_NAME,VU_COLL_AGENCY_ADD1 = @COLL_AGENCY_ADD1,VU_COLAGENCYADD2=@COLL_AGENCY_ADD2, VU_COLL_AGENCY_ADD_CITY = @COLL_AGENCY_ADD_CITY, VU_COLL_AGENCY_ADD_STATE = @COLL_AGENCY_ADD_STATE," +
                   "VU_COLL_AGENCY_ADD_PINCODE = @COLL_AGENCY_ADD_PINCODE, VU_COLL_AGENCY_CONTACT_NO = @COLL_AGENCY_CONTACT_NO, VU_Type = @Type";


                ClsGlobal.ExcuteDML(strQry);



            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static int getFileColCount(string txtPath)
        {
            try
            {
                int iCnt = 0;
                string strHeading = string.Empty;
                strHeading = File.ReadLines(txtPath).First();

                string[] strCols = strHeading.Split('|');

                iCnt = strCols.Length;


                return iCnt;
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return 0;
            }
        }
        public static void UpdateLogFile(string strGlbFileName, string strGlbAppstartID, string strGlbBatchID, int iRowCont, string strGlbTemplateName)
        {
            try
            {
                string strUpdateFileLog = "Insert into vu_fileuploadlog (FileName, " +
                " UploadDate, BatchId, AppStartNo,NumberofRecords,TemplateName) Values ('" +
                 strGlbFileName + "','" + DateTime.Now.ToShortDateString() + "','" + strGlbBatchID + "','" + strGlbAppstartID + "','" +
                  iRowCont.ToString() + "','" + strGlbTemplateName + "')";

                ClsGlobal.ExcuteDML(strUpdateFileLog);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
    }
}
