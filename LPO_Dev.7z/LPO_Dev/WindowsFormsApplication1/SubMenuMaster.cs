﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    public partial class SubMenuMaster : Form
    {
        public SubMenuMaster()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string ActiveFlag = string.Empty;
                string StrSqlInsert = string.Empty;
                string StrSqlUpdate = string.Empty;
                if (txtSubMenu.Text == "")
                {
                    MessageBox.Show("Please Enter SubMenu name !!");
                    return;
                }
                if (txtPageURL.Text == "")
                {
                    MessageBox.Show("Please Enter Page URL!!");
                    return;
                }


                if (chkActive.Checked == true)
                {
                    ActiveFlag = "Y";
                }
                else
                {
                    ActiveFlag = "N";
                }

                DateTime currentDate = DateTime.Now;
                if (btnSave.Text == "Update")
                {
                    StrSqlUpdate = "Update vu_admin_submenumaster  set Sub_Menu_Name='" + txtSubMenu.Text.Trim() + "',Sub_Menu_URL='" + txtPageURL.Text.Trim() + "',IsFlag='" + ActiveFlag + "' where Menu_Id_fk='" + cmbMenu.SelectedValue + "'  and SubMenu_Id='" + ClsProperty.SubMenuID + "'";
                    bool Update = clsMain.ExcuteDML(StrSqlUpdate);
                    if (Update == true)
                    {
                        MessageBox.Show("Data Update Successfully..");

                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }
                }
                else
                {
                    StrSqlInsert = "Insert into vu_admin_submenumaster(Menu_Id_fk,Sub_Menu_Name,Sub_Menu_URL,IsFlag,Created_On,Created_by )"
                                        + "values ('" + cmbMenu.SelectedValue + "','" + txtSubMenu.Text.Trim() + "','" + txtPageURL.Text.Trim() + "','Y','" + currentDate.ToString("dd-MM-yyyy") + "','" + ClsProperty.UserName + "')";


                    bool Insert = clsMain.ExcuteDML(StrSqlInsert);
                    if (Insert == true)
                    {
                        MessageBox.Show("Data Save Successfully..");

                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }
                }
                BindSubMenu();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
        public void BindCombo()
        {
            try
            {
                string StrSql = "select MenuID,MenuName from vu_admin_menumaster where IsFlag = 'Y' ";
                DataTable dt = clsMain.GetData(StrSql);
                clsMain.Bind_Combo(cmbMenu, dt, "MenuName", "MenuID");
            }
            catch (Exception ex)
            {


                MessageBox.Show(ex.Message);
            }
        }

        public void BindSubMenu()
        {
            try
            {
                String StrData = "Select SubMenu_Id,Sub_Menu_Name,MenuName,Sub_Menu_URL,a.Menu_Id_fk,a.ISFlag from vu_admin_submenumaster  as a inner join vu_admin_menumaster as b on a.Menu_Id_fk = b.MenuId  where b.IsFlag = 'Y'   order by b.MenuId  ";
                DataTable Objdt = new DataTable();
                Objdt = clsMain.GetData(StrData);
                if (Objdt.Rows.Count > 0)
                {
                    dvSubMenu.AutoGenerateColumns = false;

                    dvSubMenu.Columns[1].Name = "SubMenu_Id";
                    dvSubMenu.Columns[1].HeaderText = "SubMenu Id";
                    dvSubMenu.Columns[1].DataPropertyName = "SubMenu_Id";
                    dvSubMenu.Columns[1].Width = 100;


                    dvSubMenu.Columns[2].Name = "MenuName";
                    dvSubMenu.Columns[2].HeaderText = "Menu Name";
                    dvSubMenu.Columns[2].DataPropertyName = "MenuName";
                    dvSubMenu.Columns[2].Width = 150;

                    dvSubMenu.Columns[3].Name = "Sub_Menu_Name";
                    dvSubMenu.Columns[3].HeaderText = "SubMenu Name";
                    dvSubMenu.Columns[3].DataPropertyName = "Sub_Menu_Name";
                    dvSubMenu.Columns[3].Width = 150;

                    dvSubMenu.Columns[4].Name = "Menu_Id_fk";
                    dvSubMenu.Columns[4].HeaderText = "Menu_Id_fk";
                    dvSubMenu.Columns[4].DataPropertyName = "Menu_Id_fk";
                    dvSubMenu.Columns[4].Width = 150;

                    dvSubMenu.Columns[5].Name = "Sub_Menu_URL";
                    dvSubMenu.Columns[5].HeaderText = "SubMenu URL";
                    dvSubMenu.Columns[5].DataPropertyName = "Sub_Menu_URL";
                    dvSubMenu.Columns[5].Width = 150;

                    dvSubMenu.Columns[6].Name = "ISFlag";
                    dvSubMenu.Columns[6].HeaderText = "ISFlag";
                    dvSubMenu.Columns[6].DataPropertyName = "ISFlag";
                    dvSubMenu.Columns[6].Width = 150;


                    dvSubMenu.AllowUserToAddRows = false;

                    dvSubMenu.DataSource = Objdt;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void SubMenuMaster_Load(object sender, EventArgs e)
        {
            this.Width = 650;
            this.Height = 550;
            this.grpbox.Width = 493;
            this.grpbox.Height = 203;

            BindCombo();
            BindSubMenu();
        }

        private void btnreset_Click(object sender, EventArgs e)
        {
            txtSubMenu.Text = "";
            txtPageURL.Text = "";

        }

        private void dvSubMenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int row;

                row = e.RowIndex;

                string SubMenu_Id = dvSubMenu.Rows[row].Cells["SubMenu_Id"].Value.ToString();
                ClsProperty.SubMenuID = SubMenu_Id;
                string Sub_Menu_Name = dvSubMenu.Rows[row].Cells["Sub_Menu_Name"].Value.ToString();
                txtSubMenu.Text = Sub_Menu_Name;

                string Menu_Id = dvSubMenu.Rows[row].Cells["Menu_Id_fk"].Value.ToString();
                cmbMenu.SelectedValue = Menu_Id;
                string Sub_Menu_URL = dvSubMenu.Rows[row].Cells["Sub_Menu_URL"].Value.ToString();
                txtPageURL.Text = Sub_Menu_URL;

                string ISFlag = dvSubMenu.Rows[row].Cells["ISFlag"].Value.ToString();
                if (ISFlag == "Y")
                {
                    chkActive.Checked = true;
                }
                else
                {
                    chkActive.Checked = false;
                }
                this.dvSubMenu.Cursor = Cursors.Hand;
                btnSave.Text = "Update";
            }
            catch (Exception ex)
            {


                MessageBox.Show(ex.Message);
            }
        }

        private void dvSubMenu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string StrDelete = string.Empty;
            List<DataGridViewRow> selectedRows = (from row in dvSubMenu.Rows.Cast<DataGridViewRow>()
                                                  where Convert.ToBoolean(row.Cells["ChkColumn"].Value) == true
                                                  select row).ToList();
            if (MessageBox.Show(string.Format("Do you want to delete {0} rows?", selectedRows.Count), "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (DataGridViewRow row in selectedRows)
                {
                    StrDelete = "Delete from   vu_admin_submenumaster WHERE SubMenu_Id='" + row.Cells["SubMenu_Id"].Value + "'";
                    bool Delete = clsMain.ExcuteDML(StrDelete);
                    if (Delete == true)
                    {
                        MessageBox.Show("Data Delete Successfully..");
                    }
                    else
                    {
                        MessageBox.Show("Please try again..");
                    }
                  
                }

                this.BindSubMenu();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }

}
