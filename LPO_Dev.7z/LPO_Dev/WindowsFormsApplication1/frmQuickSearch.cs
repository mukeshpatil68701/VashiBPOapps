﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    public partial class frmQuickSearch : Form
    {
        public frmQuickSearch()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmQuickSearch_Load(object sender, EventArgs e)
        {
            
            pnlbulk .Enabled = false;           
            rbtnBulkSearch.Checked = false  ;
            Pnlsingle.Enabled = true ;
            clear();
        }
        void clear()
        {
            txtLoanno.Text = "";
            textAppno.Text = "";
            textBrowse.Text = "";
            dataGridView1.Columns.Clear();
        }
        private void rbtnBulkSearch_CheckedChanged(object sender, EventArgs e)
        {
            pnlbulk.Enabled = true;
            Pnlsingle.Enabled = false;
            btnRecords.Enabled = false;
            clear();
        }

        private void rbtnSingleSearch_CheckedChanged(object sender, EventArgs e)
        {
            Pnlsingle.Enabled = true;
            pnlbulk.Enabled = false;
            clear();
        }

        private void btnRecords_Click(object sender, EventArgs e)
        {
            bool bCon = false;
            bCon = PGlobalclass.Connect();
            if (bCon)
            {
                PGlobalclass.Showdata(this, txtLoanno.Text.ToString(), textAppno.Text.ToString(), textBrowse.Text.ToString() );
            }
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }

        private void btnExel_Click(object sender, EventArgs e)
        {
            if (rbtnSingleSearch.Checked == true)
            {
                bool bCon = false;
                bCon = PGlobalclass.Connect();
                if (bCon)
                {
                    PGlobalclass.GenerateExcl(this, txtLoanno.Text.ToString(), textAppno.Text.ToString());

                  //  MessageBox.Show(" MIS Exported Successfully ");
                }
                else
                {
                    MessageBox.Show("Unable to connect to Server");
                    return;
                }
            }
            else if(rbtnBulkSearch.Checked== true)
            {
                bool bCon = false;
                bCon = PGlobalclass.Connect();
                if (bCon)
                {
                    if (rbtnLoanno.Checked  == true)
                    {
                        PGlobalclass.GenerateExclbulk(this, textBrowse.Text.ToString());

                     //   MessageBox.Show(" MIS Exported Successfully ");
                    }
                    else if (rbtnAppno.Checked == true)
                    {
                        PGlobalclass.GenerateExclbulkbyapp(this, textBrowse.Text.ToString());

                       /// MessageBox.Show(" MIS Exported Successfully ");
                    }
                  
                }
                else
                {
                    MessageBox.Show("Unable to connect to Server");
                    return;
                }

            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            textBrowse.Text = "";

            //ofdbox.Filter = "*.xls|*.xlsx";
            ofdbox.ShowDialog();
            textBrowse.Text = ofdbox.FileName;
            toolTip1.SetToolTip(btnBrowse, textBrowse.Text);
            toolTip1.SetToolTip(btnBrowse, textBrowse.Text);
        }
    }
}
