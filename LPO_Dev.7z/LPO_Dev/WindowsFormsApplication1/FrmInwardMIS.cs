﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LPO_Dev
{
    public partial class FrmInwardMIS : Form
    {
        private readonly SqlConnection con;
        string LivePath = string.Empty;
        string RTOpodDownloadPath = string.Empty;     
        DataTable dt = new DataTable();
        string IS_POD_RTO = string.Empty;
        public Size Multiplier { get; private set; }

        public FrmInwardMIS()
        {
            InitializeComponent();
        }

        private void rbtnSingleSearch_CheckedChanged(object sender, EventArgs e)
        {
            pnlsingle.Enabled = true;
            pnlbulk.Enabled = false;
            PnlbyDate.Enabled = false;
            dgvStatus.DataSource = null;        
            textBrowse.Text = "";
            // clear();
        }

        private void rbtnBulkSearch_CheckedChanged(object sender, EventArgs e)
        {
            pnlbulk.Enabled = true;
            PnlbyDate.Enabled = false;
            pnlsingle.Enabled = false;
            dgvStatus.DataSource=null;
            txtLoanno.Text = "";
            textAppno.Text = "";
            textBrowse.Text = "";
           
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            textBrowse.Text = "";        
            ofdbox.ShowDialog();
            textBrowse.Text = ofdbox.FileName;
            toolTip1.SetToolTip(btnBrowse, textBrowse.Text);
            toolTip1.SetToolTip(btnBrowse, textBrowse.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRecords_Click(object sender, EventArgs e)
        {
            if (rbtbyinwardDate.Checked == true)
            {
                bool bCon = false;
                bCon = PGlobalclass.Connect();
                if (bCon)
                {
                    PGlobalclass.ShowInward(this, FrmdateTimePicker.Text.ToString(), TodateTimePicker.Text.ToString(), textBrowse.Text.ToString());
                }
                else
                {
                    MessageBox.Show("Unable to connect to Server");
                    return;
                }
            }

            else if (rbtnSingleSearch .Checked == true)
            {
                bool bCon = false;
                bCon = PGlobalclass.Connect();
                if (bCon)
                {
                    PGlobalclass.ShowInwardsingle(this, txtLoanno .Text.ToString(), textAppno .Text.ToString());
                }
                else
                {
                    MessageBox.Show("Unable to connect to Server");
                    return;
                }
            }

            else if(rbtnBulkSearch.Checked== true)
            {
                bool bCon = false;
                bCon = PGlobalclass.Connect();
                if (bCon)
                {
                    if (rbtnAppno.Checked == true)
                    {
                        PGlobalclass.ShowInwardbulkAppno(this, textBrowse.Text.ToString());
                    }
                    else if(rbtnLoanno.Checked== true)
                    {
                        PGlobalclass.ShowInwardbulkLanno(this, textBrowse.Text.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Unable to connect to Server");
                    return;
                }

            }
        }

        private void dgvStatus_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int row = 0;
            row = e.RowIndex;

            
            var senderGrid = (DataGridView)sender;

            int INDEX = dgvStatus.Columns["DownloadImage"].Index;
            var column = senderGrid.Columns[e.ColumnIndex];

            if (e.RowIndex >= 0)
            {
                if ((object)column.Name == "DownloadImage")
                {

                    string Masterid = dgvStatus.Rows[row].Cells["VU_MasterID"].Value.ToString();

                    //byte[] getImg = new byte[0];

                    //dt = clsMain.GetData("select VU_Image from lpo_inward where vu_MasterID = '" + Masterid + "'");
                    //foreach (DataRow dr in dt.Rows)
                    //{
                    //    getImg = (byte[])dr["VU_Image"];
                    //}

                    //byte[] imgData = getImg;
                    //MemoryStream stream = new MemoryStream(imgData);
                    //pictureBox1.Image = Image.FromStream(stream);

                    string srPath = string.Empty;

                    dt = clsMain.GetData("select VU_inward_image_serverPath,VU_inward_IS_POD_RTO from lpo_trnsuccess where vu_MasterID = '" + Masterid + "'");
                    if (dt.Rows.Count > 0)
                    {
                        srPath = dt.Rows[0]["VU_inward_image_serverPath"].ToString();
                        IS_POD_RTO  = dt.Rows[0]["VU_inward_IS_POD_RTO"].ToString();

                        string path = PGlobalclass.strDownloadPath  + IS_POD_RTO +"_"+ Masterid + ".TIF";
                        if (File.Exists(path))
                        {
                            MessageBox.Show("Image already Downloaded ");
                        }
                        else
                        {
                            File.Copy(srPath, path);

                            MessageBox.Show("Image Downloaded Successfully ");
                        }
                    }
                    else if (dt.Rows.Count == 0)
                    {
                        dt = clsMain.GetData("select VU_inward_image_serverPath,VU_inward_IS_POD_RTO from lpo_image_inward_mis where VU_Inward_MasterID = '" + Masterid + "'");
                        if (dt.Rows.Count > 0)
                        {
                            srPath = dt.Rows[0]["VU_inward_image_serverPath"].ToString();
                            IS_POD_RTO = dt.Rows[0]["VU_inward_IS_POD_RTO"].ToString();

                            string path = PGlobalclass.strDownloadPath + IS_POD_RTO + "_" + Masterid + ".TIF";
                            if (File.Exists(path))
                            {
                                MessageBox.Show("Image already Downloaded ");
                            }
                            else
                            {
                                File.Copy(srPath, path);

                                MessageBox.Show("Image Downloaded Successfully ");
                            }
                        }


                    }
                    else
                    {
                        MessageBox.Show("image unavailable");
                    }

                }

                else if ((object)column.Name == "showImage")
                {
                    string Masterid = dgvStatus.Rows[row].Cells["VU_MasterID"].Value.ToString();


                    string srPath = string.Empty;

                    dt = clsMain.GetData("select VU_inward_image_serverPath from lpo_trnsuccess where vu_MasterID = '" + Masterid + "'");
                    if (dt.Rows.Count > 0)
                    {
                        srPath = dt.Rows[0]["VU_inward_image_serverPath"].ToString();                     
                        pictureBox1.ImageLocation = (srPath);
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    }
                    else if (dt.Rows.Count == 0)
                    {
                        dt = clsMain.GetData("select VU_inward_image_serverPath from lpo_image_inward_mis where VU_Inward_MasterID = '" + Masterid + "'");
                        if (dt.Rows.Count > 0)
                        {
                            srPath = dt.Rows[0]["VU_inward_image_serverPath"].ToString();
                            pictureBox1.ImageLocation = (srPath);
                            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        }

                    }
                    else
                    {
                        MessageBox.Show("image unavailable");
                    }
                }
            }
        }
        private void dgvStatus_CellClick(object sender, DataGridViewCellEventArgs e)
        {
        
        }

        public void ZoomIn()
        {
            Multiplier = new Size(2, 2);

            Image MyImage = pictureBox1.Image;

            Bitmap MyBitMap = new Bitmap(MyImage, Convert.ToInt32(MyImage.Width * Multiplier.Width),
                Convert.ToInt32(MyImage.Height * Multiplier.Height));

            Graphics Graphic = Graphics.FromImage(MyBitMap);

            Graphic.InterpolationMode = InterpolationMode.High;

            pictureBox1.Image = MyBitMap;

        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            Point pt_MouseAbs = Control.MousePosition;
            Control i_Ctrl = pictureBox1;
            do
            {
                Rectangle r_Ctrl = i_Ctrl.RectangleToScreen(i_Ctrl.ClientRectangle);
                if (!r_Ctrl.Contains(pt_MouseAbs))
                {
                    base.OnMouseWheel(e);
                    return; 
                }
                i_Ctrl = i_Ctrl.Parent;
            }
            while (i_Ctrl != null && i_Ctrl != this);        
            Point pt_MouseRel = pictureBox1.PointToClient(pt_MouseAbs);
           
  
}
  
        private void hScrollBar1_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
        {

        }

 

        private void vScrollBar1_Scroll(object sender, System.Windows.Forms.ScrollEventArgs e)
        {

        }

        public void ZoomOut()
        {
            Multiplier = new Size(2, 2);

            Image MyImage = pictureBox1.Image;

            Bitmap MyBitMap = new Bitmap(MyImage, Convert.ToInt32(MyImage.Width / Multiplier.Width),
                Convert.ToInt32(MyImage.Height / Multiplier.Height));

            Graphics Graphic = Graphics.FromImage(MyBitMap);

            Graphic.InterpolationMode = InterpolationMode.High;

            pictureBox1.Image = MyBitMap;

        }

        private void textBrowse_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F4)
            {
                ZoomIn();
            }

            if (e.KeyCode == Keys.F5)
            {
                ZoomOut();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            txtpic .Focus();
        }

        private void FrmInwardMIS_Load(object sender, EventArgs e)
        {
            FrmdateTimePicker.Format = DateTimePickerFormat.Short;
            FrmdateTimePicker.Format = DateTimePickerFormat.Custom;
            FrmdateTimePicker.CustomFormat = "dd/MM/yyyy";
            TodateTimePicker.Format = DateTimePickerFormat.Short;
            TodateTimePicker.Format = DateTimePickerFormat.Custom;
            TodateTimePicker.CustomFormat = "dd/MM/yyyy";

            //dt = clsMain.GetData("select vu_Live_path from lpo_serverpath;");

            //LivePath = dt.Rows[0]["vu_Live_path"].ToString();

            bool bCon = false;
            bCon = PGlobalclass.Connect();

            //RTOpodDownloadPath = PGlobalclass.strDownloadPath;
            if (!Directory.Exists(PGlobalclass.strDownloadPath))
            {
                Directory.CreateDirectory(PGlobalclass.strDownloadPath);
            }
           

        }

        private void btnzoomin_Click(object sender, EventArgs e)
        {        
            pictureBox1.Height += 10;
            pictureBox1.Width += 10;
        }

        private void btnZoomout_Click(object sender, EventArgs e)
        {
            pictureBox1.Height -= 10;
            pictureBox1.Width -= 10;           
        }

        private void Pnlsingle_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dgvStatus.Rows)
            {
                DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)row.Cells[0];

                if (checkBox1.Checked == true)
                {
                    if (chk.Value == null)
                    {
                        chk.Value = true;
                    }
                    else if (!(bool)chk.Value)
                    {
                        chk.Value = true;
                    }
                }
                else if (checkBox1.Checked == false)
                {
                    if (chk.Value == null)
                    {
                        chk.Value = false;
                    }
                    else if ((bool)chk.Value)
                    {
                        chk.Value = false;
                    }
                }
            }
        }

        private void btnExel_Click(object sender, EventArgs e)
        {
            int icnt = 0;
     

            foreach (DataGridViewRow Datarow in dgvStatus .Rows)
            {
                icnt++;
                DataGridViewCheckBoxCell chk = (DataGridViewCheckBoxCell)Datarow.Cells[0];
                if (chk.Value == null)
                {
                    chk.Value = false;
                }
                if ((bool)chk.Value)
                {

                    string Masterid = dgvStatus.Rows[icnt-1].Cells["VU_MasterID"].Value.ToString();

                    string srPath = string.Empty;

                    dt = clsMain.GetData("select VU_inward_image_serverPath,VU_inward_IS_POD_RTO from lpo_trnsuccess where vu_MasterID = '" + Masterid + "'");
                    if (dt.Rows.Count > 0)
                    {
                        srPath = dt.Rows[0]["VU_inward_image_serverPath"].ToString();
                        IS_POD_RTO = dt.Rows[0]["VU_inward_IS_POD_RTO"].ToString();
                    }
                    else if(dt.Rows.Count == 0)
                    {
                        dt = clsMain.GetData("select VU_inward_image_serverPath,VU_inward_IS_POD_RTO from lpo_image_inward_mis where VU_Inward_MasterID = '" + Masterid + "'");
                        if (dt.Rows.Count > 0)
                        {
                            srPath = dt.Rows[0]["VU_inward_image_serverPath"].ToString();
                            IS_POD_RTO = dt.Rows[0]["VU_inward_IS_POD_RTO"].ToString();
                        }

                    }
                    string path = PGlobalclass.strDownloadPath + IS_POD_RTO +"_" + Masterid + ".TIF";
                    if (File.Exists(path))
                    {
                      //  MessageBox.Show("Image already Downloaded ");
                    }
                    else
                    {                        
                        File.Copy(srPath, path);                       
                    }                                     
                }              
            }
            MessageBox.Show("Image Downloaded Successfully ");
        }

        private void FrmInwardMIS_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void txtpic_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F4)
            {
                ZoomIn();
            }

            if (e.KeyCode == Keys.F5)
            {
                ZoomOut();
            }
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            txtpic.Focus();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            //pBox = sender as PictureBox;
            //e.Graphics.DrawImage(pBox.Image, e.ClipRectangle, x, y, e.ClipRectangle.Width,
            //  e.ClipRectangle.Height, GraphicsUnit.Pixel);
        }

        private void rbtbyinwardDate_CheckedChanged(object sender, EventArgs e)
        {
            pnlsingle .Enabled = false;
            pnlbulk.Enabled = false;
            dgvStatus.DataSource = null;
            PnlbyDate.Enabled = true;
            txtLoanno.Text = "";
            textAppno.Text = "";
            textBrowse.Text = "";
                
        }

        private void rbtnLoanno_CheckedChanged(object sender, EventArgs e)
        {
            dgvStatus.DataSource = null;
            textBrowse.Text = "";
        }

        private void rbtnAppno_CheckedChanged(object sender, EventArgs e)
        {
            dgvStatus.DataSource = null;
            textBrowse.Text = "";
        }
    }
}
