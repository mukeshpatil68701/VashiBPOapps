﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    public partial class frmUpload : Form
    {
      
        public frmUpload()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {

                ofdXlS = new OpenFileDialog();

                ofdXlS.Title = "Browse Files";
                ofdXlS.Filter = " files (*.xls)(*.txt)|*.xls;*.txt";
                DialogResult dlgResult = ofdXlS.ShowDialog();
                if (dlgResult == DialogResult.OK)
                {
                    txtPath.Text = ofdXlS.FileName;
                }

                //ofdXlS.Title = "Browse Excel Files";
                //ofdXlS.Filter = "Excel files (*.xls)|*.xls";
                //DialogResult dlgResult = ofdXlS.ShowDialog();
                //if (dlgResult == DialogResult.OK)
                //{
                //    txtPath.Text = ofdXlS.FileName;
                //}
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name +" " + Ex.Message);
            }
        }

        private void frmUpload_Load(object sender, EventArgs e)
        {
            gbD3CC.Visible = false;
            
            



            bool bCon = false;
            bCon = ClsGlobal.Connect();
            if (bCon)
            {
                ClsGlobal.cmbFill(this);
            }
            else
            {
                MessageBox.Show("Unable to connect to Server");
                return;
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            
            bool bXlsCon = false;
            if (cmbTemplate.SelectedIndex == 0)
            {
                MessageBox.Show("Select Valid Template");
                return;
            }




            if (txtPath.Text != "" && File.Exists(txtPath.Text))
            {
               
                string strTemplate = cmbTemplate.SelectedItem.ToString();

                if (strTemplate != "D3CC" && strTemplate != "D3")
                {
                    bXlsCon = ClsGlobal.ExcelCon(txtPath.Text);
                }

                if (strTemplate == "D3CC")
                {
                    string strDispatchMode = rbInland.Checked ? "INLAND" : "COURIER";
                    D3CCUpload.ProcessD3CC(cmbTemplate.SelectedIndex, txtPath.Text, strDispatchMode);
                    this.Close();

                }
                else if (strTemplate == "D3")
                {
                    string strDispatchMode = rbInland.Checked ? "INLAND" : "COURIER";
                    D3Upload.ProcessD3(cmbTemplate.SelectedIndex, txtPath.Text, strDispatchMode);
                    this.Close();
                }

                if (strTemplate == "ODRN" || strTemplate == "ODRS")
                {
                    string strDispatchMode = rbSP.Checked ? "SP" : "REG";
                    ClsGlobal.ProcessExcel(cmbTemplate.SelectedIndex, strDispatchMode);
                    this.Close();
                }
                else if (strTemplate == "SARF13_2_WHEELS")
                {
                    ClsSARFWHEELS.ProcessExcel(cmbTemplate.SelectedIndex, "SP", txtPath.Text);
                    this.Close();
                }
                else if (strTemplate == "ODRSeBOR")
                {
                    ClsOdrseBor.ProcessExcel(cmbTemplate.SelectedIndex, "SP", txtPath.Text);
                    this.Close();
                }
                else if (bXlsCon && strTemplate.ToUpper()!= "MAILMERGE")
                {
                    gbD3CC.Visible = false;
                    ClsGlobal.ProcessExcel(cmbTemplate.SelectedIndex, "");
                    this.Close();
                }
                else if (bXlsCon && strTemplate.ToUpper() == "MAILMERGE")
                {
                    gbD3CC.Visible = false;
                    ClsMailMergeUpload.ProcessMailMerge(cmbTemplate.SelectedIndex, txtPath.Text);
                    pnlMailMergeCnt.Visible = false;
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Select Valid Excel");
            }
        }

        private void cmbTemplate_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strTemplate = cmbTemplate.SelectedItem.ToString();
            if (strTemplate.ToUpper() == "MAILMERGE")
            {
                gbD3CC.Visible = false;
                pnlMailMergeCnt.Visible = true;
                string strUniqueId = ClsMailMergeUpload.GetMaxUniqueID();
                lblMMCnt.Text = "Last Unique id :" + strUniqueId;
            }
            else
            {
                pnlMailMergeCnt.Visible = false;
            }

            if (strTemplate.ToUpper() == "D3CC" || strTemplate.ToUpper() == "D3")
            {
                gbD3CC.Visible = true;
                rbInland.Checked = true;
            }
            else
            {
                gbD3CC.Visible = false;
            }


            if (strTemplate.ToUpper() == "ODRN" ||strTemplate == "ODRS" || strTemplate == "ODRSeBOR")
            {
                gbOdrn.Visible = true;
                rbSP.Checked = true;
            }
            else
            {
                gbOdrn.Visible = false;
            }
        }
    }
}
