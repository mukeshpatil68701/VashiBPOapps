﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace LPO_Dev
{
    public partial class Login : Form
    {
        public static string strUser = string.Empty;
        public Login()
        {
            InitializeComponent();
        }
        static string MachineName = System.Environment.MachineName;
        static DateTime CurrentDate = DateTime.Now;

        static string VerSion = clsMain.Encrypt("V2.1.0");
        static string ExpDate = clsMain.Encrypt("30/06/2017");
        private void button1_Click(object sender, EventArgs e)
        {
            strUser = txtUserName.Text;
            LoginMethodWithValidation();
        }
       
        public void LoginMethod()
        {
            try
            {
                DataTable dt = new DataTable();
                string EncryptPwd = string.Empty;
                EncryptPwd = clsMain.Encrypt(txtPwd.Text.Trim());
                if (txtUserName.Text == "" || txtPwd.Text == "")
                {
                    MessageBox.Show("Please Enter UserName/Password..");
                    return;

                }



                dt = clsMain.GetData("select * from VU_Admin_UserInfo  WHERE USER_NAME='" + txtUserName.Text.Trim() + "'  AND PASSWORD='" + EncryptPwd + "'  and BLOCK='N'");
                if (dt.Rows.Count > 0)
                {


                    bool IsUpdate = clsMain.ExcuteDML("Update VU_Admin_UserInfo  set LOGIN='Y' ,SYSNAME='" + MachineName + "' "
                        + " WHERE USER_NAME='" + txtUserName.Text.Trim() + "'  AND PASSWORD='" + EncryptPwd + "' ");
                    bool IsInsert = clsMain.ExcuteDML("Insert into VU_Admin_User_Log(USER_ID,LDATE,INTIME,SYSNAME)  values ('" + txtUserName.Text.Trim() + "'"
                        + ",'" + CurrentDate.ToString("dd/MM/yyyy") + "','" + CurrentDate.ToString("hh:mm:ss") + "','" + MachineName + "')");
                    if (IsUpdate == true && IsInsert == true)
                    {
                        ClsProperty.UserName = txtUserName.Text;
                        ClsProperty.Pwd = txtPwd.Text;
                        ClsProperty.Machine = MachineName;
                        ClsProperty.IsFlag = "Y";
                        ClsProperty.UserTypeID = dt.Rows[0]["USER_TypeID"].ToString();

                        this.Hide();
                      
                        MDIParent mdipar = new MDIParent();
                       
                        mdipar.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid UserName/Password,Please try again..");
                    }

                }
                else
                {
                    MessageBox.Show("Invalid UserName/Pwd..");
                }


            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        public void LoginMethodWithValidation()
        {
            try
            {

                string UserName = string.Empty;
                string StrExeVersion = string.Empty;
                DataTable dtVersion = new DataTable();
                string SrtAlreadyLoginValidation = string.Empty;
                DataTable dtAlreadyLogin = new DataTable();
                string StrAlreadyLoginValidation_1 = string.Empty;
                DataTable dtAlreadyLogin_1 = new DataTable();
                string StrIdBlock = string.Empty;
                DataTable dtIdBlock = new DataTable();
                string StrExpiryDate = string.Empty;
                DataTable dtExpiryDate = new DataTable();


                if (MachineName != string.Empty)
                {
                  
                    StrExeVersion = "select * from vu_admin_exe_control  where VTE_EXE_NAME = '" + VerSion + "' and VTE_DT_CODE = '" + ExpDate + "'";
                    
                    dtVersion = clsMain.GetData(StrExeVersion);
                    if (dtVersion.Rows.Count < 0)
                    {
                        MessageBox.Show("You are using Invalid EXE, please contract your Application Admiministrator..");
                        return;
                    }
              
                    SrtAlreadyLoginValidation = "Select * from VU_Admin_UserInfo  where sysname='" + MachineName + "'  and LOGIN='Y'  and USER_NAME='"+txtUserName.Text.Trim()+"'";
                    dtAlreadyLogin = clsMain.GetData(SrtAlreadyLoginValidation);
                    if (dtAlreadyLogin.Rows.Count > 0)
                    {
                        MessageBox.Show("USER ALREADY LOGIN ON THE SAME USER ID...");
                        return;
                    }
                   
                    StrAlreadyLoginValidation_1 = "Select * from VU_Admin_UserInfo  where USER_NAME='" + txtUserName.Text.Trim() + "'  and LOGIN='Y'";
                    dtAlreadyLogin_1 = clsMain.GetData(StrAlreadyLoginValidation_1);
                    if (dtAlreadyLogin_1.Rows.Count > 0)
                    {
                        UserName = dtAlreadyLogin_1.Rows[0]["USER_NAME"].ToString();
                        if (UserName != "SANJAY")
                            if (dtAlreadyLogin_1.Rows.Count > 0)
                            {
                                MessageBox.Show("USER ALREADY LOGGED in....");
                                return;
                            }
                    }
              
                    StrIdBlock = "Select * from VU_Admin_UserInfo  where USER_NAME='" + txtUserName.Text.Trim() + "'  and BLOCK='Y'";
                    dtIdBlock = clsMain.GetData(StrIdBlock);
                    if (dtIdBlock.Rows.Count > 0)
                    {
                        MessageBox.Show("Your ID Has Been Blocked, Please Contact Admin..");
                        return;
                    }
             
                    string Pwd = string.Empty;
                    Pwd = clsMain.Encrypt(txtPwd.Text);
                    StrExpiryDate = "select * from VU_Admin_UserInfo where USER_NAME='" + txtUserName.Text.Trim() + "'and PASSWORD='" + Pwd + "' AND LOGIN='N' AND BLOCK='N'";
                    dtExpiryDate = clsMain.GetData(StrExpiryDate);
                    if (dtExpiryDate.Rows.Count > 0)
                    {
                        DateTime ExpiryDate = Convert.ToDateTime(dtExpiryDate.Rows[0]["EXPDT"].ToString());
                        UserName = dtExpiryDate.Rows[0]["USER_NAME"].ToString();
                        int Nodays = Datediff(CurrentDate, ExpiryDate);
                        if (Nodays < 0)
                        {                         
                           
                            if (Nodays >= 0 && Nodays <= 5)
                            {
                                MessageBox.Show("Your password will be expired within" + Nodays +  " days");
                            }
                        }
                        else
                        {
                            LoginMethod();
                        }
                    }
                    else
                    {
                        LoginMethod();
                    }

                }




            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
       
        public int Datediff(DateTime CurrentDate, DateTime ExpiryDate)
        {
            double Days = 0.0;
            int No_of_Days = 0;
            try
            {
                Days = (ExpiryDate - CurrentDate).TotalDays;
                No_of_Days = Convert.ToInt32(Days);
            }
            catch (Exception)
            {

                throw;
            }
            return No_of_Days;
        }
        private void Login_Load(object sender, EventArgs e)
        {
            txtPwd.Text = "";
            txtPwd.PasswordChar = '*';
            txtPwd.MaxLength = 10;

        }

        private void btnLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin.PerformClick();
            }

        }

        private void txtPwd_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtPwd_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void txtPwd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btnLogin.PerformClick();
            }

        }

        private void txtPwd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin.PerformClick();
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
