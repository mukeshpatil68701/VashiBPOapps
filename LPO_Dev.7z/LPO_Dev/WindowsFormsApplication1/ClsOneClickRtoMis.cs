﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.Odbc;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Data.OleDb;
using System.Drawing;
using Excel = Microsoft.Office.Interop.Excel;
using System.Globalization;

namespace LPO_Dev
{
   static class ClsOneClickRtoMis
    {

        public static string pServer;
        public static string pDataBase;
        public static string pUid;
        public static string pPwd;
        public static string max_connetion;
        public static OdbcConnection con;
        public static string ConnStr;
        public static OleDbConnection conExcel = new OleDbConnection();


        public static string strGlbFileName = string.Empty;
        public static string strGlbBatchID = string.Empty;

        public static string strGlbPath = @"C:\Output";
        public const string const_strReportTable = "LPO_trnReportTbl";


        public static string strGlbUploadTbl = string.Empty;
        public static string strGlbUploadSuccess = string.Empty;
        public static string strGlbUploadFailed = string.Empty;
        public static string strGlbCol = string.Empty;
        public static string strGlbTemplateName = string.Empty;
        public static ArrayList alSpList = new ArrayList();

        public static Hashtable htGlbColTyp = new Hashtable();
        public static int iGlbRegNo = 0;


        public static string strGlbAppstartID = string.Empty;
        /// <summary>
        /// Connects to MySQL server
        /// </summary>
        /// <returns></returns>
        public static bool Connect()
        {
            bool OpenCon = false;
            try
            {
                pServer = ConfigurationManager.AppSettings["Server"].ToString();
                pDataBase = ConfigurationManager.AppSettings["DataBase"].ToString();
                pUid = ConfigurationManager.AppSettings["Uid"].ToString();
                pPwd = ConfigurationManager.AppSettings["Pwd"].ToString();
                max_connetion = ConfigurationManager.AppSettings["max_connection"].ToString();

                ConnStr = "DRIVER={MySQL ODBC 3.51 Driver}; SERVER=" + pServer + "; DATABASE=" + pDataBase + "; UID=" + pUid + "; PWD=" + pPwd + ";max_connections = " + max_connetion + ";";

                con = new OdbcConnection();

                if (con.State.ToString() == "Closed")
                {
                    con.ConnectionString = ConnStr;
                    con.ConnectionTimeout = 60000;
                    con.Open();
                    OpenCon = true;
                }
            }
            catch (Exception Ex)
            {
                OpenCon = false;
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
            return OpenCon;
        }

        public static DataTable GetData(string strQry)
        {
            DataTable dtGetData = new DataTable();
            try
            {
                //if (Connect() == true)
                //{
                OdbcCommand Com;
                Com = new OdbcCommand(strQry, con);
                dtGetData.Load(Com.ExecuteReader());
                return dtGetData;
                //}

            }
            catch (Exception Ex)
            {
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return null;
                //throw;
            }
            return dtGetData;
        }


        internal static void RtoMIsExcel(FrmoneClickRtoMis frmoneclickrtomis, DataTable dtCmb, string ProcessWise, string Fieldwise )
        {
            ComboBox cmbCntrl;
            
            DBHelper objdbhelper = new DBHelper();
            //string qry1, qry2, qry3,strqry;
            try
            {

               // dtCmb = objdbhelper.Select("Call sp_casestatusmis('" + temp + "','" + fromdate + "','" + Todate + "')", CommandType.StoredProcedure);
                DataTable dt = dtCmb;
                Excel.Application xlApp;
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "OneClickRtoMis" + DateTime.Now.ToShortDateString();

                xlWorkSheet.Range["A1:" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A1:" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Color = Color.Red;



                for (var i = 0; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[2, i + 1] = dt.Columns[i].ColumnName;
                }
                xlWorkSheet.Range["A2:" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Font.Bold = true;
                xlWorkSheet.Range["A2:" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Interior.Color = Color.Cyan;
                for (int i = 0; i <= dt.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dt.Columns.Count - 1; j++)
                    {
                        xlWorkSheet.Cells[i + 3, j + 1] = dt.Rows[i][j];
                        xlWorkSheet.Cells.Columns.AutoFit();
                    }
                }


                //   string path = @"C:\MIS\ One Click RTO MIS\" + ProcessWise + "\\" + Fieldwise;

                CultureInfo ci = new CultureInfo("en-US");
                var month = DateTime.Now.ToString("MMMM", ci);

                string path = @"C:\MIS\Daily Print MIS\" + string.Concat(DateTime.Now.Day, " ", month, " ", DateTime.Now.Year, "\\");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                string path1 = "OneClickRtoMis";
                xlWorkBook.SaveAs(path + path1);

              //  xlWorkBook.SaveAs(path + "OneClickRtoMis");
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show("OneClickRtoMis Exported Successfully ");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        internal static string GetExcelColumnName(int ColNo)
        {
            string columnName = string.Empty;
            int modulo;

            while (ColNo > 0)
            {
                modulo = (ColNo - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                ColNo = (int)((ColNo - modulo) / 26);
            }

            return columnName;
        }


    }
}
