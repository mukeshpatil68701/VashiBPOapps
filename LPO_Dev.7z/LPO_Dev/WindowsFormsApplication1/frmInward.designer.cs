﻿namespace LPO_Dev
{
    partial class frmInward
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtInwardImagePath = new System.Windows.Forms.TextBox();
            this.lblImagePath = new System.Windows.Forms.Label();
            this.filebrowserdialogue = new System.Windows.Forms.FolderBrowserDialog();
            this.btnGenStat = new System.Windows.Forms.Button();
            this.cmbTemplate = new System.Windows.Forms.ComboBox();
            this.lblTemplate = new System.Windows.Forms.Label();
            this.rbtpod = new System.Windows.Forms.RadioButton();
            this.rbtRTO = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.txtInwardExcelPath = new System.Windows.Forms.TextBox();
            this.lblExcelPath = new System.Windows.Forms.Label();
            this.openfileExel = new System.Windows.Forms.OpenFileDialog();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.BtnMIS = new System.Windows.Forms.Button();
            this.btnupload = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Rbtold = new System.Windows.Forms.RadioButton();
            this.RbtNew = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnClose.Location = new System.Drawing.Point(357, 183);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(77, 25);
            this.btnClose.TabIndex = 34;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnBrowse.Location = new System.Drawing.Point(418, 144);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(71, 23);
            this.btnBrowse.TabIndex = 33;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // txtInwardImagePath
            // 
            this.txtInwardImagePath.Location = new System.Drawing.Point(101, 144);
            this.txtInwardImagePath.Name = "txtInwardImagePath";
            this.txtInwardImagePath.Size = new System.Drawing.Size(296, 20);
            this.txtInwardImagePath.TabIndex = 32;
            // 
            // lblImagePath
            // 
            this.lblImagePath.AutoSize = true;
            this.lblImagePath.Location = new System.Drawing.Point(35, 147);
            this.lblImagePath.Name = "lblImagePath";
            this.lblImagePath.Size = new System.Drawing.Size(64, 13);
            this.lblImagePath.TabIndex = 31;
            this.lblImagePath.Text = "Image Path ";
            // 
            // btnGenStat
            // 
            this.btnGenStat.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnGenStat.Location = new System.Drawing.Point(101, 183);
            this.btnGenStat.Name = "btnGenStat";
            this.btnGenStat.Size = new System.Drawing.Size(80, 25);
            this.btnGenStat.TabIndex = 35;
            this.btnGenStat.Text = "Indexing";
            this.btnGenStat.UseVisualStyleBackColor = true;
            this.btnGenStat.Click += new System.EventHandler(this.btnGenStat_Click);
            // 
            // cmbTemplate
            // 
            this.cmbTemplate.FormattingEnabled = true;
            this.cmbTemplate.Location = new System.Drawing.Point(101, 75);
            this.cmbTemplate.Name = "cmbTemplate";
            this.cmbTemplate.Size = new System.Drawing.Size(159, 21);
            this.cmbTemplate.TabIndex = 37;
            // 
            // lblTemplate
            // 
            this.lblTemplate.AutoSize = true;
            this.lblTemplate.Location = new System.Drawing.Point(15, 79);
            this.lblTemplate.Name = "lblTemplate";
            this.lblTemplate.Size = new System.Drawing.Size(82, 13);
            this.lblTemplate.TabIndex = 36;
            this.lblTemplate.Text = "Template Name";
            // 
            // rbtpod
            // 
            this.rbtpod.AutoSize = true;
            this.rbtpod.Location = new System.Drawing.Point(275, 77);
            this.rbtpod.Name = "rbtpod";
            this.rbtpod.Size = new System.Drawing.Size(48, 17);
            this.rbtpod.TabIndex = 38;
            this.rbtpod.TabStop = true;
            this.rbtpod.Text = "POD";
            this.rbtpod.UseVisualStyleBackColor = true;
            this.rbtpod.CheckedChanged += new System.EventHandler(this.rbtpod_CheckedChanged);
            // 
            // rbtRTO
            // 
            this.rbtRTO.AutoSize = true;
            this.rbtRTO.Location = new System.Drawing.Point(339, 78);
            this.rbtRTO.Name = "rbtRTO";
            this.rbtRTO.Size = new System.Drawing.Size(48, 17);
            this.rbtRTO.TabIndex = 39;
            this.rbtRTO.TabStop = true;
            this.rbtRTO.Text = "RTO";
            this.rbtRTO.UseVisualStyleBackColor = true;
            this.rbtRTO.CheckedChanged += new System.EventHandler(this.rbtRTO_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(416, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(72, 23);
            this.button1.TabIndex = 42;
            this.button1.Text = "Browse";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtInwardExcelPath
            // 
            this.txtInwardExcelPath.Location = new System.Drawing.Point(101, 109);
            this.txtInwardExcelPath.Name = "txtInwardExcelPath";
            this.txtInwardExcelPath.Size = new System.Drawing.Size(296, 20);
            this.txtInwardExcelPath.TabIndex = 41;
            // 
            // lblExcelPath
            // 
            this.lblExcelPath.AutoSize = true;
            this.lblExcelPath.Location = new System.Drawing.Point(37, 113);
            this.lblExcelPath.Name = "lblExcelPath";
            this.lblExcelPath.Size = new System.Drawing.Size(61, 13);
            this.lblExcelPath.TabIndex = 40;
            this.lblExcelPath.Text = "Excel Path:";
            // 
            // openfileExel
            // 
            this.openfileExel.FileName = "openFileDialog1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(457, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(42, 31);
            this.pictureBox1.TabIndex = 43;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(505, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(41, 31);
            this.pictureBox2.TabIndex = 44;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // BtnMIS
            // 
            this.BtnMIS.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.BtnMIS.Location = new System.Drawing.Point(187, 183);
            this.BtnMIS.Name = "BtnMIS";
            this.BtnMIS.Size = new System.Drawing.Size(83, 25);
            this.BtnMIS.TabIndex = 45;
            this.BtnMIS.Text = "MIS";
            this.BtnMIS.UseVisualStyleBackColor = true;
            this.BtnMIS.Click += new System.EventHandler(this.BtnMIS_Click);
            // 
            // btnupload
            // 
            this.btnupload.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold);
            this.btnupload.Location = new System.Drawing.Point(274, 183);
            this.btnupload.Name = "btnupload";
            this.btnupload.Size = new System.Drawing.Size(77, 25);
            this.btnupload.TabIndex = 46;
            this.btnupload.Text = "Upload";
            this.btnupload.UseVisualStyleBackColor = true;
            this.btnupload.Click += new System.EventHandler(this.btnupload_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Rbtold);
            this.groupBox1.Controls.Add(this.RbtNew);
            this.groupBox1.Location = new System.Drawing.Point(18, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(163, 45);
            this.groupBox1.TabIndex = 47;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Process";
            // 
            // Rbtold
            // 
            this.Rbtold.AutoSize = true;
            this.Rbtold.Location = new System.Drawing.Point(93, 22);
            this.Rbtold.Name = "Rbtold";
            this.Rbtold.Size = new System.Drawing.Size(41, 17);
            this.Rbtold.TabIndex = 41;
            this.Rbtold.TabStop = true;
            this.Rbtold.Text = "Old";
            this.Rbtold.UseVisualStyleBackColor = true;
            this.Rbtold.CheckedChanged += new System.EventHandler(this.Rbtold_CheckedChanged);
            // 
            // RbtNew
            // 
            this.RbtNew.AutoSize = true;
            this.RbtNew.Location = new System.Drawing.Point(29, 21);
            this.RbtNew.Name = "RbtNew";
            this.RbtNew.Size = new System.Drawing.Size(47, 17);
            this.RbtNew.TabIndex = 40;
            this.RbtNew.TabStop = true;
            this.RbtNew.Text = "New";
            this.RbtNew.UseVisualStyleBackColor = true;
            this.RbtNew.CheckedChanged += new System.EventHandler(this.RbtNew_CheckedChanged);
            // 
            // frmInward
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 242);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnupload);
            this.Controls.Add(this.BtnMIS);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtInwardExcelPath);
            this.Controls.Add(this.lblExcelPath);
            this.Controls.Add(this.rbtRTO);
            this.Controls.Add(this.rbtpod);
            this.Controls.Add(this.cmbTemplate);
            this.Controls.Add(this.lblTemplate);
            this.Controls.Add(this.btnGenStat);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtInwardImagePath);
            this.Controls.Add(this.lblImagePath);
            this.Name = "frmInward";
            this.Text = "frmInward";
            this.Load += new System.EventHandler(this.frmInward_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtInwardImagePath;
        private System.Windows.Forms.Label lblImagePath;
        private System.Windows.Forms.FolderBrowserDialog filebrowserdialogue;
        private System.Windows.Forms.Button btnGenStat;
        private System.Windows.Forms.ComboBox cmbTemplate;
        private System.Windows.Forms.Label lblTemplate;
        private System.Windows.Forms.RadioButton rbtpod;
        private System.Windows.Forms.RadioButton rbtRTO;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtInwardExcelPath;
        private System.Windows.Forms.Label lblExcelPath;
        private System.Windows.Forms.OpenFileDialog openfileExel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button BtnMIS;
        private System.Windows.Forms.Button btnupload;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Rbtold;
        private System.Windows.Forms.RadioButton RbtNew;
    }
}