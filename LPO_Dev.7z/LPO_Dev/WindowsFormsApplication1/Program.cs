﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
          //  Application.Run(new frmUpload());
            //Application.Run(new RejectionData());
            //Application.Run(new FrmDailyPrintMis());
            //Application.Run(new FrmCaseStatusMIS());
            Application.Run(new Login());
            //Application.Run(new frmInward());
        }
    }
}
