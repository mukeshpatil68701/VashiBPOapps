﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.Odbc;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Configuration;
using System.Security.Cryptography;


namespace LPO_Dev
{

    public static class clsMain
    {
        public static string pServer;
        public static string pDataBase;
        public static string pUid;
        public static string pPwd;
        public static string ConnStr;
        public static string max_connetion;
        public static OdbcConnection con;
        public static string pUserName = "DILIPK";
        public static string pLocation;
        public static string pClient;

        public static string pApplicationName = string.Empty;
        public static string pApplicationTitle = string.Empty;
        public static string pApplicationSubTitle = string.Empty;
        public static string pStrUATDatabase = string.Empty;
        public static string pStrLiveDatabase = string.Empty;
        public static string pLoginText = string.Empty;
        public static string pImgPath = string.Empty;
        public static string pUserType;
        public static string pIsManualAllocation;
        public static string pCheckerMaker;
        public static string pAuditPercent;
        public static string pBatchName;
        public static bool lastLogin;
   
        public static bool Connect()
        {
            bool OpenCon = false;
           try
            {
                pServer = System.Configuration.ConfigurationSettings.AppSettings["Server"].ToString();
                pDataBase = System.Configuration.ConfigurationSettings.AppSettings["DataBase"].ToString();
                pUid = System.Configuration.ConfigurationSettings.AppSettings["Uid"].ToString();
                pPwd = System.Configuration.ConfigurationSettings.AppSettings["Pwd"].ToString();
                max_connetion = System.Configuration.ConfigurationSettings.AppSettings["max_connection"].ToString();

                ConnStr = "DRIVER={MySQL ODBC 3.51 Driver}; SERVER=" + pServer + "; DATABASE=" + pDataBase + "; UID=" + pUid + "; PWD=" + pPwd + ";max_connections = "+ max_connetion + ";";

                con = new OdbcConnection();

                //if (string.IsNullOrEmpty(con.ConnectionString))
                //{
               
                //}

                if (con.State == 0)
                {
                    con.ConnectionString = ConnStr;
                    con.ConnectionTimeout = 2000;
                    con.Open();
                    OpenCon = true;
                }
            }
            catch (Exception Ex)
            {
                OpenCon = false;
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
            return OpenCon;
        }

        public static DataTable GetData(string qstr)
        {
            DataTable dt = new DataTable();
            try
            {
               
                if (Connect() == true)
                {

                    OdbcCommand Com;
                    OdbcDataAdapter Da;

                    Com = new OdbcCommand(qstr, con);
                    Da = new OdbcDataAdapter(Com);
                    Da.Fill(dt);
                }

                
            }
            catch (Exception Ex)
            {
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return null;
                throw;
            }
            return dt;
        }

        public static bool SetData(string str)
        {
            try
            {
                if (Connect() == true)
                {
                    OdbcCommand Com;
                    Com = new OdbcCommand(str, con);
                    Com.ExecuteNonQuery();
                }
                return true;
            }
            catch(Exception Ex)
            {
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return false;
            }
            con.Close();
        }
        public static bool ExcuteDML(string str)
        {
            try
            {
                if (Connect() == true)
                {
                    OdbcCommand Com;
                    Com = new OdbcCommand(str, con);
                    Com.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception Ex)
            {
                con.Close();
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
                return false;
               
            }
            con.Close();

        }
            

       

       
     

        
        public static string Encrypt(string clearText)
        {
            string EncryptionKey = "abc123";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        public static string Decrypt(string cipherText)
        {
            string EncryptionKey = "abc123";
            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
        public static ComboBox Bind_Combo(ComboBox Combbox, DataTable dt, string Text, string Value)
        {
            OdbcCommand cmd;
            OdbcDataAdapter da;
            try
            {
                Combbox.DataSource = dt;
                Combbox.DisplayMember = Text;
                Combbox.ValueMember = Value;
                //  Combbox.Items.Insert(0, "--Select--");
                //  Combbox.SelectedIndex = 0;

            }
            catch (Exception ex)
            {

            }

            return Combbox;

        }
    }
}
