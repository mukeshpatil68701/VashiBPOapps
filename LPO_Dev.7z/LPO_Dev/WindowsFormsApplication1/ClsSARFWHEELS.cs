﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LPO_Dev
{

    static class ClsSARFWHEELS
    {
        public const string const_strReportTable = "LPO_trnReportTbl";
        public static string strGlbPath = @"C:\Output";
        public static int icntTest = 0;
        static int iGlbRegNo = 0;
        public static Hashtable htGlbColTyp = new Hashtable();
        public static Hashtable htGlbVPNCustomer = new Hashtable();
        static string DispatchMode = string.Empty;
        static string strGlbTemplateName = string.Empty;
        static string strGlbUploadTbl = string.Empty;
        static string strGlbUploadSuccess = string.Empty;
        static string strGlbAppstartID = string.Empty;
        static string strGlbCol = string.Empty;
        static string strGlbFileName = string.Empty;
        static string strGlbBatchID = string.Empty;
        static string strGlbOutputPathBulk = string.Empty;
        static string strInputFilePath = string.Empty;
        static string strBulkRegister = string.Empty;
        static string strReport = string.Empty;
        static string strSticker = string.Empty;
        static string strGlbUploadFailed = string.Empty;
        static string strGlbTemplateLocation = string.Empty;
        public static string stRTemplateLocation = string.Empty;

        internal static void ProcessExcel(int iTempIndex, string strDispatchMode, string strPath)
        {
            DataTable dtExcelData = new DataTable();
            DispatchMode = strDispatchMode;
            try
            {

                int iExcelColCount = ClsGlobal.getExcelColcnt(iTempIndex);
                dtExcelData = ClsGlobal.getExcelData();
                int idtExcelCnt = dtExcelData.Columns.Count;
                strInputFilePath = strPath;
                if (iExcelColCount != idtExcelCnt)
                {
                    MessageBox.Show("File format not correct");
                    ClsGlobal.conExcel.Close();
                    return;
                }
                strGlbFileName = ClsGlobal.strGlbFileName;
                generateAppStart();
                if (dtExcelData.Rows.Count > 0)
                {
                    FnUploadData(iTempIndex, dtExcelData);
                    ClsGlobal.conExcel.Close();

                }


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        internal static void generateAppStart()
        {
            DataTable dtFileUploadLog = new DataTable();
            string strUploadDate = string.Empty;
            string strBatchId = string.Empty;
            string strNumberofRecords = string.Empty;
            string strApp = string.Empty;
            try
            {
                string strAppStartQry = "select FileName, UploadDate, BatchId, AppStartNo,NumberofRecords" +
                     " from vu_fileuploadlog order by ID desc limit 1;";
                dtFileUploadLog = ClsGlobal.GetData(strAppStartQry);
                if (dtFileUploadLog.Rows.Count > 0)
                {
                    foreach (DataRow row in dtFileUploadLog.Rows)
                    {
                        strUploadDate = row["UploadDate"].ToString();
                        strBatchId = row["BatchId"].ToString();
                        strNumberofRecords = row["NumberofRecords"].ToString();
                        strApp = row["AppStartNo"].ToString();
                    }

                    DateTime dtUpload = Convert.ToDateTime(strUploadDate);
                    DateTime dtToday = DateTime.Now;

                    if (dtToday.Date > dtUpload.Date)
                    {
                        string strYr = DateTime.Now.Year.ToString();
                        string strDay = DateTime.Now.DayOfYear.ToString();
                        const string const_strAppNo = "0000001";

                        if (strDay.Length == 2)
                        {
                            strDay = "0" + strDay;
                        }
                        else if (strDay.Length == 1)
                        {
                            strDay = "00" + strDay;
                        }
                        strGlbAppstartID = strYr + strDay + const_strAppNo;
                        int iBatch = 1;
                        strGlbBatchID = iBatch.ToString();

                        return;
                    }
                    else
                    {
                        double iBatch = Convert.ToDouble(strBatchId) + 1;
                        strGlbBatchID = iBatch.ToString();
                        strGlbAppstartID = strApp;
                    }
                }


                else
                {
                    string strYr = DateTime.Now.Year.ToString();
                    string strDay = DateTime.Now.DayOfYear.ToString();
                    const string const_strAppNo = "0000001";

                    if (strDay.Length == 2)
                    {
                        strDay = "0" + strDay;
                    }
                    else if (strDay.Length == 1)
                    {
                        strDay = "00" + strDay;
                    }
                    strGlbAppstartID = strYr + strDay + const_strAppNo;
                    strGlbBatchID = "1";
                }



            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void FnUploadData(int iTempIndex, DataTable dtExcelData)
        {
            DataTable dtTables = new DataTable();

            try
            {

                int iRowCont = dtExcelData.Rows.Count;
                strGlbTemplateName = string.Empty;


                string strGetTableQry = "select TemplateName, UploadTableName, UploadTableNameSuccess, " +
                "UploadTableNameFailed, TemplateID, CurRegNo, RegNoTO from lpo_templatemaster where TemplateID = " + iTempIndex.ToString();
                dtTables = ClsGlobal.GetData(strGetTableQry);
                if (dtTables.Rows.Count > 0)
                {
                    foreach (DataRow row in dtTables.Rows)
                    {
                        strGlbTemplateName = row["TemplateName"].ToString();
                        iGlbRegNo = Convert.ToInt32(row["CurRegNo"]);
                        strGlbUploadTbl = row["UploadTableName"].ToString();
                        InsertIntoUploadtbl(iTempIndex, strGlbUploadTbl, dtExcelData);
                        strGlbUploadSuccess = row["UploadTableNameSuccess"].ToString();


                        string strDisp = string.Empty;
                        DataTable dtDispMode = new DataTable();
                        string strCondition = string.Empty;
                        DataTable dtCondition = new DataTable();
                        string strValidation = "select validation from lpo_templatemaster where TemplateId = " + iTempIndex.ToString();
                        dtCondition = ClsGlobal.GetData(strValidation);
                        if (dtCondition.Rows.Count > 0)
                        {
                            strCondition = dtCondition.Rows[0]["validation"].ToString();
                        }
                        strDisp = "select " + strGlbCol + " from " + strGlbUploadTbl + " where  " + strCondition + " and VU_DispatchMode = 'SP' ";
                        dtDispMode = ClsGlobal.GetData(strDisp);
                        if (dtDispMode.Rows.Count > 0)
                        {
                            InsertIntoSuccess(iTempIndex, strGlbUploadSuccess, dtDispMode);

                        }
                        strGlbUploadFailed = row["UploadTableNameFailed"].ToString();
                        InsertIntoFailedtbl(iTempIndex, strGlbUploadFailed);
                        string strUpdateRegNo = "update lpo_templatemaster set curRegNo = " + iGlbRegNo.ToString() + " where TemplateId = " + iTempIndex.ToString();
                        ClsGlobal.ExcuteDML(strUpdateRegNo);
                        UpdateLogFile(ClsGlobal.strGlbFileName, strGlbAppstartID, strGlbBatchID, strGlbTemplateName, 0);
                        MessageBox.Show("File uploaded Successfully!");

                        CreateFolderStructure(strGlbPath);
                        InsertIntoAnnexrtTable("lpo_trnannexrpttbl");
                        bulkRegister(strGlbTemplateName);

                    }
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        public static void UpdateLogFile(string strGlbFileName, string strGlbAppstartID, string strGlbBatchID, string strGlbTemplateName, int iRowCont)
        {
            try
            {
                string strUpdateFileLog = "Insert into vu_fileuploadlog (FileName, " +
                " UploadDate, BatchId, AppStartNo,NumberofRecords,TemplateName) Values ('" +
                 strGlbFileName + "','" + DateTime.Now.ToShortDateString() + "','" + strGlbBatchID + "','" + strGlbAppstartID + "','" +
                  iRowCont.ToString() + "','" + strGlbTemplateName + "')";

                ClsGlobal.ExcuteDML(strUpdateFileLog);
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void InsertIntoSuccess(int iTempIndex, string strUploadSuccess, DataTable dtDispMode)
        {
            string testCol = "";
            htGlbVPNCustomer = new Hashtable();
            DataTable dtCondition = new DataTable();
            string strCondition = string.Empty;
            StringBuilder sbValues = new StringBuilder();
            Hashtable ht138ECSLanCheck = new Hashtable();
            Hashtable htRegNoCheck = new Hashtable();
            Hashtable ht138ECSNumCheck = new Hashtable();
            Hashtable ht138ECSRegNoCheck = new Hashtable();

            double dAppstart = Convert.ToDouble(strGlbAppstartID);
            double dAppLocal = Convert.ToDouble(strGlbAppstartID);
            double dRegNoLocal = Convert.ToDouble(iGlbRegNo);
            double dRegNostart = Convert.ToDouble(iGlbRegNo);

            string strColTest = string.Empty;

            Hashtable htLocal = new Hashtable();
            Hashtable htRegNoMapping = new Hashtable();


            string strRptTbl = "Truncate " + const_strReportTable;
            string strInsQry = "Insert into " + strUploadSuccess + "( " + strGlbCol + ") Values (";

            try
            {

                foreach (DataRow dRow in dtDispMode.Rows)
                {

                    ArrayList alApplicants = new ArrayList();
                    bool bExecute = true;
                    foreach (DataColumn col in dtDispMode.Columns)
                    {
                        icntTest++;
                        //itest++;
                        bool bDate = false;
                        bool bLan = false;
                        string strColName = col.ColumnName;

                        strColTest = strColName;


                        string strColType = htGlbColTyp[strColName].ToString();
                        testCol = strColName;
                        //Add  by Preeti
                        #region SARF WHEELS
                        if (strColName == "VU_MasterID" && strGlbTemplateName == "SARF13_2_WHEELS")
                        {
                            if (dRow["VU_ApplicantName"].ToString().Trim() != "")
                            {
                                alApplicants.Add(dRow["VU_ApplicantName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }
                                if (!htRegNoMapping.Contains(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }


                            }
                            if (dRow["VU_CoApplicantName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_CoApplicantName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }

                                if (!htRegNoMapping.Contains(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }


                            if (dRow["VU_GurName"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_GurName"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }
                                if (!htRegNoMapping.Contains(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }

                            if (dRow["VU_OTHER_NAME"].ToString() != "")
                            {
                                alApplicants.Add(dRow["VU_OTHER_NAME"].ToString().Trim());
                                if (!htLocal.Contains(dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htLocal.Add(dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dAppLocal.ToString());
                                    dAppLocal += 1;
                                }
                                if (!htRegNoMapping.Contains(dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    htRegNoMapping.Add(dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim(), dRegNoLocal.ToString());
                                    dRegNoLocal += 1;
                                }

                            }
                            if (!htGlbVPNCustomer.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," +
                                 dRow["VU_OTHER_NAME"] + "," + dRow["VU_LanNo"]))
                            {
                                htGlbVPNCustomer.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," +
                                 dRow["VU_OTHER_NAME"] + "," + dRow["VU_LanNo"], dAppstart.ToString());

                                sbValues.Append("'" + dAppstart.ToString() + "',");
                                //dAppstart += 1;                                
                                continue;

                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;

                            }

                        }
                        #endregion
                        //Add by preeti
                        else if (strColName == "VU_REGNO" && strGlbTemplateName == "SARF13_2_WHEELS")
                        {
                            if (!htRegNoCheck.Contains(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," + dRow["VU_OTHER_NAME"]))
                            {
                                htRegNoCheck.Add(dRow["VU_ApplicantName"] + "," + dRow["VU_CoApplicantName"] + "," + dRow["VU_GurName"] + "," +
                                                            dRow["VU_OTHER_NAME"] + "," + dRow["VU_LanNo"], dRegNostart.ToString());

                                sbValues.Append("'" + dRegNostart.ToString() + "',");
                                continue;
                            }
                            else
                            {

                            }
                        }
                        else if (strColType == "Date")
                        {
                            bDate = ClsValidations.DateValidate(dRow[strColName].ToString(), strGlbTemplateName);
                            if (bDate)
                            {
                                sbValues.Append("'" + dRow[strColName].ToString() + "',");
                                continue;
                            }
                            else
                            {
                                bExecute = false;
                                sbValues.Clear();
                                break;
                            }
                        }
                        //else if (strColType == "LANMASK")
                        //{
                        //    if (strGlbTemplateName == "SARF13_2_WHEELS")
                        //    {
                        //        sbValues.Append("'',");
                        //        continue;
                        //    }
                        //    string strLanMask = dRow["VU_LanNo"].ToString();
                        //    if (Regex.IsMatch(strLanMask, @"^[0-9]") && strLanMask.Length > 12)
                        //    {
                        //        string strLanReplace = Regex.Replace(strLanMask.Substring(3, strLanMask.Length - 7), ".", "X");
                        //        string strFinalLan = strLanMask.Substring(0, 4) +
                        //            strLanReplace.Substring(1, strLanReplace.Length - 1) + strLanMask.Substring(strLanMask.Length - 4);
                        //        sbValues.Append("'" + strFinalLan + "',");

                        //    }

                        //    else
                        //    {
                        //        sbValues.Append("'" + strLanMask + "',");
                        //    }

                        //}

                        else
                        {
                            sbValues.Append("'" + dRow[strColName].ToString() + "',");
                        }


                    }
                    if (bExecute)
                    {



                        string strMasterID = string.Empty;
                        string strRegNoNew = string.Empty;

                        string strInsert = strInsQry + sbValues.ToString();


                        strInsert = strInsert.Remove(strInsert.LastIndexOf(","));
                        strInsert += ")";

                        string strAppp = dAppstart.ToString();
                        string strRegNo = dRegNostart.ToString();
                        int iRegUpload = 0;

                        #region SARF WHEELS Upload logic

                        if (strGlbTemplateName == "SARF13_2_WHEELS")
                        {
                            string strDeletermp;
                            if (alApplicants.Count == 1)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    iGlbRegNo++;

                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);
                                    ClsGlobal.ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = iGlbRegNo.ToString();

                                }
                            }
                            if (alApplicants.Count == 2)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    ClsGlobal.ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }
                                else
                                {

                                }
                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");


                                    ClsGlobal.ExcuteDML(strInsert);

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString()].ToString(), strApppReplace);
                                    ClsGlobal.ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;
                                }

                                if (htLocal.ContainsKey(dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[3].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString()].ToString(), strApppReplace);
                                    ClsGlobal.ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }
                                else
                                {

                                }
                            }

                            if (alApplicants.Count == 3)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString()))
                                {

                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ClsGlobal.ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;


                                }
                                else
                                {

                                }
                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");

                                    ClsGlobal.ExcuteDML(strInsert);

                                    strAppp = htLocal[dRow["VU_CoApplicantName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }
                                else
                                {

                                }
                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString()+","+alApplicants[1].ToString() + "','dummy'", alApplicants[0].ToString()+","+alApplicants[2].ToString() + "','dummy'");

                                    ClsGlobal.ExcuteDML(strInsert);

                                    strAppp = htLocal[dRow["VU_GurName"].ToString().Trim()+"," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_GurName"].ToString().Trim()+"," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }


                                if (htLocal.ContainsKey(dRow["VU_OTHER_NAME"].ToString().Trim()+"," + dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_OTHER_NAME"].ToString().Trim()+"," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strInsert = strInsert.Replace(alApplicants[0].ToString()+","+alApplicants[2].ToString() + "','dummy'", alApplicants[0].ToString()+","+alApplicants[3].ToString() + "','dummy'");

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_OTHER_NAME"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(htLocal[dRow["VU_OTHER_NAME"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString(), strApppReplace);
                                    ClsGlobal.ExcuteDML(strInsert);



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }
                                else
                                {

                                }
                            }

                            if (alApplicants.Count == 4)
                            {

                                if (htLocal.ContainsKey(dRow["VU_ApplicantName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()))
                                {

                                    iRegUpload++;
                                    string strApppReplace = htLocal[dRow["VU_ApplicantName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace("TestMapping','dummy'", alApplicants[0].ToString()+","+ alApplicants[0].ToString() + "','dummy'");


                                    string strRegNoReplace = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    ClsGlobal.ExcuteDML(strInsert);
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);


                                    strAppp = htLocal[dRow["VU_ApplicantName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_ApplicantName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()].ToString();



                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;


                                }
                                else
                                {

                                }


                                if (htLocal.ContainsKey(dRow["VU_CoApplicantName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[0].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'");

                                    ClsGlobal.ExcuteDML(strInsert);

                                    strAppp = htLocal[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_CoApplicantName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }
                                else
                                {

                                }

                                if (htLocal.ContainsKey(dRow["VU_GurName"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[1].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'");

                                    ClsGlobal.ExcuteDML(strInsert);

                                    strAppp = htLocal[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_GurName"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }


                                if (htLocal.ContainsKey(dRow["VU_OTHER_NAME"].ToString().Trim()+","+ dRow["VU_ApplicantName"].ToString().Trim()))
                                {
                                    iRegUpload++;
                                    strDeletermp = "Delete from " + strGlbUploadTbl + " where VU_MasterID = '" + dRow["VU_MasterID"].ToString() + "';";
                                    ClsGlobal.ExcuteDML(strDeletermp);
                                    string strApppReplace = htLocal[dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    string strRegNoReplace = htRegNoMapping[dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strInsert = strInsert.Replace(strRegNo, strRegNoReplace);

                                    strInsert = strInsert.Replace(strAppp, strApppReplace);
                                    strInsert = strInsert.Replace(alApplicants[0].ToString() + "," + alApplicants[2].ToString() + "','dummy'", alApplicants[0].ToString() + "," + alApplicants[3].ToString() + "','dummy'");

                                    ClsGlobal.ExcuteDML(strInsert);

                                    strAppp = htLocal[dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();
                                    strRegNo = htRegNoMapping[dRow["VU_OTHER_NAME"].ToString().Trim() + "," + dRow["VU_ApplicantName"].ToString().Trim()].ToString();

                                    strMasterID = strApppReplace;
                                    strRegNoNew = strRegNoReplace;

                                }
                                else
                                {

                                }
                            }
                            if (strGlbTemplateName == "SARF13_2_WHEELS")
                            {
                                strGlbAppstartID = strMasterID;
                                iGlbRegNo = Convert.ToInt32(strRegNoNew);
                            }
                            if (strGlbTemplateName == "SARF13_2_WHEELS")
                            {
                                string strUpdateLoanCard = "Update lpo_trnsuccess set VU_LoanorCard = 'LOAN' where " +
                                    " VU_TemplateName = '" + strGlbTemplateName +
                                    "' AND VU_FileName = '" + strGlbFileName + "';";
                                ClsGlobal.ExcuteDML(strUpdateLoanCard);
                            }

                        }
                        #endregion
                    }
                    sbValues.Clear();
                    alApplicants.Clear();

                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message + "  " + icntTest.ToString());
            }
        }
        private static void InsertIntoUploadtbl(int iTempIndex, string strUploadTbl, DataTable dtExcelData)
        {
            DataTable dtCol = new DataTable();
            StringBuilder sbCol = new StringBuilder();
            StringBuilder sbValues = new StringBuilder();
            int iColCnt = dtExcelData.Columns.Count;
            double dAppstart = Convert.ToDouble(strGlbAppstartID);
            strGlbCol = string.Empty;
            htGlbColTyp = new Hashtable();
            try
            {
                string strTruncate = "TRUNCATE TABLE " + strUploadTbl;
                ClsGlobal.ExcuteDML(strTruncate);
                string strColQry = "select a.Col_ID,b.Col_ID,a.DB_ColName,b.ExcelColName, b.Type from lpo_genericcolmaster a  JOIN lpo_excelcolmappingmaster b " +
                                   "ON a.Col_ID = b.Col_ID and b.TemplateID = " + iTempIndex.ToString() + " order by b.ExcelSquenceId;";
                dtCol = ClsGlobal.GetData(strColQry);
                if (dtCol.Rows.Count > 0)
                {
                    foreach (DataRow row in dtCol.Rows)
                    {
                        if (!htGlbColTyp.Contains(row["DB_ColName"]))
                        {
                            htGlbColTyp.Add(row["DB_ColName"].ToString(), row["Type"].ToString());
                        }
                        sbCol.Append(row["DB_ColName"].ToString() + ",");
                    }
                }

                strGlbCol = sbCol.ToString();
                strGlbCol = strGlbCol.Remove(strGlbCol.LastIndexOf(","));
                sbCol.Clear();
                string strInsQry = "Insert into " + strUploadTbl + "( " + strGlbCol + ") Values (";

                foreach (DataRow dRow in dtExcelData.Rows)
                {

                    for (int i = 0; i < iColCnt; i++)
                    {

                        string strRepSingleQuote = dRow[i].ToString();
                        strRepSingleQuote = strRepSingleQuote.Replace("'", "");
                        sbValues.Append("'" + strRepSingleQuote + "',");
                    }


                    sbValues.Append("'" + strGlbFileName + "',");
                    sbValues.Append("'" + dAppstart.ToString() + "',");


                    sbValues.Append("'RegNo',");
                    sbValues.Append("'" + strGlbBatchID + "',");
                    sbValues.Append("'" + DispatchMode + "',");
                    sbValues.Append("'" + strGlbTemplateName + "',");
                    sbValues.Append("'" + DateTime.Now.ToShortDateString() + "',");
                    sbValues.Append("'N',");
                    sbValues.Append("'TestMapping',");
                    sbValues.Append("'dummy',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'',");
                    sbValues.Append("'')");

                    dAppstart += 1;
                    string strInsert = strInsQry + sbValues.ToString();
                    sbValues.Clear();
                    ClsGlobal.ExcuteDML(strInsert);


                }



            }

            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void InsertIntoFailedtbl(int iTempIndex, string strUploadFailed)
        {
            try
            {
                double dAppstart = Convert.ToDouble(strGlbAppstartID);
                StringBuilder sbValues = new StringBuilder();
                DataTable dtUpload = new DataTable();
                string strSelectUpload = "Select " + strGlbCol + " From " + strGlbUploadTbl;
                dtUpload = ClsGlobal.GetData(strSelectUpload);
                string strInsQry = "Insert into " + strUploadFailed + "( " + strGlbCol + ") Values (";

                foreach (DataRow dRow in dtUpload.Rows)
                {
                    foreach (DataColumn col in dtUpload.Columns)
                    {
                        string strColName = col.ColumnName;

                        if (strColName == "VU_MasterID")
                        {
                            sbValues.Append("'" + dAppstart.ToString() + "',");
                            dAppstart += 1;
                            continue;
                        }
                        sbValues.Append("'" + dRow[strColName].ToString() + "',");

                    }

                    sbValues.Append(")");
                    string strInsert = strInsQry + sbValues.ToString();
                    strInsert = strInsert.Remove(strInsert.LastIndexOf(","), 1);
                    sbValues.Clear();
                    ClsGlobal.ExcuteDML(strInsert);

                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }

        private static void InsertIntoAnnexrtTable(string strAnxTbl)
        {
            try
            {
                string strInsertAnxtbl = "truncate " + strAnxTbl;
                ClsGlobal.ExcuteDML(strInsertAnxtbl);
                strInsertAnxtbl = "Insert into " + strAnxTbl + "( VU_LoanOrCard, VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                    ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                    ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                   " from " + strGlbUploadSuccess +
                    " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and concat(vu_ApplicantName,',',vu_ApplicantName)= VU_NAmeMapping )";

                ClsGlobal.ExcuteDML(strInsertAnxtbl);

                strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName,VU_RegNo, VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                    ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO,VU_TemplateName,VU_RegNo, VU_CoApplicantName, VU_CoAppAdd1, VU_CoAppAdd2 " +
                    ", VU_CoAppAdd3, VU_CoAppAdd4,VU_CoAppCity, VU_CoAppPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                   " from " + strGlbUploadSuccess +
                    " where VU_FileName = '" + strGlbFileName + "' " +
                                        "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                        "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_CoApplicantName <> '' and concat(vu_ApplicantName,',',VU_CoApplicantName)= VU_NAmeMapping  )";

                ClsGlobal.ExcuteDML(strInsertAnxtbl);


                strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                    ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_GurName, VU_GurAdd1, VU_GurAdd2 " +
                    ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                   " from " + strGlbUploadSuccess +
                    " where VU_FileName = '" + strGlbFileName + "' " +
                     "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                      "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_GurName <> ''  and concat(vu_ApplicantName,',',VU_GurName)=VU_NAmeMapping )";

                ClsGlobal.ExcuteDML(strInsertAnxtbl);


                strInsertAnxtbl = "Insert into " + strAnxTbl + "(VU_LoanOrCard,VU_dispatchMode, VU_BatchNO,VU_TemplateName, VU_RegNo,VU_ApplicantName, VU_AppAdd1, VU_AppAdd2 " +
                   ", VU_AppAdd3, VU_AppAdd4,VU_AppCity, VU_AppPincode, VU_LanNo, VU_Filename,VU_MasterID, VU_Same)" + "(select VU_LoanOrCard,VU_dispatchMode,VU_BatchNO, VU_TemplateName, VU_RegNo,VU_OTHER_NAME, VU_OTHER_CORREPONDANCE_ADD1, VU_OTHER_CORREPONDANCE_ADD2 " +
                   ", VU_GurAdd3, VU_GurAdd4,VU_GurCity, VU_GurPincode, VU_LanNo, VU_Filename,VU_MasterID,VU_ApplicantName " +
                  " from " + strGlbUploadSuccess +
                   " where VU_FileName = '" + strGlbFileName + "' " +
                    "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                     "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_OTHER_NAME <> ''  and concat(vu_ApplicantName,',',VU_OTHER_NAME)=VU_NAmeMapping )";

                ClsGlobal.ExcuteDML(strInsertAnxtbl);




            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void CreateFolderStructure(string strGlbPath)
        {
            try
            {

                String strDt = DateTime.Now.ToString("dd MMM yyyy");
                string strOutputPath = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt;
                string strInputFile = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Input";

                strBulkRegister = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "BulkRegister";
                strReport = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Report";
                strSticker = strGlbPath + "\\" + strGlbTemplateName + "\\" + strDt + "\\" + "Sticker";


                if (!Directory.Exists(strInputFile))
                {
                    Directory.CreateDirectory(strInputFile);

                }
                File.Copy(strInputFilePath, strInputFile + "\\" + strGlbFileName + ".xls", true);
                if (!Directory.Exists(strOutputPath))
                {
                    Directory.CreateDirectory(strOutputPath);
                }
                if (!Directory.Exists(strBulkRegister))
                {
                    Directory.CreateDirectory(strBulkRegister);
                }
                if (!Directory.Exists(strReport))
                {
                    Directory.CreateDirectory(strReport);
                }
                if (!Directory.Exists(strSticker))
                {
                    Directory.CreateDirectory(strSticker);
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void bulkRegister(string strGlbTemplateName)
        {
            DataTable dtBulk = new DataTable();
            string strReportcond = string.Empty;
            string strSetPrintFlag = string.Empty;
            try
            {


                bool bExecute = false;
                string serverRptPath = ClsGlobal.strGlbTemplateLocation + "CrRptSarfaesi12wheels.rpt";
                string serverStickerPath = ClsGlobal.strGlbTemplateLocation + "Sticker1.rpt";

                string strBulkREG = "select distinct IFNULL(concat(VU_TemplateName,'/', left(VU_MasterID, 7), '/', VU_REGNO, '/', VU_BatchNO, '/', VU_LanNo), '') AS ReferenceNo, " +
                                   "VU_REGNO as RegistrationNumber, VU_LanNo as LAN_Number, left(concat(left(IFNULL(VU_ApplicantName, ''), 100), ' , ', IFNULL(VU_AppAdd1, ''), ' , ', " +
                                   "IFNULL(VU_AppCity, '')), 200) as Name_And_Address," +
                                   "VU_AppPincode AS PinCode,VU_MasterID as MasterId from lpo_trnannexrpttbl " +
                                   "where  VU_LoanOrCard ='LOAN'  group by VU_MasterID  ORDER BY VU_MasterID;";

                strReportcond = " where VU_FileName = '" + strGlbFileName + "' " +
                                    "and VU_UploadDate = '" + DateTime.Now.ToShortDateString() + "' " +
                                    "and VU_IsPrinted = 'N' and VU_LoanOrCard ='LOAN' " +
                                    "and VU_TemplateName = '" + strGlbTemplateName + "' and VU_DispatchMode = 'SP' ";


                dtBulk = ClsGlobal.GetData(strBulkREG);
                if (dtBulk.Rows.Count > 0 && !bExecute)
                {
                    bExecute = true;
                    GenerateBulkExcel(strBulkRegister + "\\" + strGlbFileName + "_LOAN_SP_BulkRegister", dtBulk, "Speed Post");
                    dtBulk.Clear();
                    GenerateReport(strReportcond, strReport + "\\" + strGlbFileName + "_LOAN_SP.pdf", serverRptPath);
                    GenerateReport(strReportcond, strSticker + "\\" + strGlbFileName + "_LOAN_SP_Sticker.pdf", serverStickerPath);

                    strSetPrintFlag = "Update  " + strGlbUploadSuccess + " set VU_IsPrinted = 'Y' " + strReportcond;
                    ClsGlobal.ExcuteDML(strSetPrintFlag);
                }

            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void GenerateBulkExcel(string strGlbOutputPathBulk, DataTable dtBulk, string strDispMode)
        {
            try
            {
                Microsoft.Office.Interop.Excel.Application xlApp;
                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;

                object misValue = System.Reflection.Missing.Value;
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "IN CHARGE MBC, CHAKALA, MIDC POST OFFICE MUMBAI 400091";
                xlWorkSheet.Cells[2, 1] = "ICICI Bank - " + strGlbTemplateName + " Bulk Register";
                xlWorkSheet.Cells[3, 1] = "Mode of Dispatch - " + strDispMode;
                xlWorkSheet.Cells[4, 1] = "Date - " + DateTime.Now.ToShortDateString();

                for (var i = 0; i < dtBulk.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[5, i + 1] = dtBulk.Columns[i].ColumnName;
                }

                for (int i = 0; i <= dtBulk.Rows.Count - 1; i++)
                {
                    for (int j = 0; j <= dtBulk.Columns.Count - 1; j++)
                    {

                        string str = "'" + dtBulk.Rows[i][j].ToString();

                        xlWorkSheet.Cells[i + 6, j + 1] = str;

                        xlWorkSheet.Cells.Columns.AutoFit();
                    }
                }

                //xlWorkSheet.Range["A1" + ":" + GetExcelColumnName(xlWorkSheet.UsedRange.Columns.Count) + xlWorkSheet.UsedRange.Rows.Count].Borders.LineStyle = LineStyle.SingleLine;
                xlWorkBook.SaveAs(strGlbOutputPathBulk);
                xlWorkBook.Saved = true;
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                MessageBox.Show("Data Exported Successfully ,file Path: " + (strGlbOutputPathBulk));


            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
        private static void GenerateReport(string strReportcond, string strRepoPath, string strserverRptPath)
        {
            try
            {
                string strSignMohanJayaraman = ConfigurationManager.AppSettings["defaultSignatureMohanJayaraman"].ToString();
                string strQry = "truncate table " + const_strReportTable;
                ClsGlobal.ExcuteDML(strQry);

                string strInsertRpt = "Insert into " + const_strReportTable + "( " + strGlbCol + ")" + "(select " + strGlbCol +
                    " from " + strGlbUploadSuccess + strReportcond + " )";

                ClsGlobal.ExcuteDML(strInsertRpt);

                string strNonDunning = "update " + const_strReportTable + " set  VU_SignaturePath = " +
                        "'" + strSignMohanJayaraman + "'";

                ClsGlobal.ExcuteDML(strNonDunning);

                ReportDocument cryRpt = new ReportDocument();
                cryRpt.Load(strserverRptPath);

                cryRpt.Refresh();
                ExportOptions CrExportOptions;
                DiskFileDestinationOptions CrDiskFileDestinationOptions = new DiskFileDestinationOptions();
                PdfRtfWordFormatOptions CrFormatTypeOptions = new PdfRtfWordFormatOptions();
                CrDiskFileDestinationOptions.DiskFileName = strRepoPath;
                CrExportOptions = cryRpt.ExportOptions;
                {
                    CrExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
                    CrExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
                    CrExportOptions.DestinationOptions = CrDiskFileDestinationOptions;
                    CrExportOptions.FormatOptions = CrFormatTypeOptions;
                }

                cryRpt.Export();
                MessageBox.Show("Report Generated SuccessFully");
                cryRpt.Refresh();

                cryRpt.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(MethodBase.GetCurrentMethod().Name + "  " + Ex.Message);
            }
        }
    }
}
