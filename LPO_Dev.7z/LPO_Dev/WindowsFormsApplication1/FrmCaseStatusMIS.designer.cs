﻿namespace LPO_Dev
{
    partial class FrmCaseStatusMIS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbtemplatename = new System.Windows.Forms.ComboBox();
            this.lbltemplatename = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.FrmdateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.TodateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.btngenratemis = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.rbtRtopodMIS = new System.Windows.Forms.RadioButton();
            this.rbtcasestatusMIS = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // cmbtemplatename
            // 
            this.cmbtemplatename.FormattingEnabled = true;
            this.cmbtemplatename.Location = new System.Drawing.Point(222, 71);
            this.cmbtemplatename.Name = "cmbtemplatename";
            this.cmbtemplatename.Size = new System.Drawing.Size(131, 21);
            this.cmbtemplatename.TabIndex = 0;
            // 
            // lbltemplatename
            // 
            this.lbltemplatename.AutoSize = true;
            this.lbltemplatename.Location = new System.Drawing.Point(127, 74);
            this.lbltemplatename.Name = "lbltemplatename";
            this.lbltemplatename.Size = new System.Drawing.Size(85, 13);
            this.lbltemplatename.TabIndex = 1;
            this.lbltemplatename.Text = "Template Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 124);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Select Date:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(91, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "From: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(294, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "To:";
            // 
            // FrmdateTimePicker
            // 
            this.FrmdateTimePicker.Location = new System.Drawing.Point(130, 119);
            this.FrmdateTimePicker.Name = "FrmdateTimePicker";
            this.FrmdateTimePicker.Size = new System.Drawing.Size(131, 20);
            this.FrmdateTimePicker.TabIndex = 7;
            // 
            // TodateTimePicker
            // 
            this.TodateTimePicker.Location = new System.Drawing.Point(335, 118);
            this.TodateTimePicker.Name = "TodateTimePicker";
            this.TodateTimePicker.Size = new System.Drawing.Size(127, 20);
            this.TodateTimePicker.TabIndex = 8;
            // 
            // btngenratemis
            // 
            this.btngenratemis.Location = new System.Drawing.Point(130, 164);
            this.btngenratemis.Name = "btngenratemis";
            this.btngenratemis.Size = new System.Drawing.Size(97, 23);
            this.btngenratemis.TabIndex = 9;
            this.btngenratemis.Text = "GENRATE MIS";
            this.btngenratemis.UseVisualStyleBackColor = true;
            this.btngenratemis.Click += new System.EventHandler(this.btngenratemis_Click);
            // 
            // btnexit
            // 
            this.btnexit.Location = new System.Drawing.Point(335, 164);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(75, 23);
            this.btnexit.TabIndex = 10;
            this.btnexit.Text = "EXIT";
            this.btnexit.UseVisualStyleBackColor = true;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // rbtRtopodMIS
            // 
            this.rbtRtopodMIS.AutoSize = true;
            this.rbtRtopodMIS.Location = new System.Drawing.Point(282, 31);
            this.rbtRtopodMIS.Name = "rbtRtopodMIS";
            this.rbtRtopodMIS.Size = new System.Drawing.Size(98, 17);
            this.rbtRtopodMIS.TabIndex = 46;
            this.rbtRtopodMIS.TabStop = true;
            this.rbtRtopodMIS.Text = "RTO/POD MIS";
            this.rbtRtopodMIS.UseVisualStyleBackColor = true;
            // 
            // rbtcasestatusMIS
            // 
            this.rbtcasestatusMIS.AutoSize = true;
            this.rbtcasestatusMIS.Location = new System.Drawing.Point(173, 31);
            this.rbtcasestatusMIS.Name = "rbtcasestatusMIS";
            this.rbtcasestatusMIS.Size = new System.Drawing.Size(104, 17);
            this.rbtcasestatusMIS.TabIndex = 45;
            this.rbtcasestatusMIS.TabStop = true;
            this.rbtcasestatusMIS.Text = "Case Status MIS";
            this.rbtcasestatusMIS.UseVisualStyleBackColor = true;
            // 
            // FrmCaseStatusMIS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(555, 288);
            this.Controls.Add(this.rbtRtopodMIS);
            this.Controls.Add(this.rbtcasestatusMIS);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btngenratemis);
            this.Controls.Add(this.TodateTimePicker);
            this.Controls.Add(this.FrmdateTimePicker);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbltemplatename);
            this.Controls.Add(this.cmbtemplatename);
            this.Name = "FrmCaseStatusMIS";
            this.Text = "FrmCaseStatusMIS";
            this.Load += new System.EventHandler(this.FrmCaseStatusMIS_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbtemplatename;
        private System.Windows.Forms.Label lbltemplatename;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker FrmdateTimePicker;
        private System.Windows.Forms.DateTimePicker TodateTimePicker;
        private System.Windows.Forms.Button btngenratemis;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.RadioButton rbtRtopodMIS;
        private System.Windows.Forms.RadioButton rbtcasestatusMIS;
    }
}