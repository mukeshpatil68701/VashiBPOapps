﻿namespace LPO_Dev
{
    partial class SubMenuMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SubMenuMaster));
            this.grpbox = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            this.cmbMenu = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnreset = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.chkActive = new System.Windows.Forms.CheckBox();
            this.txtPageURL = new System.Windows.Forms.TextBox();
            this.txtSubMenu = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dvSubMenu = new System.Windows.Forms.DataGridView();
            this.ChkColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.SubMenu_Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MenuName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sub_Menu_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Menu_Id_fk = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sub_Menu_URL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ISFlag = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grpbox.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvSubMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // grpbox
            // 
            this.grpbox.AutoSize = true;
            this.grpbox.BackColor = System.Drawing.Color.Transparent;
            this.grpbox.Controls.Add(this.panel1);
            this.grpbox.Controls.Add(this.btnDelete);
            this.grpbox.Controls.Add(this.cmbMenu);
            this.grpbox.Controls.Add(this.label5);
            this.grpbox.Controls.Add(this.btnreset);
            this.grpbox.Controls.Add(this.btnSave);
            this.grpbox.Controls.Add(this.chkActive);
            this.grpbox.Controls.Add(this.txtPageURL);
            this.grpbox.Controls.Add(this.txtSubMenu);
            this.grpbox.Controls.Add(this.label4);
            this.grpbox.Controls.Add(this.label2);
            this.grpbox.Controls.Add(this.label1);
            this.grpbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpbox.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.grpbox.Location = new System.Drawing.Point(0, 0);
            this.grpbox.Name = "grpbox";
            this.grpbox.Size = new System.Drawing.Size(534, 228);
            this.grpbox.TabIndex = 1;
            this.grpbox.TabStop = false;
            this.grpbox.Text = "SubMenu Master";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(71)))), ((int)(((byte)(150)))));
            this.panel1.BackgroundImage = global::LPO_Dev.Properties.Resources.vara_logo;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(-2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(530, 40);
            this.panel1.TabIndex = 13;
            //this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(149, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(218, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "SUB MENU MASTER";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(244)))), ((int)(((byte)(244)))));
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.Red;
            this.btnDelete.Location = new System.Drawing.Point(311, 178);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(81, 26);
            this.btnDelete.TabIndex = 12;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // cmbMenu
            // 
            this.cmbMenu.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMenu.FormattingEnabled = true;
            this.cmbMenu.Location = new System.Drawing.Point(147, 58);
            this.cmbMenu.Name = "cmbMenu";
            this.cmbMenu.Size = new System.Drawing.Size(296, 24);
            this.cmbMenu.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(57, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Menu Name :";
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(127)))), ((int)(((byte)(26)))));
            this.btnreset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnreset.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnreset.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnreset.Location = new System.Drawing.Point(227, 177);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(81, 28);
            this.btnreset.TabIndex = 9;
            this.btnreset.Text = "Reset";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(71)))), ((int)(((byte)(150)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSave.Location = new System.Drawing.Point(145, 177);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(81, 28);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // chkActive
            // 
            this.chkActive.AutoSize = true;
            this.chkActive.Checked = true;
            this.chkActive.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkActive.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkActive.ForeColor = System.Drawing.SystemColors.ControlText;
            this.chkActive.Location = new System.Drawing.Point(146, 146);
            this.chkActive.Name = "chkActive";
            this.chkActive.Size = new System.Drawing.Size(100, 20);
            this.chkActive.TabIndex = 7;
            this.chkActive.Text = "Is Dialog Box";
            this.chkActive.UseVisualStyleBackColor = true;
            // 
            // txtPageURL
            // 
            this.txtPageURL.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPageURL.Location = new System.Drawing.Point(147, 116);
            this.txtPageURL.Name = "txtPageURL";
            this.txtPageURL.Size = new System.Drawing.Size(296, 23);
            this.txtPageURL.TabIndex = 5;
            // 
            // txtSubMenu
            // 
            this.txtSubMenu.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubMenu.Location = new System.Drawing.Point(147, 88);
            this.txtSubMenu.Name = "txtSubMenu";
            this.txtSubMenu.Size = new System.Drawing.Size(296, 23);
            this.txtSubMenu.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(54, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Other Action :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(71, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Page URL :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(68, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "SubMenu  :";
            // 
            // dvSubMenu
            // 
            this.dvSubMenu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dvSubMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvSubMenu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ChkColumn,
            this.SubMenu_Id,
            this.MenuName,
            this.Sub_Menu_Name,
            this.Menu_Id_fk,
            this.Sub_Menu_URL,
            this.ISFlag});
            this.dvSubMenu.Location = new System.Drawing.Point(6, 232);
            this.dvSubMenu.Name = "dvSubMenu";
            this.dvSubMenu.RowHeadersWidth = 35;
            this.dvSubMenu.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dvSubMenu.Size = new System.Drawing.Size(522, 190);
            this.dvSubMenu.TabIndex = 12;
            this.dvSubMenu.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvSubMenu_CellClick);
            this.dvSubMenu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvSubMenu_CellContentClick);
            // 
            // ChkColumn
            // 
            this.ChkColumn.HeaderText = "Column1";
            this.ChkColumn.Name = "ChkColumn";
            // 
            // SubMenu_Id
            // 
            this.SubMenu_Id.HeaderText = "SubMenu Id";
            this.SubMenu_Id.Name = "SubMenu_Id";
            // 
            // MenuName
            // 
            this.MenuName.HeaderText = "Menu Name";
            this.MenuName.Name = "MenuName";
            // 
            // Sub_Menu_Name
            // 
            this.Sub_Menu_Name.HeaderText = "SubMenu Name";
            this.Sub_Menu_Name.Name = "Sub_Menu_Name";
            // 
            // Menu_Id_fk
            // 
            this.Menu_Id_fk.HeaderText = "Menu_Id_fk";
            this.Menu_Id_fk.Name = "Menu_Id_fk";
            this.Menu_Id_fk.Visible = false;
            // 
            // Sub_Menu_URL
            // 
            this.Sub_Menu_URL.HeaderText = "SubMenu URL";
            this.Sub_Menu_URL.Name = "Sub_Menu_URL";
            // 
            // ISFlag
            // 
            this.ISFlag.HeaderText = "ISFlag";
            this.ISFlag.Name = "ISFlag";
            this.ISFlag.Visible = false;
            // 
            // SubMenuMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(534, 430);
            this.Controls.Add(this.dvSubMenu);
            this.Controls.Add(this.grpbox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SubMenuMaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SUB MENU MASTER";
            this.Load += new System.EventHandler(this.SubMenuMaster_Load);
            this.grpbox.ResumeLayout(false);
            this.grpbox.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvSubMenu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpbox;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.CheckBox chkActive;
        private System.Windows.Forms.TextBox txtPageURL;
        private System.Windows.Forms.TextBox txtSubMenu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbMenu;
        private System.Windows.Forms.DataGridView dvSubMenu;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ChkColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubMenu_Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn MenuName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sub_Menu_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Menu_Id_fk;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sub_Menu_URL;
        private System.Windows.Forms.DataGridViewTextBoxColumn ISFlag;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
    }
}