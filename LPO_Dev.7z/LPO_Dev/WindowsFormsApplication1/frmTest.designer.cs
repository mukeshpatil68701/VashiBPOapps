﻿namespace LPO_Dev
{
    partial class frmTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.ofdbox = new System.Windows.Forms.OpenFileDialog();
            this.ToolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.rbtDispatch = new System.Windows.Forms.RadioButton();
            this.rtbrtoupload = new System.Windows.Forms.RadioButton();
            this.rtbADUpload = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblct = new System.Windows.Forms.Label();
            this.lblrct = new System.Windows.Forms.Label();
            this.lblunmatch = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnMatchMIS = new System.Windows.Forms.Button();
            this.btnUnmatchMIS = new System.Windows.Forms.Button();
            this.rbtRetrival = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnBrowse
            // 
            this.btnBrowse.Font = new System.Drawing.Font("Marlett", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Location = new System.Drawing.Point(580, 51);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 0;
            this.btnBrowse.Text = "Upload";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Marlett", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(347, 546);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(103, 23);
            this.btnUpdate.TabIndex = 0;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Marlett", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(456, 546);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 23);
            this.button3.TabIndex = 0;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtPath
            // 
            this.txtPath.Location = new System.Drawing.Point(109, 51);
            this.txtPath.Name = "txtPath";
            this.txtPath.Size = new System.Drawing.Size(384, 20);
            this.txtPath.TabIndex = 1;
            // 
            // btnSelect
            // 
            this.btnSelect.Font = new System.Drawing.Font("Marlett", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.Location = new System.Drawing.Point(499, 51);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSelect.TabIndex = 0;
            this.btnSelect.Text = "Select ";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // ofdbox
            // 
            this.ofdbox.FileName = "ofdbox";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(389, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(183, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "RTO POD DISPATCH UPDATE";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 104);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(949, 156);
            this.dataGridView1.TabIndex = 4;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(12, 339);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(949, 161);
            this.dataGridView2.TabIndex = 5;
            // 
            // rbtDispatch
            // 
            this.rbtDispatch.AutoSize = true;
            this.rbtDispatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtDispatch.Location = new System.Drawing.Point(238, 31);
            this.rbtDispatch.Name = "rbtDispatch";
            this.rbtDispatch.Size = new System.Drawing.Size(124, 17);
            this.rbtDispatch.TabIndex = 8;
            this.rbtDispatch.TabStop = true;
            this.rbtDispatch.Text = "DISPATCH DATE";
            this.rbtDispatch.UseVisualStyleBackColor = true;
            this.rbtDispatch.CheckedChanged += new System.EventHandler(this.rbtDispatch_CheckedChanged);
            // 
            // rtbrtoupload
            // 
            this.rtbrtoupload.AutoSize = true;
            this.rtbrtoupload.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbrtoupload.Location = new System.Drawing.Point(132, 31);
            this.rtbrtoupload.Name = "rtbrtoupload";
            this.rtbrtoupload.Size = new System.Drawing.Size(105, 17);
            this.rtbrtoupload.TabIndex = 9;
            this.rtbrtoupload.TabStop = true;
            this.rtbrtoupload.Text = "RTO UPLOAD";
            this.rtbrtoupload.UseVisualStyleBackColor = true;
            this.rtbrtoupload.CheckedChanged += new System.EventHandler(this.rtbrtoupload_CheckedChanged);
            // 
            // rtbADUpload
            // 
            this.rtbADUpload.AutoSize = true;
            this.rtbADUpload.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbADUpload.Location = new System.Drawing.Point(21, 31);
            this.rtbADUpload.Name = "rtbADUpload";
            this.rtbADUpload.Size = new System.Drawing.Size(105, 17);
            this.rtbADUpload.TabIndex = 10;
            this.rtbADUpload.TabStop = true;
            this.rtbADUpload.Text = "POD UPLOAD";
            this.rtbADUpload.UseVisualStyleBackColor = true;
            this.rtbADUpload.CheckedChanged += new System.EventHandler(this.rtbADUpload_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Input File :";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(3, 79);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(958, 2);
            this.panel1.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(299, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "MATCH RECORD DISPLAY IN BELOW RECORD :: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 313);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(317, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "UNMATCH RECORD DISPLAY IN BELOW RECORD :: ";
            // 
            // lblct
            // 
            this.lblct.AutoSize = true;
            this.lblct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblct.Location = new System.Drawing.Point(921, 269);
            this.lblct.Name = "lblct";
            this.lblct.Size = new System.Drawing.Size(41, 13);
            this.lblct.TabIndex = 21;
            this.lblct.Text = "label3";
            // 
            // lblrct
            // 
            this.lblrct.AutoSize = true;
            this.lblrct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrct.Location = new System.Drawing.Point(830, 269);
            this.lblrct.Name = "lblrct";
            this.lblrct.Size = new System.Drawing.Size(98, 13);
            this.lblrct.TabIndex = 20;
            this.lblrct.Text = "MATCH CASE ::";
            // 
            // lblunmatch
            // 
            this.lblunmatch.AutoSize = true;
            this.lblunmatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblunmatch.Location = new System.Drawing.Point(917, 508);
            this.lblunmatch.Name = "lblunmatch";
            this.lblunmatch.Size = new System.Drawing.Size(41, 13);
            this.lblunmatch.TabIndex = 23;
            this.lblunmatch.Text = "label3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(803, 508);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "UNMATCH CASE ::";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(3, 538);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(955, 2);
            this.panel2.TabIndex = 24;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(4, 296);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(958, 2);
            this.panel3.TabIndex = 25;
            // 
            // btnMatchMIS
            // 
            this.btnMatchMIS.Font = new System.Drawing.Font("Marlett", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMatchMIS.Location = new System.Drawing.Point(12, 269);
            this.btnMatchMIS.Name = "btnMatchMIS";
            this.btnMatchMIS.Size = new System.Drawing.Size(174, 23);
            this.btnMatchMIS.TabIndex = 26;
            this.btnMatchMIS.Text = "Generate MIS For Match Case ";
            this.btnMatchMIS.UseVisualStyleBackColor = true;
            this.btnMatchMIS.Click += new System.EventHandler(this.btnMatchMIS_Click);
            // 
            // btnUnmatchMIS
            // 
            this.btnUnmatchMIS.Font = new System.Drawing.Font("Marlett", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUnmatchMIS.Location = new System.Drawing.Point(12, 506);
            this.btnUnmatchMIS.Name = "btnUnmatchMIS";
            this.btnUnmatchMIS.Size = new System.Drawing.Size(185, 23);
            this.btnUnmatchMIS.TabIndex = 27;
            this.btnUnmatchMIS.Text = "Generate MIS For UnMatch Case ";
            this.btnUnmatchMIS.UseVisualStyleBackColor = true;
            this.btnUnmatchMIS.Click += new System.EventHandler(this.btnUnmatchMIS_Click);
            // 
            // rbtRetrival
            // 
            this.rbtRetrival.AutoSize = true;
            this.rbtRetrival.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtRetrival.Location = new System.Drawing.Point(368, 31);
            this.rbtRetrival.Name = "rbtRetrival";
            this.rbtRetrival.Size = new System.Drawing.Size(116, 17);
            this.rbtRetrival.TabIndex = 28;
            this.rbtRetrival.TabStop = true;
            this.rbtRetrival.Text = "RTO RETRIVAL";
            this.rbtRetrival.UseVisualStyleBackColor = true;
            this.rbtRetrival.CheckedChanged += new System.EventHandler(this.rbtRetrival_CheckedChanged);
            // 
            // frmTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(967, 577);
            this.Controls.Add(this.rbtRetrival);
            this.Controls.Add(this.btnUnmatchMIS);
            this.Controls.Add(this.btnMatchMIS);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lblunmatch);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblct);
            this.Controls.Add(this.lblrct);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rbtDispatch);
            this.Controls.Add(this.rtbrtoupload);
            this.Controls.Add(this.rtbADUpload);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPath);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.btnBrowse);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "frmTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTest";
            this.Load += new System.EventHandler(this.frmTest_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox txtPath;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.OpenFileDialog ofdbox;
        private System.Windows.Forms.ToolTip ToolTip1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.RadioButton rbtDispatch;
        private System.Windows.Forms.RadioButton rtbrtoupload;
        private System.Windows.Forms.RadioButton rtbADUpload;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblct;
        private System.Windows.Forms.Label lblrct;
        private System.Windows.Forms.Label lblunmatch;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnMatchMIS;
        private System.Windows.Forms.Button btnUnmatchMIS;
        private System.Windows.Forms.RadioButton rbtRetrival;
    }
}