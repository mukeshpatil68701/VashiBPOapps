﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LPO_Dev
{
    
    public class ConnectionString
    {
        public String pServer;
        public String pDataBase;
        public String pUid;
        public String pPwd;
        public String ConnStr;
        public OdbcConnection con;
        public void connect()
        {
            pServer = System.Configuration.ConfigurationSettings.AppSettings["Server"].ToString();

            pDataBase = System.Configuration.ConfigurationSettings.AppSettings["DataBase"].ToString();

            pUid = System.Configuration.ConfigurationSettings.AppSettings["Uid"].ToString();

            pPwd = System.Configuration.ConfigurationSettings.AppSettings["Pwd"].ToString();

            ConnStr = "DRIVER={MySQL ODBC 3.51 Driver}; SERVER=" + pServer + "; DATABASE=" + pDataBase + "; UID=" + pUid + "; PWD=" + pPwd + ";";
            con = new OdbcConnection(ConnStr);
            con.Open();
        }
        public string  GetFileName(string path)
        {
            string OgFile = "";

            string FNAME = path;
            string[] parts = FNAME.Split('\\');
            int len = Convert.ToInt32(parts.Length.ToString());
            string result = parts[len - 1].ToString();


            int index = result.LastIndexOf(".");
            OgFile = result.Substring(0, index);

            return OgFile;
        }
        public DataTable GetExcel(string path)
        {
            OleDbConnection my_con = new OleDbConnection();
            my_con.Close();
            DataTable dt = new DataTable();

            

            if (Path.GetExtension(path) == ".xls")
                my_con.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";Extended Properties=Excel 8.0;Persist Security Info=False";
            else if (Path.GetExtension(path) == ".xlsx")
                my_con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 8.0;Persist Security Info=False";
          
            my_con.Open();
            try
            {
                OleDbCommand o_cmd1 = new OleDbCommand("select * from [Sheet1$] ", my_con);
                //create oledbdataadapter object
                OleDbDataAdapter da1 = new OleDbDataAdapter();
                dt = new DataTable("ExcelData");
                // pass o_cmd data to da object
                da1.SelectCommand = o_cmd1;
                //create a dataset object ds
                //DataSet ds1 = new DataSet();
                // Assign da object data to dataset (virtual table)
                da1.Fill(dt);
            }
              
            catch (Exception ex)
            {
                
            }
            my_con.Close();
            return dt;
        }

    }

}
