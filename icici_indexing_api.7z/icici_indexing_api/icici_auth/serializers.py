from rest_framework import serializers

from .models import Users


class UserSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = Users
        fields = ('created_at',
                  'updated_at',
                  'username',
                  'password',
                  'name',
                  )
