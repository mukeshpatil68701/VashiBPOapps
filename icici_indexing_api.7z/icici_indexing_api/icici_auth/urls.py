from django.conf.urls import url

from icici_auth import views

urlpatterns = [
    url(r"^login/$", views.Login.as_view(), name="login"),
    url(r"^create_user/$", views.CreateUser.as_view(), name="create_user"),
]
