from django.conf.urls import url

from cc_index import views

urlpatterns = [
    url(r"^applicationrecord/$", views.ApplicationRecord.as_view(), name="applicationrecord"),
    url(r'^upload/(?P<filename>[^/]+)$', views.UploadFormImage.as_view(), name="uploadformimage"),
]
