from __future__ import unicode_literals

from django.db import models

# Create your models here.
class ApplicationRecord(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    original_file_name = models.CharField(max_length=100)
    final_file_name = models.CharField(max_length=100)
    file_type = models.CharField(max_length=3)
    skipped = models.BooleanField(default=False)
    app_user_id = models.CharField(max_length=50)
    image_uploaded = models.BooleanField(default=False)
    aof_no = models.CharField(max_length=30)
    cc_no = models.CharField(max_length=16)
