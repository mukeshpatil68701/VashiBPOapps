from __future__ import unicode_literals

from django.apps import AppConfig


class CcIndexConfig(AppConfig):
    name = 'cc_index'
