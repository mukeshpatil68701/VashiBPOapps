from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.http import Http404
from django.shortcuts import render
from rest_framework import status
from rest_framework.parsers import FileUploadParser
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import ApplicationRecord as ApplicationRecordModel
from .serializers import ApplicationRecordSerializer
from .utils import CustomFileSystemStorage


class ApplicationRecord(APIView):

    def post(self, request, format=None):
        """
        Saves the data for each application record that is processed.
        """
        serializer = ApplicationRecordSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UploadFormImage(APIView):
    parser_classes = (FileUploadParser,)

    def put(self, request, filename, format=None):
        """
        Saves the file received in the request in the DOCUMENT_STORAGE_DIR
        specified in the sessings.py.

        Once saved, all the entries for this particular file in the DB are
        marked as image_uploaded = True.
        """
        try:
            file_obj = request.data['file']
            customFS = CustomFileSystemStorage(
                location=settings.DOCUMENT_STORAGE_DIR)
            customFS.save(filename, file_obj)

            records = ApplicationRecordModel.objects.filter(
                final_file_name=filename)
            for record in records:
                record.image_uploaded = True
                print record.id, record.final_file_name, record.image_uploaded
                record.save()

            return Response("File uploaded.", status=status.HTTP_202_ACCEPTED)
        except:
            return Response("File not saved.", status=status.HTTP_500_INTERNAL_SERVER_ERROR)
