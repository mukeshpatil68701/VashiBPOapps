from rest_framework import serializers

from .models import ApplicationRecord


class ApplicationRecordSerializer(serializers.HyperlinkedModelSerializer):

    class Meta:
        model = ApplicationRecord
        fields = ('created_at',
                  'updated_at',
                  'original_file_name',
                  'final_file_name',
                  'file_type',
                  'skipped',
                  'app_user_id',
                  'image_uploaded',
                  'aof_no',
                  'cc_no',
                  )
