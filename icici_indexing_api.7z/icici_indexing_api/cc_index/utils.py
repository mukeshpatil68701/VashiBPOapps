import os

from django.core.files.storage import FileSystemStorage


class CustomFileSystemStorage(FileSystemStorage):
    """
    A custom implementation for the FileSystemStorage class which overwrites
    the file if it already exists.
    """

    def get_available_name(self, name, max_length=None):
        if os.path.exists(self.path(name)):
            os.remove(self.path(name))
        return name
